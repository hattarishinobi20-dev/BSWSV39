using Newtonsoft.Json;
using GromCore.Laser.Logic.Avatar;
using GromCore.Laser.Logic.Avatar.Structures;
using GromCore.Laser.Logic.Battle;
using GromCore.Laser.Logic.Data;
using GromCore.Laser.Logic.Data.Helper;
using GromCore.Laser.Logic.Helper;
using GromCore.Laser.Logic.Home;
using GromCore.Laser.Logic.Home.Items;
using GromCore.Laser.Logic.Home.Structures;
using GromCore.Laser.Logic.Listener;
using GromCore.Laser.Logic.Message;
using GromCore.Laser.Logic.Message.Home;
using GromCore.Laser.Logic.Message.Ranked;
using GromCore.Laser.Logic.Time;
using GromCore.Laser.Titan.DataStream;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;

namespace GromCore.Laser.Logic.Ranked
{
    public struct TickAction
    {
        public bool ActionWill;
        public int AtWhenTick;
    }
    public class RankedMatch
    {
        public long PROJECTGROM_RANKED_MATCH_ID;
        public List<RankedMatchPlayer> MatchPlayers;
        public Timer TempTimer;
        public bool Done;
        public bool Over;
        public GameTime Ticks;
        public bool MatchWithBans = true;
        private bool AllPickedUp;
        private int AllPickedUpLastTick;
        private bool AllBan;
        private int AllBanLastTick;
        private int PostAllPickupTick;

        public TickAction AllPlayersBannedAction;
        public TickAction PickupAction;
        public bool PickUpStarted;
        public int PickUpLastTick;
        public List<int> QueueModel;
        public int Round;
        public RankedMatchPlayer Turn;
        private int PrefferedLocation;
        private int PrefferedTeam;
        public int GameRounds;
        public int TrueTeamWins;
        public int TrueRedWins;
        public bool Solo;
        public bool BanDone;
        public bool MatchOver => TrueRedWins >= 2 || TrueTeamWins >= 2;

        private static readonly Random _random = new Random();


        private readonly object _tickLock = new object();
        private bool _startedSent;
        private bool _banPhaseStarted;
        private bool _pickPhaseStarted;
        private int _botActTick;

        // Names of the bots that fill empty slots (picked at random, unique inside a match).
        private static readonly string[] BotNamePool =
        {
            "TEST", "Botik", "Robotik", "Deneme", "@jowpercat", "PixelBot", "Turbo", "NovaBot", "Alfa", "Beta", "Gama", "Zeta"
        };

        private const int StartDelayTicks = 10;          
        private const int BanStartTicks = 20 * 9;       
        private const int BanPhaseTicks = 20 * 16;    
        private const int PickTurnTicks = 20 * 16;       
        private const int FinalPrepTicks = 20 * 10;       

  
        private static readonly int[] BotBrawlerIds =
        {
            0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 43, 44, 45, 46, 47, 48
        };

        public RankedMatch()
        {
            Round = 0;
            QueueModel = new();
            PrefferedTeam = _random.Next(2);
            PROJECTGROM_RANKED_MATCH_ID = 0;
            Ticks = new();
            MatchPlayers = new();
        }

        public void Start() => TempTimer = new Timer(new TimerCallback(Update), null, 0, 1000 / 20);
        public void Stop()
        {
            TempTimer?.Dispose();
            TempTimer = null;
        }

        public void AddMatchPlayer(RankedMatchPlayer plr) => MatchPlayers.Add(plr);

        public void FillMissingSlotsWithBots(int totalPlayers)
        {
            // Ranked is always 3v3. Fill BOTH teams before the draft starts.
            // Keep real players in their assigned team and use deterministic
            // PlayerIndex values: blue = 0..2, red = 3..5.
            int[] botBrawlers = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 43, 44, 45, 46, 47, 48 };

            int nextBotNumber = MatchPlayers.Count(p => p.IsBot) + 1;

            while (MatchPlayers.Count(p => p.TeamIndex == 0) < 3 || MatchPlayers.Count(p => p.TeamIndex == 1) < 3)
            {
                int blue = MatchPlayers.Count(p => p.TeamIndex == 0);
                int red = MatchPlayers.Count(p => p.TeamIndex == 1);
                if (blue >= 3 && red >= 3) break;

                int team = blue < 3 ? 0 : 1;
                if (red < 3 && blue >= 3) team = 1;

                int character = GlobalId.CreateGlobalId(16, 1); // Prefer Shelly.
                if (MatchPlayers.Any(p => p.TeamIndex == team && p.Character == character))
                {
                    character = 0;
                    foreach (int id in botBrawlers)
                    {
                        int candidate = GlobalId.CreateGlobalId(16, id);
                        if (!MatchPlayers.Any(p => p.TeamIndex == team && p.Character == candidate))
                        {
                            character = candidate;
                            break;
                        }
                    }
                }

                if (character == 0)
                    character = GlobalId.CreateGlobalId(16, 1);

                int internalIndex = MatchPlayers.Count == 0
                    ? 0
                    : MatchPlayers.Max(p => p.PlayerInternalIndex) + 1;

                RankedMatchPlayer bot = RankedMatchPlayer.CreateBotPlayer(
                    team,
                    internalIndex,
                    character,
                    NextBotName());

                MatchPlayers.Add(bot);
            }

            // Normalize the six draft slots. The client uses the team information
            // from RankedMatchStartedMessage, while PlayerIndex identifies the slot.
            for (int team = 0; team < 2; team++)
            {
                List<RankedMatchPlayer> teamPlayers = MatchPlayers
                    .Where(p => p.TeamIndex == team)
                    .OrderBy(p => p.IsBot)
                    .ThenBy(p => p.PlayerInternalIndex)
                    .Take(3)
                    .ToList();

                for (int i = 0; i < teamPlayers.Count; i++)
                    teamPlayers[i].PlayerIndex = team == 0 ? i : i + 3;
            }

            // Send the player list in team order as well. This prevents older clients
            // from treating an interleaved list as a single blue team.
            MatchPlayers = MatchPlayers
                .OrderBy(p => p.TeamIndex)
                .ThenBy(p => p.PlayerIndex)
                .ToList();
        }

        private string NextBotName()
        {
            List<string> free = BotNamePool
                .Where(n => !MatchPlayers.Any(p => p.DisplayData != null && p.DisplayData.Name == n))
                .ToList();
            if (free.Count > 0) return free[Random.Shared.Next(free.Count)];
            return "Bot " + (MatchPlayers.Count(p => p.IsBot) + 1);
        }

        private static bool IsValidHero(int globalId)
        {
            CharacterData d = DataTables.Get(16).GetDataByGlobalId<CharacterData>(globalId);
            return d != null && !d.LockedForChronos && !d.Disabled && d.IsHero();
        }

        private bool IsBanned(int globalId) => globalId != 0 && MatchPlayers.Any(x => x.BannedCharacter == globalId);

        private bool IsTeammatePick(RankedMatchPlayer who, int globalId) =>
            MatchPlayers.Any(x => x != who && x.TeamIndex == who.TeamIndex && x.Picked && x.Character == globalId);

        /// <summary>
        /// Returns a random global id of a valid, unlocked hero that satisfies <paramref name="allowed"/>,
        /// or 0 if nothing fits.
        /// </summary>
        private static int ChooseBrawler(Func<int, bool> allowed)
        {
            List<int> pool = new List<int>();
            foreach (int id in BotBrawlerIds)
            {
                if (GeneralStaticLogic.LockedBrawlers.Contains(id)) continue;

                int globalId = GlobalId.CreateGlobalId(16, id);
                CharacterData data = DataTables.Get(16).GetDataByGlobalId<CharacterData>(globalId);
                if (data == null || data.LockedForChronos || data.Disabled || !data.IsHero()) continue;
                if (allowed != null && !allowed(globalId)) continue;

                pool.Add(globalId);
            }

            if (pool.Count == 0) return 0;
            return pool[Random.Shared.Next(pool.Count)];
        }

        /// <summary>
        /// Every bot bans one brawler (different from the other bots' bans), exactly like a real player would.
        /// </summary>
        private void PrepareBotBans()
        {
            HashSet<int> alreadyBanned = new HashSet<int>();
            foreach (RankedMatchPlayer p in MatchPlayers)
                if (p.BannedCharacter != 0) alreadyBanned.Add(p.BannedCharacter);

            foreach (RankedMatchPlayer bot in MatchPlayers.Where(x => x.IsBot))
            {
                int ban = ChooseBrawler(c => !alreadyBanned.Contains(c));
                if (ban == 0) ban = ChooseBrawler(null);

                bot.BannedCharacter = ban;
                bot.Banned = true;
                bot.BanState = 0;
                if (ban != 0) alreadyBanned.Add(ban);

                Console.WriteLine($"[Ranked] {bot.DisplayData.Name} (takım {bot.TeamIndex}) yasakladı: {GlobalId.GetInstanceId(ban)}");
            }
        }

        /// <summary>
        /// A bot locks in a random brawler that is not banned and not already picked by a teammate.
        /// </summary>
        private void BotPick(RankedMatchPlayer bot)
        {
            int selected = ChooseBrawler(c => !IsBanned(c) && !IsTeammatePick(bot, c));
            if (selected == 0) selected = ChooseBrawler(c => !IsBanned(c));
            if (selected == 0) selected = ChooseBrawler(null);
            if (selected == 0) selected = GlobalId.CreateGlobalId(16, 0);

            bot.BotCharacter = selected;
            bot.Character = selected;
            bot.PickState = 0;
            bot.Picked = true;

            Console.WriteLine($"[Ranked] {bot.DisplayData.Name} (takım {bot.TeamIndex}) seçti: {GlobalId.GetInstanceId(selected)}");
        }

        /// <summary>
        /// A human ran out of time: lock in the brawler they were hovering, or a random valid one they own.
        /// (No penalty and the match is NOT cancelled.)
        /// </summary>
        private void AutoPickHuman(RankedMatchPlayer human)
        {
            Func<int, bool> usable = g => g != 0 && IsValidHero(g) && human.Avatar != null && human.Avatar.HasHero(g)
                                          && !IsBanned(g) && !IsTeammatePick(human, g);

            int choice = usable(human.Character) ? human.Character : 0;

            if (choice == 0 && human.Avatar != null)
            {
                List<int> options = human.Avatar.Heroes.Select(h => h.CharacterId).Where(usable).ToList();
                if (options.Count > 0) choice = options[Random.Shared.Next(options.Count)];
            }

            if (choice == 0 && human.Avatar != null)
            {
                List<int> options = human.Avatar.Heroes.Select(h => h.CharacterId).Where(g => IsValidHero(g) && !IsBanned(g)).ToList();
                if (options.Count > 0) choice = options[Random.Shared.Next(options.Count)];
            }

            if (choice == 0) choice = GlobalId.CreateGlobalId(16, 0);

            human.Character = choice;
            human.SetPickUpQueue(0);
            human.Picked = true;

            Console.WriteLine($"[Ranked] {human.DisplayData.Name} süre doldu, otomatik seçildi: {GlobalId.GetInstanceId(choice)}");
        }

        /// <summary>
        /// A real player hovers (pickType 1) or locks in (pickType 0) a brawler. Returns false when the
        /// request is not valid right now; the caller answers with PickHeroFailed (never with OutOfSync).
        /// </summary>
        public bool HandlePick(long accountId, int globalId, int pickType)
        {
            lock (_tickLock)
            {
                if (Done || Over || !_pickPhaseStarted || AllPickedUp) return false;

                RankedMatchPlayer player = GetPlayer(accountId);
                if (player == null || player.IsBot) return false;
                if (Turn == null || Turn.AccountId != player.AccountId) return false;
                if (!IsValidHero(globalId)) return false;
                if (player.Avatar == null || !player.Avatar.HasHero(globalId)) return false;

                if (pickType == 1)
                {
                    player.Character = globalId;
                    Send(new RankedMatchHeroDataUpdatedMessage { Player = player });
                    return true;
                }

                if (pickType == 0)
                {
                    if (IsBanned(globalId) || IsTeammatePick(player, globalId)) return false;

                    player.Character = globalId;
                    player.SetPickUpQueue(0);
                    player.Picked = true;
                    Send(new RankedMatchHeroPickedMessage { Player = player });
                    NextTurn();
                    return true;
                }

                return false;
            }
        }

        /// <summary>
        /// A real player hovers (pickType 1) or confirms (pickType 0) the brawler they want to ban.
        /// </summary>
        public bool HandleBan(long accountId, int instanceId, int pickType)
        {
            lock (_tickLock)
            {
                if (Done || Over || !_banPhaseStarted || BanDone) return false;

                RankedMatchPlayer player = GetPlayer(accountId);
                if (player == null || player.IsBot || player.Banned) return false;

                int globalId = GlobalId.CreateGlobalId(16, instanceId);
                if (!IsValidHero(globalId)) return false;

                if (pickType == 1)
                {
                    player.Character = globalId;
                    Send(new RankedMatchHeroDataUpdatedMessage { Player = player });
                    return true;
                }

                if (pickType == 0)
                {
                    player.Character = globalId;
                    player.BannedCharacter = globalId;
                    player.SetBanQueue(0);
                    player.Banned = true;
                    Send(new RankedMatchBanHeroResponseMessage { BannedCharacter = globalId, PlayerAccountId = player.AccountId });
                    Console.WriteLine($"[Ranked] {player.DisplayData.Name} yasakladı: {instanceId}");
                    return true;
                }

                return false;
            }
        }

        public static int CalculatePlayerIndex(int playerPosition, int teamIndex)
        {
            if (playerPosition == 0 && teamIndex == 1)
                return 3;

            if (teamIndex == 0)
                return playerPosition % 3;
            else if (teamIndex == 1)
                return (playerPosition % 3) + 3;

            return -1;
        }

        public void Update(object stateInfo)
        {
            // System.Threading.Timer can overlap callbacks and an unhandled exception in a
            // timer callback kills the whole server process, so serialize + guard every tick.
            lock (_tickLock)
            {
                try
                {
                    Tick();
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"[Ranked] Матч {PROJECTGROM_RANKED_MATCH_ID} Программа выдала ошибку и завершила работу: {ex}");
                    try { Send(new RankedMatchTerminatedMessage { Name = "", Reason = 3 }); } catch { }
                    Done = true;
                    StopMatch();
                }
            }
        }

        public void Tick()
        {
            Ticks.IncreaseTick();
            if (Done) return;

            HandleTerminate();
            if (Done)
            {
                StopMatch();
                return;
            }

            int now = GetTicks();

            // Safety net: the queue normally fills both teams before the match is created.
            if (!_startedSent && now >= 5 && MatchPlayers.Count < 6)
                FillMissingSlotsWithBots(6);

            // ---- 1) coin flip screen ----
            if (!_startedSent && now >= StartDelayTicks)
            {
                _startedSent = true;

                Console.WriteLine("===Матч начинается.  ===");
                Console.WriteLine($"Общий: {MatchPlayers.Count}");
                Console.WriteLine($"Синий: {MatchPlayers.Count(p => p.TeamIndex == 0)}");
                Console.WriteLine($"красный: {MatchPlayers.Count(p => p.TeamIndex == 1)}");
                foreach (var p in MatchPlayers)
                {
                    Console.WriteLine($"  {p.DisplayData.Name} | Набор={p.TeamIndex} | Index={p.PlayerIndex} | Бот={p.IsBot}");
                }
                Console.WriteLine("====================");

                PrefferedLocation = CalculateRandomMap();
                QueueModel = MatchPlayers.Where(p => !p.IsBot).Select(p => p.PlayerInternalIndex).ToList();

                Send(new RankedMatchStartedMessage
                {
                    Players = MatchPlayers,
                    SelectedMap = GlobalId.GetInstanceId(PrefferedLocation),
                    Team = PrefferedTeam,
                    PROJECTGROM_RANKED_MATCH_ID = PROJECTGROM_RANKED_MATCH_ID
                });
            }

            // ---- 2) ban phase (or straight to pick when bans are disabled) ----
            if (_startedSent && !_banPhaseStarted && !_pickPhaseStarted && now >= BanStartTicks)
            {
                if (MatchWithBans) StartBanPhase(now);
                else StartPickPhase(now);
            }

            // The ban phase ends when everybody (bots ban instantly) has banned OR when the time is up.
            // The old code could only leave the ban phase when every human had banned, so a single
            // missed ban froze the match on the ban screen forever.
            if (_banPhaseStarted && !BanDone)
            {
                bool everyoneBanned = MatchPlayers.All(p => p.Banned);
                if (everyoneBanned || now >= AllBanLastTick + BanPhaseTicks)
                    EndBanPhase(now);
            }

            // ---- 3) everybody picked -> final preparation ----
            if (_pickPhaseStarted && !AllPickedUp && MatchPlayers.All(p => p.Picked))
            {
                Send(new RankedMatchFinalPreparationStartedMessage());
                AllPickedUp = true;
                AllPickedUpLastTick = now;
                PickUpStarted = false;
            }

           
            if (PickUpStarted && !AllPickedUp && Turn != null)
            {
                if (Turn.IsBot)
                {
                    if (now >= _botActTick)
                    {
                        BotPick(Turn);
                        Send(new RankedMatchHeroPickedMessage { Player = Turn });
                        NextTurn();
                    }
                }
                else if (PickUpLastTick + PickTurnTicks < now)
                {
                    AutoPickHuman(Turn);
                    Send(new RankedMatchHeroPickedMessage { Player = Turn });
                    NextTurn();
                }
            }

            // ---- 5) battle ----
            if (AllPickedUp && AllPickedUpLastTick + FinalPrepTicks < now)
            {
                foreach (RankedMatchPlayer p in MatchPlayers)
                    if (p.IsBot)
                        p.Character = p.BotCharacter;

                Done = true;
                LogicServerListener.Instance.StartMatchBattle(MatchPlayers, null, PrefferedLocation, (int)PROJECTGROM_RANKED_MATCH_ID);
            }

            TickTimers();
        }

        private void StartBanPhase(int now)
        {
            _banPhaseStarted = true;

            foreach (RankedMatchPlayer p in MatchPlayers)
                if (!p.IsBot)
                    p.BanState = 1;

         
            PrepareBotBans();

            Send(new RankedMatchBanStartedMessage());

            AllBan = false;
            AllBanLastTick = now;
        }

        private void EndBanPhase(int now)
        {
            BanDone = true;
            AllBan = true;


            foreach (RankedMatchPlayer p in MatchPlayers)
                if (!p.IsBot && !p.Banned)
                    p.Banned = true;

      
            Dictionary<long, int> bannedPersons = new Dictionary<long, int>();
            foreach (RankedMatchPlayer p in MatchPlayers)
                if (p.BannedCharacter != 0)
                    bannedPersons[p.AccountId] = p.BannedCharacter;

            Send(new RankedMatchBanEndedMessage { BannedBrawlers = bannedPersons });

            foreach (RankedMatchPlayer p in MatchPlayers)
            {
                p.Character = 0;
                p.BanState = 0;
                p.Picked = false;
            }

            StartPickPhase(now);
        }

        private void StartPickPhase(int now)
        {
            _pickPhaseStarted = true;

            QueueModel = BuildDraftOrder();
            Round = 0;
            BeginTurn(now);
        }

        
        private List<int> BuildDraftOrder()
        {
            int startTeam = PrefferedTeam;
            int otherTeam = 1 - startTeam;

            List<RankedMatchPlayer> s = MatchPlayers.Where(p => p.TeamIndex == startTeam).OrderBy(p => p.PlayerIndex).ToList();
            List<RankedMatchPlayer> o = MatchPlayers.Where(p => p.TeamIndex == otherTeam).OrderBy(p => p.PlayerIndex).ToList();

            List<RankedMatchPlayer> order = new List<RankedMatchPlayer>();
            void Add(List<RankedMatchPlayer> list, int i) { if (i < list.Count) order.Add(list[i]); }
            Add(s, 0); Add(o, 0); Add(o, 1); Add(s, 1); Add(s, 2); Add(o, 2);

            foreach (RankedMatchPlayer p in MatchPlayers)
                if (!order.Contains(p)) order.Add(p);

            return order.Select(p => p.PlayerInternalIndex).ToList();
        }

        private void BeginTurn(int now)
        {
            while (Round < QueueModel.Count)
            {
                Turn = MatchPlayers.Find(p => p.PlayerInternalIndex == QueueModel[Round]);
                if (Turn != null) break;
                Round++;
            }

            if (Round >= QueueModel.Count || Turn == null)
            {
                PickUpStarted = false;
                return;
            }

            Turn.PickState = 0;

            int nextIndex = -1;
            if (Round + 1 < QueueModel.Count)
            {
                RankedMatchPlayer next = MatchPlayers.Find(p => p.PlayerInternalIndex == QueueModel[Round + 1]);
                if (next != null) nextIndex = next.PlayerIndex;
            }

            Send(new RankedMatchPickStartedMessage { Player = Turn, Next = nextIndex });

            PickUpStarted = true;
            PickUpLastTick = now;
            if (Turn.IsBot) _botActTick = now + Random.Shared.Next(30, 61);

            Console.WriteLine($"[Ranked] Заказ: {Turn.DisplayData.Name} (набор {Turn.TeamIndex}, бот={Turn.IsBot})");
        }

        public void NextTurn()
        {
            Round++;

            if (Round >= QueueModel.Count)
            {

                PickUpStarted = false;
                return;
            }

            BeginTurn(GetTicks());
        }

        public void TickTimers()
        {
            if (PostAllPickupTick > 0) PostAllPickupTick--;
        }

        public void TerminateError(string name)
        {
            Send(new RankedMatchTerminatedMessage { Name = name });
            Done = true;
        }

        public int RestartRound()
        {
            if (TrueRedWins >= 2 || TrueTeamWins >= 2)
            {
                // The best-of-3 is decided: release the timer and let the regulator drop this match.
                StopMatch();
                return -1;
            }
            Console.WriteLine($"[Ranked] Тур завершен (синий) {TrueTeamWins} - Красный {TrueRedWins}), Начинается следующий раунд (раунд) {GameRounds})");
            LogicServerListener.Instance.StartMatchBattle(MatchPlayers, null, PrefferedLocation, (int)PROJECTGROM_RANKED_MATCH_ID, GameRounds);
            return 0;
        }

        public void StopMatch()
        {
            Over = true;
            Stop();
        }

        public void HandleTerminate()
        {
            foreach (RankedMatchPlayer p in MatchPlayers)
                if (!p.IsBot && !LogicServerListener.Instance.IsPlayerOnline(p.AccountId))
                {
                    Send(new RankedMatchTerminatedMessage { Name = p.DisplayData.Name, Reason = 2 });
                    Done = true;
                }
        }

        public void Send(GameMessage message)
        {
            foreach (RankedMatchPlayer conn in MatchPlayers)
            {
                if (!conn.IsBot && conn.Home?.HomeMode?.GameListener != null)
                    conn.Home.HomeMode.GameListener.SendMessage(message);
            }
        }

        public int CalculateRandomMap()
        {
            List<string> Names = new();
            foreach (RankedLocationsData data in DataTables.Get(DataType.RankedE).GetDatas())
            {
                var locationData = DataTables.Get(DataType.Location).GetData<LocationData>(data.Name);
                if (locationData != null && !GeneralStaticLogic.BlockedEventsForRanked.Contains(locationData.GameModeVariation))
                    Names.Add(data.Name);
            }

            if (Names.Count == 0)
                throw new InvalidOperationException("No available ranked maps found");

            string random = Names[_random.Next(Names.Count)];
            var selectedLocation = DataTables.Get(DataType.Location).GetData<LocationData>(random);
            if (selectedLocation == null)
                throw new InvalidOperationException($"Location data not found: {random}");

            return selectedLocation.GetGlobalId();
        }

        public RankedMatchPlayer GetPlayer(long id) => MatchPlayers.Find(p => p.AccountId == id);
        public int GetTicks() => Ticks.GetTick();
    }

    public class RankedMatchPlayer
    {
        public long AccountId;
        public PlayerDisplayData DisplayData;
        public int Character;
        public int BanState;
        public int PickState;
        public bool Picked;
        public bool Banned;
        public Hero HeroData;
        public int PlayerIndex;
        public int PlayerInternalIndex;
        public int TeamIndex;
        public int BannedCharacter;
        public bool IsBot;
        public int BotCharacter;
        [JsonIgnore] public readonly ClientHome Home;
        [JsonIgnore] public readonly ClientAvatar Avatar;

        public RankedMatchPlayer()
        {
            DisplayData = new PlayerDisplayData();
            AccountId = -1;
        }

        public RankedMatchPlayer(ClientAvatar a, ClientHome h) : this()
        {
            Home = h;
            Avatar = a;
        }

        public static RankedMatchPlayer CreateRankedPlayer(ClientAvatar avatar, ClientHome home, int teamIndex, int playerIndex, int playerIndexInTeam)
        {
            RankedMatchPlayer player = new(avatar, home);
            player.TeamIndex = teamIndex;
            player.PlayerInternalIndex = playerIndex;
            player.PlayerIndex = teamIndex == 0 ? playerIndexInTeam : playerIndexInTeam + 3;
            player.DisplayData = new(home.ThumbnailId, home.NameColorId, avatar.Name, home.HasPremiumPass, home.HasPremiumPass);
            player.AccountId = avatar.AccountId;
            return player;
        }

        public static RankedMatchPlayer CreateBotPlayer(int teamIndex, int playerIndex, int character, string botName)
        {
            RankedMatchPlayer player = new();
            player.IsBot = true;
            player.AccountId = 1900000000L + playerIndex;
            player.TeamIndex = teamIndex;
            player.PlayerInternalIndex = playerIndex;
            // A bot starts the draft exactly like a human: nothing banned, nothing picked.
            // Its ban/pick is decided by RankedMatch.PrepareBotBans / PrepareBotPicks.
            player.BotCharacter = character;
            player.Character = 0;
            player.DisplayData = new PlayerDisplayData(
                GlobalId.CreateGlobalId(28, 0),
                GlobalId.CreateGlobalId(43, 0),
                botName,
                false,
                false);
            player.Banned = false;
            player.Picked = false;
            return player;
        }

        public void ChangeHeroData(int character, int state)
        {
            if (state >= 0 && state <= 1) BanState = state;
            if (state >= 2 && state <= 3)
                switch (state)
                {
                    case 2:
                        PickState = 0;
                        break;
                    case 3:
                        PickState = 1;
                        break;
                }
        }

        public void SetBanQueue(int i) => BanState = i;
        public void SetPickUpQueue(int q) => PickState = q;

        private int ValidCardRef(Hero hero, int instanceId, int metaType)
        {
            try
            {
                if (instanceId <= 0 || instanceId >= 1000000) return 0;
                CardData card = DataTables.Get(23).GetData<CardData>(instanceId);
                if (card == null || card.MetaType != metaType) return 0;

                string heroName = hero.CharacterData != null ? hero.CharacterData.Name : null;
                if (heroName != null && card.Target != heroName) return 0;

                int globalId = card.GetGlobalId();
                if (Avatar != null && Avatar.SPGS != null && !Avatar.SPGS.Contains(globalId)) return 0;
                return globalId;
            }
            catch
            {
                return 0;
            }
        }

        private static int ValidGearRef(Hero hero, int gearId)
        {
            if (gearId < 0 || hero.OwnedGears == null || !hero.OwnedGears.Contains(gearId)) return 0;
            return 62000000 + gearId;
        }

        public void Encode(ByteStream Stream)
        {
            ByteStreamHelper.EncodeLogicLong(Stream, AccountId);
            Stream.WriteBoolean(true);
            DisplayData.Encode(Stream);

            Stream.WriteVInt(BanState);
            Stream.WriteVInt(PickState);
            Stream.WriteVInt(PlayerIndex);
            ByteStreamHelper.WriteDataReference(Stream, Character);

            if (Character == 0)
            {
                Stream.WriteVInt(11);
                ByteStreamHelper.WriteDataReference(Stream, 0);
                ByteStreamHelper.WriteDataReference(Stream, 0);
                ByteStreamHelper.WriteDataReference(Stream, 0);
                ByteStreamHelper.WriteDataReference(Stream, 0);
                Stream.WriteBoolean(false);
                Stream.WriteVInt(1);
                ByteStreamHelper.WriteDataReference(Stream, 0);
                Stream.WriteVInt(1);
                ByteStreamHelper.WriteDataReference(Stream, 0);
                Stream.WriteVInt(0);
            }
            else
            {
                Hero hero = null;
                if (!IsBot && Avatar != null)
                    hero = Avatar.GetHero(Character);

                int _heroLVL = IsBot ? 11 : 1;
                int _starpowerId = 0;
                int _gadgetId = 0;
                int _hyperCharge = 0;
                int _gear1GlobalId = 0;
                int _gear2GlobalId = 0;

                if (hero != null)
                {
                 
                    _heroLVL = hero.PowerLevel;
                    _starpowerId = ValidCardRef(hero, hero.SelectedStarPowerId, 4);
                    _gadgetId = ValidCardRef(hero, hero.SelectedGadgetId, 5);
                    _hyperCharge = ValidCardRef(hero, hero.SelectedOverChargeId, 6);
                    _gear1GlobalId = ValidGearRef(hero, hero.SelectedGearId1);
                    _gear2GlobalId = ValidGearRef(hero, hero.SelectedGearId2);
                }

                Stream.WriteVInt(_heroLVL);
                ByteStreamHelper.WriteDataReference(Stream, 0);
                ByteStreamHelper.WriteDataReference(Stream, _starpowerId);
                ByteStreamHelper.WriteDataReference(Stream, _gadgetId);
                ByteStreamHelper.WriteDataReference(Stream, _hyperCharge);
                Stream.WriteBoolean(Picked);
                Stream.WriteVInt(1);
                ByteStreamHelper.WriteDataReference(Stream, _gear1GlobalId);
                Stream.WriteVInt(1);
                ByteStreamHelper.WriteDataReference(Stream, _gear2GlobalId);
                Stream.WriteVInt(0);
            }
        }
    }
}