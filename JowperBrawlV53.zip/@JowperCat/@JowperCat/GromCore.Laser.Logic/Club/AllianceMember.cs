namespace GromCore.Laser.Logic.Club
{
    using Newtonsoft.Json;
    using GromCore.Laser.Logic.Avatar;
    using GromCore.Laser.Logic.Avatar.Structures;
    using GromCore.Laser.Logic.Data.Helper;
    using GromCore.Laser.Logic.Home;
    using GromCore.Laser.Logic.Listener;
    using GromCore.Laser.Titan.DataStream;
    using GromCore.Laser.Titan.Debug;

    public class AllianceMember
    {
        [JsonProperty("displayData")] public PlayerDisplayData DisplayData { get; set; }
        [JsonProperty("accountId")] public long AccountId { get; set; }
        [JsonProperty("trophies")] public int Trophies { get; set; }
        [JsonProperty("role")] public AllianceRole Role { get; set; }
        [JsonProperty("DoNotDisturb")] public bool DoNotDisturb { get; set; }
        [JsonProperty("pbankwins")] public int PiggyBankWins { get; set; }
        [JsonProperty("hasactive")] public bool HasActivePiggyBank { get; set; }

        // Filler member used only while encoding (never stored): the client refuses to show the club
        // Mega Kumbara ("collect more members for the event") when the club is too small.
        [JsonIgnore] public bool IsVirtual;

        public static AllianceMember CreateVirtual(int index)
        {
            return new AllianceMember
            {
                IsVirtual = true,
                AccountId = 1900000100L + index,
                Role = AllianceRole.Member,
                Trophies = 0,
                PiggyBankWins = 0,
                DisplayData = new PlayerDisplayData(GlobalId.CreateGlobalId(28, 0), GlobalId.CreateGlobalId(43, 0), "Kumbara Botu " + (index + 1), false, false)
            };
        }

        private void EncodeVirtual(ByteStream stream)
        {
            stream.WriteLong(AccountId);
            stream.WriteVInt((int)Role);
            stream.WriteVInt(Trophies);
            stream.WriteVInt(0);      // player status
            stream.WriteVInt(3600);   // last online (seconds ago)
            stream.WriteVInt(0);
            stream.WriteBoolean(true);
            DisplayData.Encode(stream);
            stream.WriteVInt(0);
            stream.WriteBoolean(false);
            stream.WriteVInt(0);
            stream.WriteVInt(0);

            stream.WriteVInt(1);
            stream.WriteVInt(PiggyBankWins);
            stream.WriteVInt(6);
            stream.WriteVInt(1488);
        }

        [JsonIgnore]
        public ClientAvatar Avatar
        {
            get
            {
                return LogicServerListener.Instance.GetAvatar(AccountId);
            }
        }

        [JsonIgnore]
        public HomeMode HomeMode
        {
            get
            {
                return LogicServerListener.Instance.GetHomeMode(AccountId);
            }
        }

        [JsonIgnore]
        public bool IsOnline
        {
            get
            {
                return LogicServerListener.Instance.IsPlayerOnline(AccountId);
            }
        }

        public AllianceMember()
        {
            // For json...
        }

        public AllianceMember(ClientAvatar avatar, HomeMode home)
        {
            DisplayData = new PlayerDisplayData(home.Home.ThumbnailId, home.Home.NameColorId, avatar.Name, home.Home.HasPremiumPass, home.Home.HasPremiumPassPlus);
            AccountId = avatar.AccountId;
            Trophies = avatar.Trophies;
            Role = avatar.AllianceRole;
            if (avatar.DoNotDisturb == 1) DoNotDisturb = true;
            else DoNotDisturb = false;
        }

        public void Encode(ByteStream stream)
        {
            if (IsVirtual)
            {
                EncodeVirtual(stream);
                return;
            }

            ClientAvatar avatar = Avatar;

            stream.WriteLong(AccountId);
            stream.WriteVInt((int)Role);
            stream.WriteVInt(avatar.Trophies);

            stream.WriteVInt(IsOnline ? avatar.PlayerStatus : 0); // PlayerStatus
            stream.WriteVInt(IsOnline ? -1 : (int)(DateTime.UtcNow - avatar.LastOnline).TotalSeconds);

            stream.WriteVInt(0);

            stream.WriteBoolean(true);
            DisplayData.Name = avatar.Name;
            DisplayData.Encode(stream);

            stream.WriteVInt(0);
            stream.WriteBoolean(false);
            stream.WriteVInt(0);

            stream.WriteVInt(0);

            // Mega Kumbara (club piggy bank) block of this member: contribution (wins) + tickets.
            // The club screen builds the yellow progress bar and the "top contributors" list from these,
            // so they must come from the player's real values (updated by battles).
            int piggyWins = PiggyBankWins;
            int piggyTickets = 6;
            var piggyHome = HomeMode?.Home;
            if (piggyHome != null)
            {
                piggyWins = Math.Clamp(piggyHome.PiggyBankWins, 0, 50);
                piggyTickets = piggyHome.PiggyBankTickets;
                PiggyBankWins = piggyWins;
            }
            HasActivePiggyBank = true;

            stream.WriteVInt(1);
            stream.WriteVInt(piggyWins);
            stream.WriteVInt(piggyTickets);
            stream.WriteVInt(1488);
        }
    }
}
