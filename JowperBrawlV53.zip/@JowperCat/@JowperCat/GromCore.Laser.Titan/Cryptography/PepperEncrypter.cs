namespace GromCore.Laser.Titan.Cryptography
{
    using System.Runtime.ExceptionServices;
    using System.Text;
    using static GromCore.Laser.Titan.Library.TweetNaCl;

    public class PepperEncrypter : StreamEncrypter
    {
        private byte[] Key;
        private byte[] Nonce;

        public PepperEncrypter(byte[] key, byte[] nonce)
        {
            Key = key;
            Nonce = nonce;
        }

        public override int Decrypt(byte[] input, byte[] output, int length)
        {
            NextNonce(Nonce);

            try
            {
                byte[] res = crypto_secretbox_xsalsa19poly1305_tweet_open(input, Nonce, Key);
                Buffer.BlockCopy(res, 0, output, 0, res.Length);
            }
            catch (InvalidCipherTextException)
            {
                return -1;
            }
            return 0;
        }

        public override int Encrypt(byte[] input, byte[] output, int length)
        {
            NextNonce(Nonce);

            byte[] res = crypto_secretbox_xsalsa19poly1305_tweet(input, Nonce, Key);
            Buffer.BlockCopy(res, 0, output, 0, res.Length);
            return 0;
        }

        public void NextNonce(byte[] nonce)
        {
            int timesToIncrease = 2;
            for (int j = 0; j < timesToIncrease; j++)
            {
                ushort c = 1;
                for (UInt32 i = 0; i < nonce.Length; i++)
                {
                    c += (ushort)nonce[i];
                    nonce[i] = (byte)c;
                    c >>= 8;
                }
            }
            //for(int i= 23; i >= 0; i--)
            //{
            //    if (nonce[i] >= 255) nonce[i] = 0;
            //    else
            //    {
            //        nonce[i]+=2;
            //        break;
            //    }
            //}
        }
        public static string DecodeUntilReadable(string input)
        {
            string current = input;
            int attempt = 0;
            const int maxAttempts = 10;

            while (attempt < maxAttempts)
            {
                try
                {
                    byte[] data = Convert.FromBase64String(current);
                    string decoded = Encoding.UTF8.GetString(data);

                    if (IsValidBase64(decoded))
                    {
                        current = decoded;
                        attempt++;
                    }
                    else
                    {
                        return decoded; 
                    }
                }
                catch
                {
                    return current;
                }
            }

            return current; 
        }

        static bool IsValidBase64(string s)
        {
            try
            {
                Convert.FromBase64String(s);
                return true;
            }
            catch
            {
                return false;
            }
        }

        public override int GetEncryptionOverhead()
        {
            return 16;
        }
    }
}
