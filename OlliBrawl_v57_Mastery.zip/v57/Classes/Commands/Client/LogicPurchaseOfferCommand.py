import json

import Configuration
from Classes.Commands.LogicCommand import LogicCommand
from Classes.Messaging import Messaging
from Classes.Logic import RewardHelper
from Database.DatabaseHandler import DatabaseHandler


def _loadOffers():
    with open("shop.json", 'r', encoding='utf-8') as f:
        return json.load(f)['Offers']


def _catalogPrice(dataClass, itemID):
    """Цена товара каталога из CSV: (блинги, гемы)."""
    try:
        if dataClass == 29:
            from Classes.Files.Classes.Skins import Skins
            cost = Skins.getCostSkinByID(itemID)
        elif dataClass == 52:
            from Classes.Files.Classes.Pins import Emotes
            cost = Emotes.getCostPinsByID(itemID)
        elif dataClass == 68:
            from Classes.Files.Classes.Sprays import Sprays
            cost = Sprays.getCostSprayByID(itemID)
        elif dataClass == 28:
            from Classes.Files.Classes.PlayerThumbnails import PlayerThumbnails
            cost = PlayerThumbnails.getCostThumbnailsByID(itemID)
        else:
            return 0, 0
        return int(cost['Bling'] or 0), int(cost['Diamonds'] or 0)
    except Exception:
        return 0, 0


class LogicPurchaseOfferCommand(LogicCommand):
    def __init__(self, commandData):
        super().__init__(commandData)

    def encode(self, fields):
        LogicCommand.encode(self, fields)
        self.writeVInt(0)
        self.writeDataReference(0)
        return self.messagePayload

    def decode(self, calling_instance):
        fields = {}
        LogicCommand.decode(calling_instance, fields, False)
        fields["Unk1"] = calling_instance.readVInt()
        fields["Item"] = calling_instance.readDataReference()  # None, если это обычный оффер
        LogicCommand.parseFields(fields)
        return fields

    def execute(self, calling_instance, fields):
        db_instance = DatabaseHandler()
        player_data = json.loads(db_instance.getPlayerEntry(calling_instance.player.ID)[2])

        item = fields.get('Item')
        index = fields['Unk1']
        items = []

        if item is not None:
            # Покупка товара из каталога: скин / пин / спрей / иконка (класс 29 / 52 / 68 / 28)
            dataClass, itemID = item[0], item[1]

            if Configuration.settings.get('ChargeCatalog', False):
                bling, gems = _catalogPrice(dataClass, itemID)
                if bling > 0 and player_data.get('Blings', 0) >= bling:
                    player_data['Blings'] -= bling
                elif gems > 0 and player_data.get('Gems', 0) >= gems:
                    player_data['Gems'] -= gems
                elif bling > 0 or gems > 0:
                    print("[Purchase] не хватает валюты на", item)
                    return

            reward = RewardHelper.giveByDataRef(player_data, dataClass, itemID)
            if reward is None:
                return
            items.append(reward)
        else:
            # Обычный оффер из магазина: Unk1 - индекс в shop.json
            offers = _loadOffers()
            if not (0 <= index < len(offers)):
                print("[Purchase] нет оффера с индексом", index)
                return
            offer = offers[index]

            cost = int(offer.get('Cost', 0))
            field = RewardHelper.PRICE_FIELDS.get(offer.get('Currency', 0))
            if cost > 0 and field is not None:
                if player_data.get(field, 0) < cost:
                    print("[Purchase] не хватает", field, "на оффер", index)
                    return
                player_data[field] -= cost

            for rewardData in offer['Rewards']:
                itemID = rewardData['CsvID'][1] if rewardData['CsvID'][0] != 0 else rewardData.get('SkinID', 0)
                reward = RewardHelper.give(player_data, rewardData['ItemType'], rewardData['Amount'], itemID)
                if reward is not None:
                    items.append(reward)
            if not items:
                return

        RewardHelper.prepareDelivery(player_data, items)
        db_instance.updatePlayerData(player_data, calling_instance)

        fields["Socket"] = calling_instance.client
        fields["Command"] = {"ID": 203}
        fields["PlayerID"] = calling_instance.player.ID
        Messaging.sendMessage(24111, fields)

    def getCommandType(self):
        return 519
