from Classes.ByteStream import ByteStream
from Classes.Commands.LogicCommand import LogicCommand
from Classes.Messaging import Messaging
from Database.DatabaseHandler import DatabaseHandler
import json


class LogicPurchaseHeroLvlUpMaterialCommand(LogicCommand):

    def __init__(self, commandData):
        super().__init__(commandData)

    def decode(self, calling_instance):
        fields = {}
        LogicCommand.decode(calling_instance, fields, False)
        fields["BrawlerID"] = calling_instance.readDataReference()
        fields["ItemType"] = calling_instance.readDataReference()
        LogicCommand.parseFields(fields)
        return fields

    def encode(self, fields):
        pass

    def execute(self, calling_instance, fields):
        db_instance = DatabaseHandler()
        player_data = json.loads(db_instance.getPlayerEntry(calling_instance.player.ID)[2])
        
        brawler_id = str(fields["BrawlerID"][1])
        item_id = fields["ItemType"][1]
        item_type = fields["ItemType"][0] 

        # Цены согласно твоему конфигу:
        # 5  = Item (Звездная сила / Гаджет) -> Гаджет 1000, Пассивка 2000
        # 32 = GearToken / 33 = GearScrap (Снаряжение) -> 1000
        
        cost = 0

        # Если покупка проходит через тип 5 (Item), определяем гаджет или пассивка по ID или типу
        if item_type == 5:
            # Если передается ID, определяем стоимость (обычно в клиенте 5:X для гаджетов и пассивок)
            # Если разграничение идет по диапазону ID или дополнительному полю, можно подставить проверку.
            # По умолчанию: 1000 для гаджетов, 2000 для пассивок.
            cost = 1000 if item_id < 100 else 2000 
            
        elif item_type in [32, 33]:  # Снаряжения (Гиры)
            cost = 1000

        # Проверка баланса и выполнение покупки
        if brawler_id in player_data["OwnedBrawlers"] and cost > 0:
            if player_data.get("Coins", 0) >= cost:
                brawler_data = player_data["OwnedBrawlers"][brawler_id]

                # Покупка Предмета (Гаджет / Пассивка)
                if item_type == 5:
                    if cost == 1000:
                        if "Gadgets" not in brawler_data:
                            brawler_data["Gadgets"] = []
                        if item_id not in brawler_data["Gadgets"]:
                            player_data["Coins"] -= cost
                            brawler_data["Gadgets"].append(item_id)
                    else:
                        if "StarPowers" not in brawler_data:
                            brawler_data["StarPowers"] = []
                        if item_id not in brawler_data["StarPowers"]:
                            player_data["Coins"] -= cost
                            brawler_data["StarPowers"].append(item_id)

                # Покупка Гиров
                elif item_type in [32, 33]:
                    if "Gears" not in brawler_data:
                        brawler_data["Gears"] = []
                    if item_id not in brawler_data["Gears"]:
                        player_data["Coins"] -= cost
                        brawler_data["Gears"].append(item_id)

                db_instance.updatePlayerData(player_data, calling_instance)

    def getCommandType(self):
        return 521
