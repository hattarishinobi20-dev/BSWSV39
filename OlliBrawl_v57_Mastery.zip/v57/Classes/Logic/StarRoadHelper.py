# Общая логика Star Road (кого бойца открываем следующим за кредиты).
# 0 = все бойцы открыты -> в игре показывается слава (Glory).

LAST_BRAWLER = 85
SKIPPED = (32, 33, 55, 56)  # так же пропускает LogicClaimStarRoadCommand


def getStarRoadSequence():
    return [i for i in range(1, LAST_BRAWLER + 1) if i not in SKIPPED]


def getNextUnlockingBrawler(ownedBrawlers):
    """ownedBrawlers - ключи OwnedBrawlers (int или str). Возвращает ID следующего
    бойца за кредиты или 0, если открыты все."""
    owned = {int(k) for k in ownedBrawlers}
    for brawlerID in getStarRoadSequence():
        if brawlerID not in owned:
            return brawlerID
    return 0
