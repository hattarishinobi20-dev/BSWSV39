# Общая логика выдачи наград (магазин, каталог, Brawl Pass).
# Одна функция выдаёт предмет игроку (в словарь player_data) и возвращает
# предмет для окна наград: {'Amount', 'DataRef', 'RewardID'}.
#
# ItemType (тот же, что в milestones.csv / shop.json):
#   1 монеты | 3 бравлер | 4 и 24 скин | 16 гемы | 19 пин | 25 иконка профиля
#   35 спрей | 38 кредиты | 39 хроматические кредиты | 41 очки силы | 45 блинги
# Классы DataRef: 16 бравлер, 28 иконка профиля, 29 скин, 52 пин, 68 спрей

# ItemType -> (поле в аккаунте, RewardID для окна наград)
CURRENCY_ITEMS = {
    1: ("Coins", 7),
    16: ("Gems", 8),
    38: ("RareTokens", 22),
    39: ("ChromaticTokens", 23),
    41: ("PowerPoints", 24),
    45: ("Blings", 25),
}

# ItemType -> (класс DataRef, список в аккаунте, RewardID)
VANITY_ITEMS = {
    4: (29, "OwnedSkins", 9),
    24: (29, "OwnedSkins", 9),
    19: (52, "OwnedPins", 11),
    25: (28, "OwnedThumbnails", 11),
    35: (68, "OwnedSprays", 11),
}

# класс DataRef -> ItemType (для покупок из каталога)
CLASS_TO_ITEMTYPE = {29: 4, 52: 19, 28: 25, 68: 35, 16: 3}

# валюта оффера -> поле аккаунта (0 гемы, 1 монеты, 3 старпоинты)
PRICE_FIELDS = {0: "Gems", 1: "Coins", 3: "StarPoints"}


DEFAULT_BRAWLER = {'Trophies': 0, 'HighestTrophies': 0, 'MasteryPoints': 0, 'MasteryClaimed': 0,
                   'PowerLevel': 1, 'PowerPoints': 0, 'State': 2}


def _addUnique(player_data, key, value):
    if key not in player_data or player_data[key] is None:
        player_data[key] = []
    if value not in player_data[key]:
        player_data[key].append(value)


def _giveBrawler(player_data, brawlerID):
    from Classes.Files.Classes.Cards import Cards
    from Classes.Files.Classes.Characters import Characters
    from Classes.Logic.StarRoadHelper import getNextUnlockingBrawler

    if str(brawlerID) in player_data['OwnedBrawlers']:
        return
    cardID = Cards.getCardIdByName(Characters.getBrawlerNameByID(brawlerID))
    brawler = dict(DEFAULT_BRAWLER)
    brawler['CardID'] = cardID
    player_data['OwnedBrawlers'][str(brawlerID)] = brawler
    player_data['UnlockingBrawler'] = getNextUnlockingBrawler(player_data['OwnedBrawlers'])


def give(player_data, itemType, amount=1, itemID=0):
    """Выдаёт награду. Возвращает предмет для окна наград или None,
    если такой тип награды сервер не умеет выдавать."""
    if itemType in CURRENCY_ITEMS:
        field, rewardID = CURRENCY_ITEMS[itemType]
        player_data[field] = player_data.get(field, 0) + amount
        return {'Amount': amount, 'DataRef': [0, 0], 'RewardID': rewardID}

    if itemType in VANITY_ITEMS:
        dataClass, key, rewardID = VANITY_ITEMS[itemType]
        _addUnique(player_data, key, itemID)
        return {'Amount': 1, 'DataRef': [dataClass, itemID], 'RewardID': rewardID}

    if itemType == 3:
        _giveBrawler(player_data, itemID)
        return {'Amount': 1, 'DataRef': [16, itemID], 'RewardID': 1}

    print("[RewardHelper] неизвестный ItemType:", itemType)
    return None


def giveByDataRef(player_data, dataClass, itemID):
    """Выдача по ссылке (класс, id) - так приходят покупки из каталога."""
    itemType = CLASS_TO_ITEMTYPE.get(dataClass)
    if itemType is None:
        print("[RewardHelper] неизвестный класс DataRef:", dataClass)
        return None
    return give(player_data, itemType, 1, itemID)


def prepareDelivery(player_data, items):
    """Кладёт предметы в delivery_items как обычные награды (не Brawl Pass)."""
    player_data['RewardTrackType'] = 0
    player_data['BrawlPassSeason'] = 0
    player_data['RewardForRank'] = 0
    player_data['delivery_items'] = {'Boxes': [{'Type': 100, 'Items': items}]}
