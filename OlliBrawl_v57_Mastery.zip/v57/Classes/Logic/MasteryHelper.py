# Мастерство бойцов: уровни, награды и титулы.
# Данные берутся из csv_logic: mastery_levels.csv (пороги очков и награды по редкости),
# mastery_hero_confs.csv (эмодзи / иконка / титул каждого бойца), cards.csv (редкость бойца).
#
# Клиент забирает награды отдельной командой, ID которой в этом сервере неизвестен,
# поэтому награды выдаются автоматически: при входе, после боя и по коду MASTERY.

import csv
import traceback

from Classes.Logic import RewardHelper

CSV_DIR = "Classes/Files/assets/csv_logic/"

# Сколько очков даёт код MASTERY и максимальный уровень (порог 10 уровня = 24800)
MAX_MASTERY_POINTS = 24800

# Как показывать клиенту «забрано наград» (MasteryClaimed):
#   True  - номер последнего забранного уровня (полностью забрано = 10)
#   False - количество забранных наград, первый уровень наград не имеет (полностью забрано = 9)
# Если в игре у бойца всё равно горит «забрать» - переключи это значение.
CLAIMED_IS_LEVEL_NUMBER = False

RARITY_COLUMN = {"common": 0, "rare": 1, "super_rare": 2, "epic": 3, "mega_epic": 4, "legendary": 5, "chromatic": 6}
REWARD_ITEMTYPE = {"Coins": 1, "PowerPoints": 41, "Credits": 38, "Gems": 16, "Blings": 45}

_cache = {}


def _rows(name):
    with open(CSV_DIR + name, encoding="utf-8") as f:
        return [r for r in csv.reader(f)][2:]


def _load():
    if _cache:
        return _cache

    levels = []
    for r in _rows("mastery_levels.csv"):
        if not r or r[0] == "":
            continue
        rewards = []
        for i in range(7):  # Common .. Chromatic
            count, kind = r[3 + i * 2], r[4 + i * 2]
            rewards.append((int(count) if count else 0, kind))
        levels.append({"Level": int(r[1]), "Threshold": int(r[2]), "Rewards": rewards,
                       "Fallback": int(r[17]) if r[17] else 0})
    levels.sort(key=lambda x: x["Level"])

    rarity = {r[4]: r[21] for r in _rows("cards.csv") if r and r[0].endswith("_unlock")}
    confs = {r[0]: r for r in _rows("mastery_hero_confs.csv") if r}

    def index(name):
        result, n = {}, 0
        for r in _rows(name):
            if r and r[0] != "":
                result[r[0]] = n
                n += 1
        return result

    heroes = {}
    n = 0
    for r in _rows("characters.csv"):
        if not r or r[0] == "":
            continue
        if len(r) > 32 and r[32] == "Hero" and r[2].lower() != "true" and r[3] != "":
            heroes[n] = r[0]
        n += 1

    _cache.update({"levels": levels, "rarity": rarity, "confs": confs, "heroes": heroes,
                   "emotes": index("emotes.csv"), "icons": index("player_thumbnails.csv"),
                   "titles": index("player_titles.csv")})
    return _cache


def getLevel(points):
    """Уровень мастерства (1..10) по очкам."""
    level = 1
    for lvl in _load()["levels"]:
        if points >= lvl["Threshold"]:
            level = lvl["Level"]
    return level


def getBrawlerName(brawlerID):
    return _load()["heroes"].get(int(brawlerID))


def _claimedForClient(level):
    return level if CLAIMED_IS_LEVEL_NUMBER else max(0, level - 1)


def getTitleName(titleID):
    for name, i in _load()["titles"].items():
        if i == titleID:
            return name
    return None


def _grantVanity(player_data, kind, brawlerName, summary):
    """Эмодзи / иконка / титул бойца. Если уже есть - возвращаем False (будут монеты)."""
    data = _load()
    conf = data["confs"].get("Mastery" + brawlerName)
    if conf is None:
        return False

    if kind == "UniqueEmote":
        itemID = data["emotes"].get(conf[1])
        if itemID is None or itemID in player_data.get("OwnedPins", []):
            return False
        RewardHelper.give(player_data, 19, 1, itemID)
        summary["Emotes"] += 1
    elif kind == "UniquePlayerIcon":
        itemID = data["icons"].get(conf[2])
        if itemID is None or itemID in player_data.get("OwnedThumbnails", []):
            return False
        RewardHelper.give(player_data, 25, 1, itemID)
        summary["Icons"] += 1
    elif kind == "UniqueTitle":
        itemID = data["titles"].get(conf[3])
        titles = player_data.setdefault("OwnedTitles", [])
        if itemID is None or itemID in titles:
            return False
        titles.append(itemID)
        summary["Titles"] += 1
    else:
        return False
    return True


def claimPending(player_data):
    """Выдаёт награды за все достигнутые, но ещё не выданные уровни мастерства у всех бойцов.
    Меняет player_data (сохранять его должен вызывающий код).
    Возвращает (изменилось ли что-то, предметы для окна награды)."""
    try:
        data = _load()
        totals = {}
        summary = {"Emotes": 0, "Icons": 0, "Titles": 0}
        changed = False

        for key, brawler in player_data.get("OwnedBrawlers", {}).items():
            points = brawler.get("MasteryPoints", 0)
            level = getLevel(points)
            # 'MasteryRewardLevel' - до какого уровня награды уже выданы.
            # У старых аккаунтов поля нет - выдаём всё с 2 уровня (раньше забрать было нельзя).
            given = brawler.get("MasteryRewardLevel", 1)

            if level > given:
                name = getBrawlerName(key)
                rarityCol = RARITY_COLUMN.get(data["rarity"].get(name, "common"), 0)
                for lvl in data["levels"]:
                    if given < lvl["Level"] <= level:
                        count, kind = lvl["Rewards"][rarityCol]
                        if kind in REWARD_ITEMTYPE:
                            totals[kind] = totals.get(kind, 0) + count
                        elif kind and name and not _grantVanity(player_data, kind, name, summary):
                            # награда уже есть - вместо неё монеты
                            if lvl["Fallback"]:
                                totals["Coins"] = totals.get("Coins", 0) + lvl["Fallback"]
                brawler["MasteryRewardLevel"] = level
                changed = True

            claimed = _claimedForClient(level)
            if brawler.get("MasteryClaimed") != claimed:
                brawler["MasteryClaimed"] = claimed
                changed = True

        items = []
        for kind, amount in totals.items():
            item = RewardHelper.give(player_data, REWARD_ITEMTYPE[kind], amount)
            if item:
                items.append(item)
        if summary["Emotes"] or summary["Icons"] or summary["Titles"]:
            print("[Mastery] выдано:", summary)
        return changed, items
    except Exception:
        print(traceback.format_exc())
        return False, []


def giveMasteryPoints(player_data, points=MAX_MASTERY_POINTS):
    """Код MASTERY: всем имеющимся бойцам ставим не меньше `points` очков мастерства."""
    for brawler in player_data.get("OwnedBrawlers", {}).values():
        if brawler.get("MasteryPoints", 0) < points:
            brawler["MasteryPoints"] = points
