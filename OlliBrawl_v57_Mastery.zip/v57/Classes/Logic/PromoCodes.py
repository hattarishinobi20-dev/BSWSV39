import json
import random

from Classes.Logic import RewardHelper, MasteryHelper
from Classes.Logic.StarRoadHelper import getStarRoadSequence

# Коды лежат в promocodes.json. Type: Gems | Coins | Blings | Credits | RandomBrawlers | Mastery
TYPE_TO_ITEMTYPE = {"Gems": 16, "Coins": 1, "Blings": 45, "Credits": 38}

OK, NOT_FOUND, ALREADY_USED = 0, 1, 2


def _loadCodes():
    with open("promocodes.json", 'r', encoding='utf-8') as f:
        return {k.strip().upper(): v for k, v in json.load(f).items()}


def redeem(player_data, code):
    """Возвращает (статус, список предметов для окна награды).
    Меняет player_data, но не сохраняет его."""
    code = (code or "").strip().upper()
    promo = _loadCodes().get(code)
    if promo is None:
        return NOT_FOUND, []

    used = player_data.setdefault('UsedPromoCodes', [])
    if code in used:
        return ALREADY_USED, []

    items = []
    if promo['Type'] == 'RandomBrawlers':
        owned = {int(k) for k in player_data['OwnedBrawlers']}
        pool = [b for b in getStarRoadSequence() if b not in owned]
        for brawlerID in random.sample(pool, min(promo['Amount'], len(pool))):
            items.append(RewardHelper.give(player_data, 3, 1, brawlerID))
        # если новых бравлеров не хватило - добираем кредитами (500 за каждого)
        missing = promo['Amount'] - len(items)
        if missing > 0:
            items.append(RewardHelper.give(player_data, 38, 500 * missing))
    elif promo['Type'] == 'Mastery':
        # всем бойцам - очки мастерства, награды за уровни выдаём сразу
        MasteryHelper.giveMasteryPoints(player_data, promo['Amount'])
        changed, items = MasteryHelper.claimPending(player_data)
    else:
        items.append(RewardHelper.give(player_data, TYPE_TO_ITEMTYPE[promo['Type']], promo['Amount']))

    used.append(code)
    return OK, items
