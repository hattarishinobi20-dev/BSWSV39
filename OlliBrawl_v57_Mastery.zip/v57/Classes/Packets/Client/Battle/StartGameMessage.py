from Classes.Messaging import Messaging

from Classes.Packets.PiranhaMessage import PiranhaMessage


class StartGameMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0

    def encode(self, fields):
        pass

    def decode(self):
        fields = {}
        super().decode(fields)
        return fields

    def execute(message, calling_instance, fields):
        fields["Socket"] = calling_instance.client
        # каждый бой начинается с нулевого тика (раньше тик копился между боями)
        calling_instance.player.battleTick = 0
        fields['BattleTick'] = 20
        try:
            fields["ServerIP"] = calling_instance.client.getsockname()[0]
        except Exception:
            pass
        # Всё отправляется сразу одной пачкой, без пауз: загрузка -> UDP -> первые кадры
        Messaging.sendMessage(20559, fields, calling_instance.player)
        Messaging.sendMessage(24112, fields, calling_instance.player)
        for _ in range(3):
            Messaging.sendMessage(24109, fields, calling_instance.player)

    def getMessageType(self):
        return 14103

    def getMessageVersion(self):
        return self.messageVersion