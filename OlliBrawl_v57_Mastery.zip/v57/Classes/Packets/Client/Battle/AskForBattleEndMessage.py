import json
import Configuration
from Classes.Messaging import Messaging
from Classes.Packets.PiranhaMessage import PiranhaMessage
from Database.DatabaseHandler import DatabaseHandler
from Classes.Logic import MasteryHelper

OwnedBrawlersLatest = {
    0: {'CardID': 0, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    1: {'CardID': 4, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    2: {'CardID': 8, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    3: {'CardID': 12, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    4: {'CardID': 16, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    5: {'CardID': 20, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    6: {'CardID': 24, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    7: {'CardID': 28, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    8: {'CardID': 32, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    9: {'CardID': 36, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    10: {'CardID': 40, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    11: {'CardID': 44, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    12: {'CardID': 48, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    13: {'CardID': 52, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    14: {'CardID': 56, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    15: {'CardID': 60, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    16: {'CardID': 64, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    17: {'CardID': 68, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    18: {'CardID': 72, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    19: {'CardID': 95, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    20: {'CardID': 100, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    21: {'CardID': 105, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    22: {'CardID': 110, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    23: {'CardID': 115, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    24: {'CardID': 120, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    25: {'CardID': 125, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    26: {'CardID': 130, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    27: {'CardID': 177, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    28: {'CardID': 182, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    29: {'CardID': 188, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    30: {'CardID': 194, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    31: {'CardID': 200, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    32: {'CardID': 206, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    34: {'CardID': 218, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    35: {'CardID': 224, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    36: {'CardID': 230, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    37: {'CardID': 236, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    38: {'CardID': 279, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    39: {'CardID': 296, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    40: {'CardID': 303, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    41: {'CardID': 320, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    42: {'CardID': 327, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    43: {'CardID': 334, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    44: {'CardID': 341, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    45: {'CardID': 358, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    46: {'CardID': 365, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    47: {'CardID': 372, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    48: {'CardID': 379, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    49: {'CardID': 386, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    50: {'CardID': 393, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    51: {'CardID': 410, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    52: {'CardID': 417, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    53: {'CardID': 427, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    54: {'CardID': 434, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    56: {'CardID': 448, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    57: {'CardID': 466, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    58: {'CardID': 474, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    59: {'CardID': 491, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    60: {'CardID': 499, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    61: {'CardID': 507, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    62: {'CardID': 515, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    63: {'CardID': 523, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    64: {'CardID': 531, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    65: {'CardID': 539, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    66: {'CardID': 547, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    67: {'CardID': 557, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    68: {'CardID': 565, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    69: {'CardID': 573, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    70: {'CardID': 581, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    71: {'CardID': 589, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    72: {'CardID': 597, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    73: {'CardID': 605, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    74: {'CardID': 619, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    75: {'CardID': 633, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 11, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    76: {'CardID': 642, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    77: {'CardID': 655, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'Mastery': 0, 'ClaimRewardsMastery': 0},
    78: {'CardID': 663, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
    79: {'CardID': 671, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
    80: {'CardID': 730, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0},
    81: {'CardID': 748, 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2, 'Mastery': 0, 'ClaimRewardMastery': 0}
}


class AskForBattleEndMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0

    def encode(self, fields):
        pass

    def decode(self):
        fields = {}
        fields["Unk"] = self.readVInt()
        fields["Result"] = self.readVInt()
        fields["Rank"] = self.readVInt()
        fields["MapID"] = self.readDataReference()
        fields["HeroesCount"] = self.readVInt()
        fields["Heroes"] = []
        for i in range(fields["HeroesCount"]):
            fields["Heroes"].append({
                "Brawler": {
                    "ID": self.readDataReference(),
                    "SkinID": self.readDataReference()
                },
                "Team": self.readVInt(),
                "IsPlayer": self.readBoolean(),
                "PlayerName": self.readString()
            })
        super().decode(fields)
        return fields

    def execute(message, calling_instance, fields):
        db_instance = DatabaseHandler()
        player_data = json.loads(db_instance.getPlayerEntry(calling_instance.player.ID)[2])

        PlayersTeams = [heroEntry["Team"] for heroEntry in fields["Heroes"]]
        PlayerTeam = PlayersTeams[0] if PlayersTeams else 0
        PlayerTeamMembers = PlayersTeams.count(PlayerTeam)

        fields["PlayerThumbnail"] = player_data.get("Thumbnail", 0)
        fields["PlayerNamecolor"] = player_data.get("Namecolor", 0)
        fields["PlayerBPActivated"] = player_data.get("BPActivated", False)

        # Определение типа испытания
        if fields["MapID"][1] in Configuration.settings.get("ChallengeMaps", []):
            fields["ChallengeVariation"] = Configuration.settings.get("ChallengeVariation", -1)
        else:
            fields["ChallengeVariation"] = -1

        # Определение игрового режима и результата боя
        if fields["HeroesCount"] == 10 and PlayerTeamMembers == 2:
            fields["GameMode"] = 5  # Duo Showdown
            fields["Result"] = 0 if fields["Rank"] <= 2 else (2 if fields["Rank"] == 3 else 1)
        elif fields["HeroesCount"] == 10:
            fields["GameMode"] = 2  # Solo Showdown
            fields["Result"] = 0 if fields["Rank"] <= 4 else (2 if fields["Rank"] == 5 else 1)
        elif fields["HeroesCount"] == 3 and fields["MapID"][1] in [27, 29, 39, 68]:
            fields["GameMode"] = 3
        elif fields["HeroesCount"] == 3 and fields["MapID"][1] in [57, 67, 133]:
            fields["GameMode"] = 6
        elif fields["HeroesCount"] == 6 and fields["MapID"][1] in [21, 30, 65, 66, 119, 120]:
            fields["GameMode"] = 4
            if PlayerTeam == 1:
                fields["Result"] = 1 if fields["Result"] == 0 else (0 if fields["Result"] == 1 else 2)
                for heroEntry in fields["Heroes"]:
                    heroEntry["Team"] = 1 if heroEntry["Team"] == 0 else 0
        else:
            fields["GameMode"] = 1
            if PlayerTeam == 1:
                fields["Result"] = 1 if fields["Result"] == 0 else (0 if fields["Result"] == 1 else 2)
                for heroEntry in fields["Heroes"]:
                    heroEntry["Team"] = 1 if heroEntry["Team"] == 0 else 0

        # Сброс / Инициализация параметров
        fields["TokensGained"] = 0
        fields["TrophiesResult"] = 0
        fields["DoubleTokenEvent"] = 0
        fields["CoinShowEvent"] = 0
        fields["RewardTokens"] = 0
        fields["RewardCoins"] = 0
        fields["RewardGems"] = 0
        fields["RewardStarPoints"] = 0

        # --- ОБНОВЛЕНИЕ ТРОФЕЕВ И НАГРАД ---
        for heroEntry in fields["Heroes"]:
            if heroEntry["IsPlayer"]:
                brawler_id = heroEntry["Brawler"]["ID"][1]

                if brawler_id in OwnedBrawlersLatest:
                    target_card_id = OwnedBrawlersLatest[brawler_id]["CardID"]

                    for i, brawler in player_data["OwnedBrawlers"].items():
                        if brawler["CardID"] == target_card_id:
                            earned_trophies = 0
                            star_points = 0

                            if fields["ChallengeVariation"] == -1:  # Обычный бой
                                # Всегда выдавать 1000 токенов за катку
                                fields["TokensGained"] = 1000

                                if fields["Result"] == 0:    # ПОБЕДА
                                    earned_trophies = 1250
                                    brawler["MasteryPoints"] += 1000
                                    star_points = 20

                                elif fields["Result"] == 1:  # ПОРАЖЕНИЕ (СЛИВ)
                                    earned_trophies = -100

                                elif fields["Result"] == 2:  # НИЧЬЯ
                                    earned_trophies = 0

                                # Защита от ухода в минус по трофеям бравлера
                                if brawler["Trophies"] + earned_trophies < 0:
                                    earned_trophies = -brawler["Trophies"]

                                # Обновление бравлера
                                brawler["Trophies"] += earned_trophies
                                if brawler["Trophies"] > brawler["HighestTrophies"]:
                                    brawler["HighestTrophies"] = brawler["Trophies"]

                                # Обновление аккаунта
                                player_data["Trophies"] += earned_trophies
                                if player_data["Trophies"] < 0:
                                    player_data["Trophies"] = 0

                                if player_data["Trophies"] > player_data["HighestTrophies"]:
                                    player_data["HighestTrophies"] = player_data["Trophies"]

                                player_data["StarPoints"] += star_points
                                player_data["BPTokens"] += fields["TokensGained"]
                                fields["TrophiesResult"] = earned_trophies

                                # Начисление ELO только в ранговых режимах
                                if fields.get("IsRankedMode", False):
                                    if fields["Result"] == 0:
                                        player_data["Plpoints"] = player_data.get("Plpoints", 0) + 120
                                    elif fields["Result"] == 1:
                                        player_data["Plpoints"] = max(0, player_data.get("Plpoints", 0) - 60)

                            fields["Trophies"] = brawler["Trophies"]
                            fields["HighestTrophies"] = brawler["HighestTrophies"]
                            break

        # --- НАГРАДЫ МАСТЕРСТВА: новые уровни выдаём сразу ---
        MasteryHelper.claimPending(player_data)

        # --- СЧЁТЧИКИ ПОБЕД ДЛЯ ПРОФИЛЯ (сохраняются в аккаунте) ---
        if fields["ChallengeVariation"] == -1 and fields["Result"] == 0:
            if fields["GameMode"] == 2:      # Соло шоудаун
                player_data["soloWins"] = player_data.get("soloWins", 0) + 1
            elif fields["GameMode"] == 5:    # Дуо шоудаун
                player_data["duoWins"] = player_data.get("duoWins", 0) + 1
            else:                            # Командные режимы 3х3
                player_data["threeXthreeWins"] = player_data.get("threeXthreeWins", 0) + 1

        # --- ОБРАБОТКА ЛОГОВ И ЧЕЛЛЕНДЖЕЙ ---
        if "Logs" not in player_data:
            player_data["Logs"] = []

        fields["ChallengeReward"] = {}
        fields["ChallengeWin"] = 0
        fields["ChallengeLosses"] = 0

        if fields["ChallengeVariation"] == -1:
            log = {
                'Trophies': fields["TrophiesResult"],
                'Result': fields["Result"],
                'MapID': fields["MapID"],
                'ChallengeVariation': fields["ChallengeVariation"],
                'Number': len(player_data["Logs"]) + 1
            }
        else:
            log = {
                'Trophies': 0,
                'Result': fields["Result"],
                'MapID': fields["MapID"],
                'ChallengeVariation': fields["ChallengeVariation"],
                'Number': len(player_data["Logs"]) + 1
            }
            challenge = Configuration.settings.get("ChallengeLogicName", "")

            if fields["Result"] == 0 and challenge in player_data.get("Challenges", {}):
                if "Notifications" not in player_data:
                    player_data["Notifications"] = []

                for x in Configuration.settings.get("ChallengeRewards", []):
                    if x["Win"] == player_data["Challenges"][challenge]["Wins"]:
                        if x["Type"] in [1, 16, 17, 28]:
                            if x["Type"] == 1:
                                player_data["Coins"] += x["Amount"]
                                fields["RewardCoins"] += x["Amount"]
                            elif x["Type"] == 17:
                                player_data["StarPoints"] += x["Amount"]
                                fields["RewardStarPoints"] += x["Amount"]
                            elif x["Type"] == 16:
                                player_data["Gems"] += x["Amount"]
                                fields["RewardGems"] += x["Amount"]
                            elif x["Type"] == 28:
                                player_data["BPTokens"] += x["Amount"]
                                fields["RewardTokens"] += x["Amount"]

                        if x["Type"] in [19, 25, 4, 6, 14, 10]:
                            notification = {
                                "Type": 63, "Readed": False, "Timer": 999, "Text": "",
                                "Reward": {"Type": x["Type"], "Amount": x["Amount"], "Brawler": x["Brawler"], "Extra": x["Extra"]},
                                "ChallengeVariation": fields["ChallengeVariation"],
                                "Win": player_data["Challenges"][challenge]["Wins"],
                                "ChallengeName": Configuration.settings.get("ChallengeName", ""),
                                "Number": len(player_data["Notifications"]) + 1
                            }
                            player_data["Notifications"].append(notification)

                        fields["ChallengeWin"] = player_data["Challenges"][challenge]["Wins"]
                        fields["ChallengeReward"] = {"Type": x["Type"], "Amount": x["Amount"], "Brawler": x["Brawler"], "Extra": x["Extra"]}

            elif fields["Result"] == 1 and challenge in player_data.get("Challenges", {}):
                fields["ChallengeLosses"] = player_data["Challenges"][challenge]["Defeates"]

        player_data['Logs'].append(log)

        # Сохранение и отправка пакета
        db_instance.updatePlayerData(player_data, calling_instance)
        fields["Socket"] = calling_instance.client
        Messaging.sendMessage(23456, fields, calling_instance.player)

    def getMessageType(self):
        return 14110

    def getMessageVersion(self):
        return self.messageVersion

