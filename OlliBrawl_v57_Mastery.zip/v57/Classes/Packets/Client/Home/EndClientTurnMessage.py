from Classes.Logic.LogicCommandManager import LogicCommandManager
from Classes.Messaging import Messaging

from Classes.Packets.PiranhaMessage import PiranhaMessage
from Classes.Logic import RewardHelper

from Database.DatabaseHandler import DatabaseHandler
import json

class EndClientTurnMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0

    def encode(self, fields):
        pass

    def decode(self):
        fields = {}
        self.readBoolean()
        fields["Tick"] = self.readVInt()
        fields["Checksum"] = self.readVInt()
        fields["CommandsCount"] = self.readVInt()
        super().decode(fields)
        fields["Commands"] = []
        for i in range(fields["CommandsCount"]):
            fields["Commands"].append({"ID": self.readVInt()})
            if LogicCommandManager.commandExist(fields["Commands"][i]["ID"]):
                command = LogicCommandManager.createCommand(fields["Commands"][i]["ID"])
                print("Command", LogicCommandManager.getCommandsName(fields["Commands"][i]["ID"]))
                if command is not None:
                    fields["Commands"][i]["Fields"] = command.decode(self)
                    fields["Commands"][i]["Instance"] = command
            else:
                print(fields["Commands"][i]["ID"], ': Unknown')
                # Пишем неизвестные команды в файл: по ним можно узнать ID нужных команд клиента
                try:
                    with open("UnknownCommands.log", "a", encoding="utf-8") as log:
                        log.write(f'{fields["Commands"][i]["ID"]}: {bytes(self.messagePayload[self.offset:self.offset + 48]).hex()}\n')
                except Exception:
                    pass
        return fields

    def execute(message, calling_instance, fields):
        fields["Socket"] = calling_instance.client
        fields["PlayerID"] = calling_instance.player.ID
        db_instance = DatabaseHandler()
        player_data = json.loads(db_instance.getPlayerEntry(calling_instance.player.ID)[2])
        for command in fields["Commands"]:
            if "Instance" not in command.keys():
                return

            if hasattr(command["Instance"], 'execute'):
                command["Instance"].execute(calling_instance, command["Fields"])
            if command['ID'] == 571:
                # Starr Drop удалён: любое открытие даёт 1000 кредитов
                player_data = json.loads(db_instance.getPlayerEntry(calling_instance.player.ID)[2])
                reward = RewardHelper.give(player_data, 38, 1000)
                RewardHelper.prepareDelivery(player_data, [reward])
                db_instance.updatePlayerData(player_data, calling_instance)

                fields["Command"] = {"ID": 203}
                Messaging.sendMessage(24111, fields)

    def getMessageType(self):
        return 14102

    def getMessageVersion(self):
        return self.messageVersion