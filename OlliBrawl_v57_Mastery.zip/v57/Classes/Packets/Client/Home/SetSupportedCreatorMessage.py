import json

from Classes.Logic import PromoCodes, RewardHelper
from Classes.Messaging import Messaging
from Classes.Packets.PiranhaMessage import PiranhaMessage
from Database.DatabaseHandler import DatabaseHandler


class SetSupportedCreatorMessage(PiranhaMessage):
    """Поле ввода кода в магазине (Enter creator code) - используем как промокоды."""

    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0

    def encode(self, fields):
        pass

    def decode(self):
        fields = {}
        fields["Code"] = self.readString()
        super().decode(fields)
        return fields

    def execute(message, calling_instance, fields):
        db_instance = DatabaseHandler()
        player_data = json.loads(db_instance.getPlayerEntry(calling_instance.player.ID)[2])

        status, items = PromoCodes.redeem(player_data, fields["Code"])
        print("[Promo]", fields["Code"], "->", status)

        if status == PromoCodes.OK:
            RewardHelper.prepareDelivery(player_data, items)
            db_instance.updatePlayerData(player_data, calling_instance)

        Messaging.sendMessage(28686, {"Socket": calling_instance.client, "Code": fields["Code"],
                                      "Result": 1 if status == PromoCodes.OK else 0})

        if status == PromoCodes.OK:
            Messaging.sendMessage(24111, {"Socket": calling_instance.client, "Command": {"ID": 203},
                                          "PlayerID": calling_instance.player.ID})

    def getMessageType(self):
        return 18686

    def getMessageVersion(self):
        return self.messageVersion
