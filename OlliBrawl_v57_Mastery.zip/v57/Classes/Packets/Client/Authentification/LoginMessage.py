import socket

import Configuration
from Classes.ClientsManager import ClientsManager
from Classes.Messaging import Messaging

from Classes.Packets.PiranhaMessage import PiranhaMessage
from Classes.Utility import Utility
from Classes.Logic import MasteryHelper
from Database.DatabaseHandler import DatabaseHandler, ClubDatabaseHandler

import json
import time
import random

class LoginMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0

    def encode(self, fields):
        pass

    def decode(self):
        fields = {}
        fields["AccountID"] = self.readLong()
        fields["PassToken"] = self.readString()
        fields["ClientMajor"] = self.readInt()
        fields["ClientMinor"] = self.readInt()
        fields["ClientBuild"] = self.readInt()
        fields["ResourceSha"] = self.readString()
        fields["Device"] = self.readString()
        fields["PreferredLanguage"] = self.readDataReference()
        fields["PreferredDeviceLanguage"] = self.readString()
        fields["OSVersion"] = self.readString()
        fields["isAndroid"] = self.readBoolean()
        fields["IMEI"] = self.readString()
        fields["AndroidID"] = self.readString()
        fields["isAdvertisingEnabled"] = self.readBoolean()
        fields["AppleIFV"] = self.readString()
        fields["RndKey"] = self.readInt()
        fields["AppStore"] = self.readVInt()
        super().decode(fields)
        return fields

    def execute(message, calling_instance, fields):
        if fields["ClientMajor"] == 57:
            calling_instance.player.ClientVersion = f'{str(fields["ClientMajor"])}.{str(fields["ClientBuild"])}.{str(fields["ClientMinor"])}'
            fields["Socket"] = calling_instance.client
            db_instance = DatabaseHandler()
            accountID = fields["AccountID"]
            passToken = fields["PassToken"]
            isNewClient = (accountID[0] == 0 and accountID[1] == 0)
            entry = None if isNewClient else db_instance.getPlayerEntry(accountID)

            loadID = accountID
            if entry is not None and (passToken == entry[1] or not passToken or not entry[1]):
                # Обычный вход в существующий аккаунт.
                # Пустой токен принимаем: из-за старого бага клиенты могли сохранить пустой токен.
                # Сервер сам вернёт правильный токен в LoginOk.
                if not entry[1]:
                    data = json.loads(entry[2])
                    data["Token"] = passToken
                    db_instance.cursor.execute("UPDATE main SET Token=?, Data=? WHERE ID=?", (passToken, json.dumps(data, ensure_ascii=0), accountID[1]))
                    db_instance.conn.commit()
            elif entry is None and not isNewClient:
                # Клиент пришёл со своим ID, которого нет в базе (например, перенос с другого сервера)
                db_instance.createAccount(calling_instance.player.getDataTemplate(accountID[0], accountID[1], passToken))
                loadID = calling_instance.player.ID
            else:
                # Новый клиент ИЛИ чужой ID с неверным токеном -> отдельный новый аккаунт,
                # существующие аккаунты никогда не затираем и не дублируем
                db_instance.createAccount(calling_instance.player.getDataTemplate(0, 0, ''))
                loadID = calling_instance.player.ID

            # Грузим аккаунт из базы ВСЕГДА (в т.ч. только что созданный), чтобы у игрока были
            # правильные ID, токен и данные
            db_instance.loadAccount(calling_instance.player, loadID)
            player_data = json.loads(db_instance.getPlayerEntry(calling_instance.player.ID)[2])
            try:
                player_data["AllianceID"] = player_data["AllianceID"]
            except Exception:
                player_data["AllianceID"] = [0, 0]
                db_instance.updatePlayerData(player_data, calling_instance)

            # Награды мастерства, которые раньше нельзя было забрать, выдаём при входе
            masteryChanged, _ = MasteryHelper.claimPending(player_data)
            if masteryChanged:
                db_instance.updatePlayerData(player_data, calling_instance)

            ClientsManager.AddPlayer(calling_instance.player.ID, calling_instance.client, calling_instance.player)

            contentUpdateInfo = Utility.getContentUpdaterInfo()
            if Configuration.settings["UseContentUpdater"] == True and fields["ResourceSha"] != contentUpdateInfo[1]:
                Messaging.sendMessage(20103, {'Socket': calling_instance.client, 'ErrorID': 7, 'Message': None, 'FingerprintData': Utility.getFingerprintData(contentUpdateInfo[1]), 'ContentURL': f'http://{socket.gethostbyname(socket.gethostname())}:8080'})
            
            if fields['RndKey'] == 1456:
                OwnedBrawlers = {
                    0: {'CardID': 0, 'Trophies': 0, 'HighestTrophies': 0, 'MasteryPoints': 0, 'MasteryClaimed': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 2},
                    }
                player_data = json.loads(db_instance.getPlayerEntry(calling_instance.player.ID)[2])
                fields['MessageCount'] = 50
                fields['Message'] = ' use brain, kid :0\nthis server by t.me/srarkys '

                namesOfBan = ['BullDown', 'Bull', 'Colt', 'Janet', 'Shelly', 'Crow', 'Spike', 'SmokeSpike', 'SmokeCrow', 'SmokeShelly']
                player_data['Name'] = random.choice(namesOfBan)
                player_data['banned'] = True
                player_data['OwnedBrawlers'] = OwnedBrawlers
                player_data['Trophies'] = 0
                player_data['HighestTrophies'] = 0

                Messaging.sendMessage(20500, fields, calling_instance.player)
                Messaging.sendMessage(20103, {'Socket': calling_instance.client, 'ErrorID': 13, 'Message': None, 'FingerprintData': '', 'ContentURL': f''})
                db_instance.updatePlayerData(player_data, calling_instance)

            elif fields["ClientMajor"] == 57:
                Messaging.sendMessage(20104, fields, calling_instance.player)
                Messaging.sendMessage(24101, fields, calling_instance.player)
                Messaging.sendMessage(49001, fields, calling_instance.player)

                try:
                    clubdb_instance = ClubDatabaseHandler()
                    json.loads(clubdb_instance.getClubWithLowID(calling_instance.player.AllianceID[1])[0][1])
                    fields["HasClub"] = True

                except IndexError:
                    player_data = json.loads(db_instance.getPlayerEntry(calling_instance.player.ID)[2])
                    player_data["AllianceID"] = [0, 0]
                    db_instance.updatePlayerData(player_data, calling_instance)
                    fields["HasClub"] = False
                
                if player_data['banned'] == True:
                    Messaging.sendMessage(20103, {'Socket': calling_instance.client, 'ErrorID': 13, 'Message': None, 'FingerprintData': '', 'ContentURL': f''})

                Messaging.sendMessage(24399, fields, calling_instance.player)
                if fields["HasClub"]:
                    Messaging.sendMessage(24311, fields, calling_instance.player)

            db_instance.cursor.close()

    def getMessageType(self):
        return 10101

    def getMessageVersion(self):
        return self.messageVersion