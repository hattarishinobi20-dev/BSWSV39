from io import BytesIO

from Classes.ClientsManager import ClientsManager
from Classes.Files.Classes.Skins import Skins
from Classes.Packets.PiranhaMessage import PiranhaMessage


class StartLoadingMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0

    def getBattleHero(self, player):
        """Выбранный бравлер и подходящий ему скин (несовпадение вызывало вылет на загрузке)."""
        try:
            brawlerID = int(player.SelectedBrawlers[0])
        except Exception:
            brawlerID = 0
        if str(brawlerID) not in player.OwnedBrawlers and brawlerID not in player.OwnedBrawlers:
            brawlerID = 0
        skinID = None
        try:
            skinID = player.SelectedSkins.get(str(brawlerID))
        except Exception:
            pass
        if skinID is None:
            try:
                import csv
                with open('Classes/Files/assets/csv_logic/characters.csv') as f:
                    rows = list(csv.reader(f))
                default = rows[brawlerID + 2][35]
                skinID = Skins.getSkinIdByName(default)
            except Exception:
                skinID = 0
        return brawlerID, skinID

    def encode(self, fields, player):
        brawlerID, skinID = self.getBattleHero(player)
        self.writeInt(6) # Players Count
        self.writeInt(0)
        self.writeInt(0)

        self.writeInt(6) # Players Count
        # LogicPlayer::encode
        for index in range(6):
            self.writeInt(0)
            self.writeInt(player.ID[1])

            self.writeVInt(index) # Player Index
            teamIndex = 0
            if index > 2:
                teamIndex = 1
            self.writeVInt(teamIndex)
            self.writeVInt(0) # ?

            self.writeInt(0)

            self.writeBoolean(True)

            # Display Data тут блять

            self.writeDataReference(16, brawlerID) # brawlerID

            self.writeBoolean(False)
            self.writeBoolean(False)
            self.writeBoolean(False)

            self.writeDataReference(29, skinID) # skinID

            self.writeString(str(player.Name))
            self.writeVInt(0) # Experience
            self.writeVInt(28000000 + int(player.Thumbnail)) # ProfileIcon
            self.writeVInt(43000000 + int(player.Namecolor)) # Namecolor
            self.writeVInt(0) # Bpnamecolor

            self.writeBoolean(False) # ??
            self.writeVInt(0)

        self.writeInt(0) # LogicVector

        self.writeInt(0) # ?

        self.writeInt(0) # ?

        self.writeVInt(0) # gameModVariation
        self.writeVInt(1)
        self.writeVInt(1)

        self.writeBoolean(True) 

        self.writeVInt(0)
        self.writeVInt(0)

        self.writeDataReference(15, 7) # mapID

        self.writeBoolean(False) # PlayerMap
        self.writeBoolean(False) # Undergod
        self.writeBoolean(False) # Friendly Match

        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)

        self.writeVInt(0)

    def decode(self):
        fields = {}
        return {}

    def execute(message, calling_instance, fields):
        pass

    def getMessageType(self):
        return 20559

    def getMessageVersion(self):
        return self.messageVersion