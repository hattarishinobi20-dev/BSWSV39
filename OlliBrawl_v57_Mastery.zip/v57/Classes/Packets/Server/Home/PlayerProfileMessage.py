import datetime
import json
import traceback

from Classes.ClientsManager import ClientsManager
from Classes.Packets.PiranhaMessage import PiranhaMessage
from Classes.Wrappers.PlayerProfile import PlayerProfile
from Classes.Wrappers.AllianceHeaderEntry import AllianceHeaderEntry
from Database.DatabaseHandler import DatabaseHandler, ClubDatabaseHandler

# Показывать клуб игрока в профиле (значок и название клуба).
# Если у игрока в клубе профиль вдруг не открывается - поставь False.
PROFILE_SHOW_CLUB = True

PROFILE_STATUS_TEXT = "hello world"


class PlayerProfileMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0

    @staticmethod
    def _buildStats(playerData, brawlersCount):
        """Список (id статистики, значение). Все числа берутся из сохранённого аккаунта,
        а не из заглушек. ID статистик:
          1  победы 3х3            2  опыт                3  кубки
          4  рекорд кубков         5  открыто бойцов      11 победы соло
          12 победы дуо            20 кубки               24 очки ранговых боёв
          25 рекорд ранговых       27 год создания аккаунта
        """
        trophies = playerData.get('Trophies', 0)
        highest = max(playerData.get('HighestTrophies', 0), trophies)
        rankedPoints = playerData.get('Plpoints', 0)
        year = playerData.get('RegisterYear', 0) or datetime.datetime.now().year
        return [
            (1, playerData.get('threeXthreeWins', 0)),
            (2, playerData.get('Experience', 0)),
            (3, trophies),
            (4, highest),
            (5, brawlersCount),
            (11, playerData.get('soloWins', 0)),
            (12, playerData.get('duoWins', 0)),
            (20, trophies),
            (24, rankedPoints),
            (25, max(rankedPoints, playerData.get('RankedHighest', 0))),
            (27, year),
        ]

    def encode(self, fields):
        db_instance = DatabaseHandler()
        clubdb_instance = ClubDatabaseHandler()
        playerData = db_instance.getPlayer(fields["PlayerID"])

        if playerData is None:
            # Игрока с таким ID нет - показываем пустой профиль вместо падения сервера
            playerData = {'ID': list(fields["PlayerID"]), 'Name': 'Unknown', 'Thumbnail': 0, 'Namecolor': 0,
                          'favoriteBrawler': 0, 'OwnedBrawlers': {}, 'SelectedSkins': {}, 'AllianceID': [0, 0]}

        # ID берём из сохранённого аккаунта, а не из запроса клиента
        playerID = playerData.get('ID', fields["PlayerID"])
        ownedBrawlers = playerData.get('OwnedBrawlers', {})
        selectedSkins = playerData.get('SelectedSkins', {})

        self.writeVLong(playerID[0], playerID[1])
        self.writeDataReference(16, playerData.get('favoriteBrawler', 0)) # FavoriteBrawler

        sortedBrawlers = sorted(ownedBrawlers, key=lambda x: ownedBrawlers[x].get('Trophies', 0), reverse=True)
        self.writeVInt(len(sortedBrawlers))
        for brawler in sortedBrawlers:
            brawlerData = ownedBrawlers[brawler]
            self.writeDataReference(16, brawler)
            skinID = selectedSkins.get(str(brawler), 0)
            if skinID:
                self.writeDataReference(29, skinID) # скин бойца (иконка в профиле)
            else:
                self.writeDataReference(0)
            self.writeVInt(brawlerData.get('Trophies', 0)) # Trophies
            self.writeVInt(brawlerData.get('HighestTrophies', 0)) # Highest Trophies
            self.writeVInt(brawlerData.get('PowerLevel', 1)) # Power Level
            self.writeVInt(0) #

        stats = PlayerProfileMessage._buildStats(playerData, len(sortedBrawlers))
        self.writeVInt(len(stats))
        for statID, value in stats:
            self.writeDataReference(statID, value)

        self.writeString(playerData['Name'])  #PlayerInfo
        self.writeVInt(100)
        self.writeVInt(28000000 + playerData.get('Thumbnail', 0)) # иконка игрока
        self.writeVInt(43000000 + playerData.get('Namecolor', 0)) # цвет ника
        self.writeVInt(43000000)

        self.writeBoolean(False)

        self.writeString(PROFILE_STATUS_TEXT)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeDataReference(29, 0)
        self.writeDataReference(0)
        self.writeDataReference(0)
        self.writeDataReference(0)
        self.writeDataReference(0)

        clubData = None
        clubRole = 0
        allianceID = playerData.get('AllianceID', [0, 0])
        if PROFILE_SHOW_CLUB and allianceID and allianceID[1] != 0:
            try:
                clubRows = clubdb_instance.getClubWithLowID(allianceID[1])
                if clubRows:
                    clubData = json.loads(clubRows[0][1])
                    member = clubData.get('Members', {}).get(str(playerID[1]))
                    if member is None:
                        clubData = None
                    else:
                        clubRole = member.get('Role', 0)
            except Exception:
                print(traceback.format_exc())
                clubData = None

        if clubData is not None:
            self.writeBoolean(True) #alliance
            AllianceHeaderEntry.encode(self, clubdb_instance, clubData)
        else:
            self.writeBoolean(False) #alliance

        self.writeDataReference(25, clubRole) #alliance role
        self.writeVInt(1) # Ranks

    def decode(self):
        return {}

    def execute(message, calling_instance, fields):
        pass

    def getMessageType(self):
        return 24113

    def getMessageVersion(self):
        return self.messageVersion
