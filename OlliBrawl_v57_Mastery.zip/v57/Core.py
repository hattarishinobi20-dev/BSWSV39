import os
import threading
import Configuration
from Classes.ServerConnection import ServerConnection
from Static.StaticData import StaticData

print(r"""
    ____                      __   _____ __                 
   / __ )_________ __      __/ /  / ___// /_____ ___________
  / __  / ___/ __ `/ | /| / / /   \__ \/ __/ __ `/ ___/ ___/
 / /_/ / /  / /_/ /| |/ |/ / /   ___/ / /_/ /_/ / /  (__  ) 
/_____/_/   \__,_/ |__/|__/_/   /____/\__/\__,_/_/  /____/  
                                                            
    """)

if not os.path.exists(f"HexDumpV{Configuration.settings['DumpMajor']}"):
    os.mkdir(f"HexDumpV{Configuration.settings['DumpMajor']}")

StaticData.Preload()

# Чистим возможные дубли аккаунтов (остались от старого бага сохранений): оставляем самую первую запись каждого ID
try:
    from Database.DatabaseHandler import DatabaseHandler
    _db = DatabaseHandler()
    _db.cursor.execute("DELETE FROM main WHERE rowid NOT IN (SELECT MIN(rowid) FROM main GROUP BY ID)")
    _db.conn.commit()
    _db.conn.close()
except Exception as e:
    print("Проверка базы игроков:", e)

serverThread = threading.Thread(target=ServerConnection, args=(("0.0.0.0", 9339),), daemon=True)
serverThread.start()

# Админ-панель в консоли (Pydroid 3). Команды: /help
try:
    import AdminPanel
    AdminPanel.run()
except Exception as e:
    print("Админ-панель недоступна:", e)

# Если панель закрыта (/exit) - сервер продолжает работать
serverThread.join()
