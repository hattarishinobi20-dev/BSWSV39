import json
import sqlite3
import traceback
from Classes.Files.Classes.Regions import Regions

class DatabaseHandler():
    def __init__(self):
        # timeout - ждём, если база занята другим потоком (раньше это давало «database is locked»
        # и часть сохранений тихо терялась)
        self.conn = sqlite3.connect("Database/Files/player.sqlite", timeout=30, check_same_thread=False)
        self.cursor = self.conn.cursor()
        try:
            self.cursor.execute("""CREATE TABLE main (ID int, Token text, Data json)""")
            self.conn.commit()
        except sqlite3.OperationalError:
            pass
        except Exception:
            print(traceback.format_exc())

    def createAccount(self, data):
        try:
            # Никогда не создаём второй аккаунт с тем же ID - это и был баг «аккаунт не сохраняется»
            self.cursor.execute("SELECT 1 FROM main WHERE ID=?", (data["ID"][1],))
            if self.cursor.fetchone() is not None:
                return False
            self.cursor.execute("INSERT INTO main (ID, Token, Data) VALUES (?, ?, ?)", (data["ID"][1], data["Token"], json.dumps(data, ensure_ascii=0)))
            self.conn.commit()
            return True
        except Exception:
            print(traceback.format_exc())
            return False

    def getNextFreeID(self):
        try:
            self.cursor.execute("SELECT MAX(ID) FROM main")
            row = self.cursor.fetchone()
            biggest = row[0] if row and row[0] else 0
            return biggest + 1
        except Exception:
            print(traceback.format_exc())
            return 1

    def getAll(self):
        self.playersId = []
        try:
            self.cursor.execute("SELECT ID from main")
            self.playersId = [row[0] for row in self.cursor.fetchall()]
            return self.playersId
        except Exception:
            print(traceback.format_exc())
            return self.playersId

    def getLeaders(self):
        return self.getAll()

    def getPlayer(self, plrId):
        try:
            self.cursor.execute("SELECT * from main where ID=?", (plrId[1],))
            return json.loads(self.cursor.fetchall()[0][2])
        except IndexError:
            return None
        except Exception:
            print(traceback.format_exc())

    def getPlayerEntry(self, plrId):
        try:
            self.cursor.execute("SELECT * from main where ID=?", (plrId[1],))
            return self.cursor.fetchall()[0]
        except IndexError:
            pass
        except Exception:
            print(traceback.format_exc())

    def loadAccount(self, player, plrId):
        try:
            self.cursor.execute("SELECT * from main where ID=?", (plrId[1],))
            row = self.cursor.fetchall()[0]
            playerData = json.loads(row[2])
            g = playerData.get

            player.ID = list(playerData["ID"])
            # Токен обязательно грузим из базы - иначе клиент получает пустой токен и
            # при следующем входе сервер считает его новым игроком
            player.Token = g("Token", row[1])
            player.Name = g("Name", "Brawler")
            player.AllianceID = g("AllianceID", [0, 0])
            player.RoomID = g("RoomID", [0, 0])
            player.Registered = g("Registered", False)
            player.banned = g("banned", False)
            player.Vip = g("Vip", 0)
            player.Thumbnail = g("Thumbnail", 0)
            player.Namecolor = g("Namecolor", 0)
            player.Region = g("Region", "RU")
            player.ContentCreator = g("ContentCreator", "")
            player.Coins = g("Coins", 0)
            player.Gems = g("Gems", 0)
            player.StarPoints = g("StarPoints", 0)

            player.ChromaticTokens = g("ChromaticTokens", 0)
            player.RareTokens = g("RareTokens", 0)
            player.Blings = g("Blings", 0)
            player.UnlockingBrawler = g("UnlockingBrawler", 1)
            player.PowerPoints = g("PowerPoints", 0)

            player.Trophies = g("Trophies", 0)
            player.HighestTrophies = g("HighestTrophies", 0)
            player.TrophyRoadTier = g("TrophyRoadTier", 1)
            player.Experience = g("Experience", 0)
            player.Level = g("Level", 0)
            player.Tokens = g("Tokens", 0)
            player.TokensDoubler = g("TokensDoubler", 0)
            # BrawlPass
            player.BrawlPassFreeLevel = g("BrawlPassFreeLevel", [])
            player.BrawlPassLevel = g("BrawlPassLevel", [])
            player.BrawlPassPlusLevel = g("BrawlPassPlusLevel", [])

            player.RewardTrackType = g("RewardTrackType", 0)
            player.RewardForRank = g("RewardForRank", 0)
            player.BrawlPassSeason = g("BrawlPassSeason", 0)
            player.BrawlPassBuy = g("BrawlPassBuy", 2)
            player.BPTokens = g("BPTokens", 0)
            # Profiles
            player.favoriteBrawler = g("favoriteBrawler", 0)
            player.battleIcon = g("battleIcon", -1)
            player.battleIcon1 = g("battleIcon1", -1)
            player.battlePin = g("battlePin", -1)
            player.battleTitle = g("battleTitle", -1)
            player.threeXthreeWins = g("threeXthreeWins", 0)
            player.duoWins = g("duoWins", 0)
            player.soloWins = g("soloWins", 0)
            player.Plpoints = g("Plpoints", 0)
            player.RegisterYear = g("RegisterYear", 0)
            # Profiles End
            player.IntValueEntry = g("IntValueEntry", player.IntValueEntry)
            player.SelectedSkins = g("SelectedSkins", {'0': 0})
            player.SelectedBrawlers = g("SelectedBrawlers", [0, 1, 8])
            player.OwnedPins = g("OwnedPins", [])
            player.OwnedThumbnails = g("OwnedThumbnails", [])
            player.OwnedSprays = g("OwnedSprays", [])
            player.OwnedTitles = g("OwnedTitles", [])
            player.OwnedSkins = g("OwnedSkins", [])
            player.OwnedBrawlers = g("OwnedBrawlers", player.OwnedBrawlers)
            player.NotificationFactory = g("NotificationFactory", player.NotificationFactory)
        except Exception:
            print(traceback.format_exc())

    def updatePlayerData(self, data, calling_instance):
        try:
            self.cursor.execute("UPDATE main SET Data=? WHERE ID=?", (json.dumps(data, ensure_ascii=0), calling_instance.player.ID[1]))
            self.conn.commit()
            self.loadAccount(calling_instance.player, calling_instance.player.ID)
        except Exception:
            print(traceback.format_exc())

    def playerExist(self, loginToken, loginID):
        try:
            entry = self.getPlayerEntry(loginID)
            if entry is None:
                return False
            return loginToken == entry[1]
        except Exception:
            print(traceback.format_exc())
            return False

    def getSorted(self):
        a = []
        self.cursor.execute("SELECT * FROM main")
        this = self.cursor.fetchall()
        for db in this:
            data = json.loads(db[2])
            a.append(data)
        a = sorted(a, key=lambda x:x["Trophies"], reverse=True)
        return a

class TeamDatabaseHandler:
    def __init__(self):
        self.conn = sqlite3.connect("Database/Files/team.sqlite")
        self.cursor = self.conn.cursor()
        try:
            self.cursor.execute("""CREATE TABLE main (LowID integer, Data json)""")
        except:
            pass

    def createTeam(self, lowID, data):
        try:
            self.cursor.execute("INSERT INTO main (LowID, Data) VALUES (?, ?)",
                                (lowID, json.dumps(data, ensure_ascii=0)))
            self.conn.commit()
        except Exception as e:
            print(e)

    def deleteTeam(self, lowID):
        try:
            self.cursor.execute("DELETE FROM main where LowID=?", (lowID,))
            self.conn.commit()
        except Exception as e:
            print(e)

    def getDefaultPlayersData(self, player, king):
        return {'HighID': player.HighID, 'LowID': player.LowID, 'Name': player.Name, 'brawlerID': player.SelectedBrawlers[0], 'skinID': player.SelectedSkins, 'King': king, 'Trophies': player.trophies, 'NameColor': player.nameColor, 'Thumbnail': player.thumbnail}
    

    def getMembersSorted(self, clubdata):
        try:
            return sorted(clubdata['Members'].items(), key = lambda x: x[1]['Trophies'], reverse=True)
        except Exception as e:
            print(e)
    
    def updateTeamData(self, data, lowID):
        try:
            self.cursor.execute("UPDATE main SET Data=? WHERE LowID=?", (json.dumps(data, ensure_ascii=0), lowID))
            self.conn.commit()
        except Exception as e:
            print(e)

    def getTeamWithLowID(self, low):
        try:
            self.cursor.execute("SELECT * from main where LowID=?", (low,))
            return self.cursor.fetchall()
        except Exception as e:
            print(e)

class ClubDatabaseHandler:
    def __init__(self):
        self.conn = sqlite3.connect("Database/Files/club.sqlite")
        self.cursor = self.conn.cursor()
        try:
            self.cursor.execute("""CREATE TABLE main (LowID integer, Data json)""")
        except:
            pass

    def createClub(self, lowID, data):
        try:
            self.cursor.execute("INSERT INTO main (LowID, Data) VALUES (?, ?)",
                                (lowID, json.dumps(data, ensure_ascii=0)))
            self.conn.commit()
        except Exception as e:
            print(e)

    def deleteClub(self, lowID):
        try:
            self.cursor.execute("DELETE FROM main where LowID=?", (lowID,))
            self.conn.commit()
        except Exception as e:
            print(e)


    def getAllClub(self):
        clubs = []
        try:
            self.cursor.execute("SELECT * from main")
            self.db = self.cursor.fetchall()
            for i in range(len(self.db)):
                clubs.append(json.loads(self.db[i][1]))
            return clubs
        except Exception as e:
            print(e)

    def getAllClubByRegion(self, regionID):
        clubs = []
        try:
            self.cursor.execute("SELECT * from main")
            self.db = self.cursor.fetchall()
            for i in range(len(self.db)):
                dataLoaded = json.loads(self.db[i][1])
                if dataLoaded['RegionID'] == Regions.getIDByRegion(self, regionID):
                    clubs.append(dataLoaded)
            return clubs
        except Exception as e:
            print(traceback.format_exc())

    def getDefaultMembersData(self, player, role):
        return {'HighID': player.HighID, 'LowID': player.LowID, 'Name': player.Name, 'Role': role, 'Trophies': player.trophies, 'NameColor': player.nameColor, 'Thumbnail': player.thumbnail}

    def getDefaultMessageData(self, eventType, streamType, lastID, playerID, playerName, playerRole, target={}, msgData="", premadeID=-1, messageDataID=-1):
        return {'StreamType': eventType, 'EventType': streamType, 'StreamID': lastID, 'PlayerID': playerID, 'PlayerName': playerName, 'PlayerRole': playerRole, 'Message': msgData, 'Target': target, 'PremadeID': premadeID, 'MessageDataID': messageDataID}

    def getClubWithLowID(self, low):
        try:
            self.cursor.execute("SELECT * from main where LowID=?", (low,))
            return self.cursor.fetchall()
        except Exception as e:
            print(e)

    def getMembersSorted(self, clubdata):
        try:
            return sorted(clubdata['Members'].items(), key = lambda x: x[1]['Trophies'], reverse=True)
        except Exception as e:
            print(e)

    def getMemberWithLowID(self, clubData, playerLowID):
        try:
            return clubData["Members"][str(playerLowID)]
        except Exception as e:
            print(e)

    def getTotalTrophies(self, clubData):
        try:
            totalTrophies = 0
            for i in clubData["Members"].values():
                totalTrophies += i['Trophies']
            return totalTrophies
        except Exception as e:
            print(e)

    def LoadAccount(self, low, player):
        try:
            self.player = player
            self.cursor.execute("SELECT * from main where LowID=?", (low,))
            self.players = self.cursor.fetchall()
            self.players = json.loads(self.players[0][2])
        except Exception as e:
            print(e)

    def updateClubData(self, data, lowID):
        try:
            self.cursor.execute("UPDATE main SET Data=? WHERE LowID=?", (json.dumps(data, ensure_ascii=0), lowID))
            self.conn.commit()
        except Exception as e:
            print(e)