import csv
import json
import traceback

from Database.DatabaseHandler import DatabaseHandler
from Classes.Logic.StarRoadHelper import getNextUnlockingBrawler

CSV_DIR = "Classes/Files/assets/csv_logic/"

HELP = """
========== АДМИН ПАНЕЛЬ ==========
Формат: /команда <ID игрока> <значение>
  ID игрока - число из /players (или all - для всех игроков)
  Значение: 500 = добавить, -500 = отнять, =500 = установить ровно

  /players                        список игроков и их ID
  /gems <ID> <число>              гемы
  /coins <ID> <число>             монеты (в игре это очки силы)
  /powerpoints <ID> <число>       поле PowerPoints аккаунта
  /trophies <ID> <число> [бравлер]  трофеи (с бравлером - и ему тоже)
  /resettrophies <ID>             обнулить все трофеи (аккаунт и бойцы)
  /brawler <ID> <имя или id|all>  выдать бравлера
  /pin <ID> <имя или id>          выдать пин, например: /pin 6 smile

  /brawlers [часть имени]         список бравлеров с ID
  /pins [часть имени]             поиск пинов с ID
  /help                           это меню
  /exit                           закрыть панель (сервер продолжит работать)
==================================
"""


# ---------- Данные из CSV ----------

def loadBrawlers():
    """[(id, codename, itemname)] - реальные бравлеры."""
    result = []
    try:
        with open(CSV_DIR + "characters.csv") as f:
            rows = list(csv.reader(f))
        for i, r in enumerate(rows[2:]):
            if len(r) > 32 and r[32] == "Hero" and r[2].lower() != "true" and r[3] != "":
                result.append((i, r[0], r[3]))
    except Exception:
        print(traceback.format_exc())
    return result


def loadCards():
    """{'ShotgunGirl_unlock': cardID}"""
    cards = {}
    try:
        with open(CSV_DIR + "cards.csv") as f:
            rows = list(csv.reader(f))
        for i, r in enumerate(rows[2:]):
            if r and r[0] != "":
                cards[r[0]] = i
    except Exception:
        print(traceback.format_exc())
    return cards


def loadPins():
    """[(id, name)]"""
    pins = []
    try:
        with open(CSV_DIR + "emotes.csv") as f:
            rows = list(csv.reader(f))
        for i, r in enumerate(rows[2:]):
            if r and r[0] != "":
                pins.append((i, r[0]))
    except Exception:
        print(traceback.format_exc())
    return pins


BRAWLERS = loadBrawlers()
CARDS = loadCards()
PINS = loadPins()


# ---------- Поиск ----------

def findBrawler(query):
    q = query.lower()
    if q.isdigit():
        for b in BRAWLERS:
            if b[0] == int(q):
                return [b]
        return []
    exact = [b for b in BRAWLERS if q in (b[1].lower(), b[2].lower())]
    if exact:
        return exact
    return [b for b in BRAWLERS if q in b[1].lower() or q in b[2].lower()]


def findPin(query):
    q = query.lower()
    if q.isdigit():
        for p in PINS:
            if p[0] == int(q):
                return [p]
        return []
    exact = [p for p in PINS if p[1].lower() == q or p[1].lower() == "emoji_" + q]
    if exact:
        return exact
    return [p for p in PINS if q in p[1].lower()]


# ---------- Работа с базой ----------

def getPlayerIDs(db):
    return db.getAll() or []


def loadPlayer(db, lowID):
    entry = db.getPlayerEntry([0, lowID])
    if entry is None:
        return None
    return json.loads(entry[2])


def savePlayer(db, lowID, data):
    db.cursor.execute("UPDATE main SET Data=? WHERE ID=?", (json.dumps(data, ensure_ascii=0), lowID))
    db.conn.commit()
    pushToOnline(db, lowID)


def pushToOnline(db, lowID):
    """Если игрок сейчас в игре - обновляем его данные и отправляем ему главный экран заново,
    чтобы гемы, бравлеры и пины появились сразу, без перезахода."""
    try:
        from Classes.ClientsManager import ClientsManager
        from Classes.Messaging import Messaging
        online = ClientsManager.GetAll().get(lowID)
        if not online or online.get("Player") is None:
            return
        player = online["Player"]
        db.loadAccount(player, [0, lowID])
        Messaging.sendMessage(24101, {"Socket": online["Socket"]}, player)
        print(f"   (игрок {lowID} онлайн - данные обновлены в игре)")
    except Exception:
        print(traceback.format_exc())


def resolveTargets(db, arg):
    if arg.lower() == "all":
        return getPlayerIDs(db)
    if not arg.lstrip("-").isdigit():
        print("Неверный ID игрока:", arg)
        return []
    lowID = int(arg)
    if lowID not in getPlayerIDs(db):
        print(f"Игрок с ID {lowID} не найден. Список: /players")
        return []
    return [lowID]


def applyValue(current, text):
    """500 -> добавить, -500 -> отнять, =500 -> установить."""
    text = text.strip()
    if text.startswith("="):
        return int(text[1:])
    return current + int(text)


# ---------- Команды ----------

def cmdPlayers(db):
    ids = getPlayerIDs(db)
    if not ids:
        print("Игроков пока нет.")
        return
    print(f"{'ID':<10}{'Имя':<20}{'Трофеи':<9}{'Гемы':<8}{'Монеты':<8}Бравлеров")
    for lowID in ids:
        d = loadPlayer(db, lowID)
        if d:
            print(f"{lowID:<10}{str(d.get('Name', '')):<20}{d.get('Trophies', 0):<9}{d.get('Gems', 0):<8}{d.get('Coins', 0):<8}{len(d.get('OwnedBrawlers', {}))}")


def cmdNumeric(db, field, label, args):
    if len(args) < 2:
        print(f"Использование: /{label} <ID игрока|all> <число>")
        return
    try:
        int(args[1].lstrip("="))
    except ValueError:
        print("Значение должно быть числом.")
        return
    for lowID in resolveTargets(db, args[0]):
        d = loadPlayer(db, lowID)
        d[field] = max(0, applyValue(d.get(field, 0), args[1]))
        savePlayer(db, lowID, d)
        print(f"[{lowID}] {d['Name']}: {field} = {d[field]}")


def cmdTrophies(db, args):
    if len(args) < 2:
        print("Использование: /trophies <ID игрока|all> <число> [бравлер]")
        return
    try:
        int(args[1].lstrip("="))
    except ValueError:
        print("Значение должно быть числом.")
        return
    brawler = None
    if len(args) >= 3:
        found = findBrawler(args[2])
        if len(found) != 1:
            print("Бравлер не найден или найдено несколько. Смотри /brawlers")
            return
        brawler = found[0]
    for lowID in resolveTargets(db, args[0]):
        d = loadPlayer(db, lowID)
        if brawler is None:
            d["Trophies"] = max(0, applyValue(d["Trophies"], args[1]))
        else:
            b = d["OwnedBrawlers"].get(str(brawler[0]))
            if b is None:
                print(f"[{lowID}] у игрока нет бравлера {brawler[2]}. Сначала: /brawler {lowID} {brawler[0]}")
                continue
            old = b["Trophies"]
            b["Trophies"] = max(0, applyValue(old, args[1]))
            d["Trophies"] = max(0, d["Trophies"] + b["Trophies"] - old)
            b["HighestTrophies"] = max(b["HighestTrophies"], b["Trophies"])
        d["HighestTrophies"] = max(d["HighestTrophies"], d["Trophies"])
        savePlayer(db, lowID, d)
        print(f"[{lowID}] {d['Name']}: трофеи = {d['Trophies']}")


def cmdResetTrophies(db, args):
    if len(args) < 1:
        print("Использование: /resettrophies <ID игрока|all>")
        return
    for lowID in resolveTargets(db, args[0]):
        d = loadPlayer(db, lowID)
        d["Trophies"] = 0
        d["HighestTrophies"] = 0
        for b in d["OwnedBrawlers"].values():
            b["Trophies"] = 0
            b["HighestTrophies"] = 0
        savePlayer(db, lowID, d)
        print(f"[{lowID}] {d['Name']}: все трофеи обнулены")


def giveBrawler(d, brawler):
    key = str(brawler[0])
    if key in d["OwnedBrawlers"]:
        return False
    cardID = CARDS.get(brawler[1] + "_unlock")
    if cardID is None:
        print(f"Нет карточки для {brawler[1]}, пропуск.")
        return False
    d["OwnedBrawlers"][key] = {'CardID': cardID, 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0,
                               'MasteryPoints': 0, 'MasteryClaimed': 0, 'PowerLevel': 1,
                               'PowerPoints': 0, 'State': 2}
    return True


def cmdBrawler(db, args):
    if len(args) < 2:
        print("Использование: /brawler <ID игрока|all> <имя или id|all>")
        return
    if args[1].lower() == "all":
        chosen = BRAWLERS
    else:
        chosen = findBrawler(args[1])
        if not chosen:
            print("Бравлер не найден. Смотри /brawlers")
            return
        if len(chosen) > 1:
            print("Найдено несколько, уточни или укажи id:")
            for b in chosen:
                print(f"  {b[0]}: {b[2]} ({b[1]})")
            return
    for lowID in resolveTargets(db, args[0]):
        d = loadPlayer(db, lowID)
        added = [b for b in chosen if giveBrawler(d, b)]
        d["UnlockingBrawler"] = getNextUnlockingBrawler(d["OwnedBrawlers"])
        savePlayer(db, lowID, d)
        if not added:
            print(f"[{lowID}] {d['Name']}: уже есть.")
        elif len(added) == 1:
            print(f"[{lowID}] {d['Name']}: выдан бравлер {added[0][2]} (id {added[0][0]})")
        else:
            print(f"[{lowID}] {d['Name']}: выдано бравлеров: {len(added)}")
        if d["UnlockingBrawler"] == 0:
            print(f"   все бойцы открыты - вместо кредитов показывается слава")
        else:
            print(f"   кредиты теперь копятся на бойца id {d['UnlockingBrawler']}")


def cmdPin(db, args):
    if len(args) < 2:
        print("Использование: /pin <ID игрока|all> <имя или id>   например: /pin 6 smile")
        return
    found = findPin(" ".join(args[1:]))
    if not found:
        print("Пин не найден. Поиск: /pins <часть имени>")
        return
    if len(found) > 1:
        print("Найдено несколько пинов, укажи точное имя или id:")
        for p in found[:30]:
            print(f"  {p[0]}: {p[1]}")
        if len(found) > 30:
            print(f"  ... и ещё {len(found) - 30}")
        return
    pin = found[0]
    for lowID in resolveTargets(db, args[0]):
        d = loadPlayer(db, lowID)
        if pin[0] in d["OwnedPins"]:
            print(f"[{lowID}] {d['Name']}: пин {pin[1]} уже есть.")
            continue
        d["OwnedPins"].append(pin[0])
        savePlayer(db, lowID, d)
        print(f"[{lowID}] {d['Name']}: выдан пин {pin[1]} (id {pin[0]})")


def cmdList(items, query, fmt):
    q = query.lower()
    shown = [i for i in items if q in " ".join(str(x) for x in i).lower()]
    for i in shown[:60]:
        print(fmt(i))
    if len(shown) > 60:
        print(f"... показано 60 из {len(shown)}, уточни поиск")
    if not shown:
        print("Ничего не найдено.")


def handle(line):
    parts = line.strip().split()
    if not parts:
        return True
    cmd = parts[0].lower().lstrip("/")
    args = parts[1:]
    db = DatabaseHandler()
    try:
        if cmd in ("exit", "quit"):
            return False
        elif cmd in ("help", "menu", "?"):
            print(HELP)
        elif cmd == "players":
            cmdPlayers(db)
        elif cmd == "gems":
            cmdNumeric(db, "Gems", "gems", args)
        elif cmd in ("coins", "coin"):
            cmdNumeric(db, "Coins", "coins", args)
        elif cmd == "powerpoints":
            cmdNumeric(db, "PowerPoints", "powerpoints", args)
        elif cmd == "trophies":
            cmdTrophies(db, args)
        elif cmd == "resettrophies":
            cmdResetTrophies(db, args)
        elif cmd == "brawler":
            cmdBrawler(db, args)
        elif cmd == "pin":
            cmdPin(db, args)
        elif cmd == "brawlers":
            cmdList(BRAWLERS, " ".join(args), lambda b: f"  {b[0]}: {b[2]} ({b[1]})")
        elif cmd == "pins":
            cmdList(PINS, " ".join(args), lambda p: f"  {p[0]}: {p[1]}")
        else:
            print("Неизвестная команда. /help - список команд.")
    except Exception:
        print(traceback.format_exc())
    finally:
        try:
            db.conn.close()
        except Exception:
            pass
    return True


def run():
    print(HELP)
    while True:
        try:
            line = input("> ")
        except (EOFError, KeyboardInterrupt):
            break
        if not handle(line):
            break
