import struct


class BitStream:
    def __init__(self, data: bytes | int = 4096):
        if isinstance(data, (bytes, bytearray)):
            self._buf      = bytearray(data)
            self._length   = len(data)
            self._offset   = 0
            self._bit_off  = 0
            self._read_mode = True
        else:
            self._buf      = bytearray(data)
            self._length   = data
            self._offset   = 0
            self._bit_off  = 0
            self._read_mode = False

    def _ensure(self, n: int):
        need = self._offset + n
        if need > len(self._buf):
            self._buf += bytearray(max(n, len(self._buf)))

    def read_bit(self) -> int:
        if self._offset >= len(self._buf):
            return 0
        val = (self._buf[self._offset] >> self._bit_off) & 1
        self._bit_off += 1
        if self._bit_off == 8:
            self._bit_off = 0
            self._offset += 1
        return val

    def read_positive_int(self, bits: int) -> int:
        result = 0
        for i in range(bits):
            result |= self.read_bit() << i
        return result

    def read_int(self, bits: int) -> int:
        sign = self.read_positive_int(1)
        val  = self.read_positive_int(bits)
        return val if sign else -val

    def read_boolean(self) -> bool:
        return self.read_positive_int(1) == 1

    def read_positive_vint_max255(self) -> int:
        bits = self.read_positive_int(3)
        return self.read_positive_int(bits)

    def write_bit(self, bit: int):
        if self._bit_off == 0:
            self._offset += 1
            self._ensure(1)
            self._buf[self._offset - 1] = 0xFF
        val  = self._buf[self._offset - 1]
        val &= ~(1 << self._bit_off)
        val |= (bit & 1) << self._bit_off
        self._buf[self._offset - 1] = val
        self._bit_off = (self._bit_off + 1) % 8

    def write_positive_int(self, value: int, bits: int):
        v = value & 0xFFFFFFFF
        for i in range(bits):
            self.write_bit((v >> i) & 1)

    def write_int(self, value: int, bits: int):
        if value < 0:
            self.write_positive_int(0, 1)
            self.write_positive_int(-value, bits)
        else:
            self.write_positive_int(1, 1)
            self.write_positive_int(value, bits)

    def write_boolean(self, value: bool) -> bool:
        self.write_positive_int(1 if value else 0, 1)
        return value

    def write_positive_vint(self, value: int, bits: int):
        if value == 0:
            v3 = 1
        else:
            v3, tmp = 0, value
            while tmp:
                v3 += 1
                tmp >>= 1
        self.write_positive_int(v3 - 1, bits)
        self.write_positive_int(value, v3)

    def wpvint_often_zero(self, value: int, bits: int):
        if value == 0:
            self.write_positive_int(1, 1)
            return
        self.write_positive_int(0, 1)
        self.write_positive_vint(value, bits)

    def wpi1(self, v):    self.write_positive_int(v, 1)
    def wpi2(self, v):    self.write_positive_int(v, 2)
    def wpi3(self, v):    self.write_positive_int(v, 3)
    def wpi4(self, v):    self.write_positive_int(v, 4)
    def wpi5(self, v):    self.write_positive_int(v, 5)
    def wpi6(self, v):    self.write_positive_int(v, 6)
    def wpi7(self, v):    self.write_positive_int(v, 7)
    def wpi8(self, v):    self.write_positive_int(v, 8)
    def wpi9(self, v):    self.write_positive_int(v, 9)
    def wpi10(self, v):   self.write_positive_int(v, 10)
    def wpi11(self, v):   self.write_positive_int(v, 11)
    def wpi12(self, v):   self.write_positive_int(v, 12)
    def wpi13(self, v):   self.write_positive_int(v, 13)
    def wpi14(self, v):   self.write_positive_int(v, 14)
    def wpi15(self, v):   self.write_positive_int(v, 15)
    def wpi16(self, v):   self.write_positive_int(v, 16)
    def wpi17(self, v):   self.write_positive_int(v, 17)
    def wpi19(self, v):   self.write_positive_int(v, 19)
    def wpi21(self, v):   self.write_positive_int(v, 21)
    def wpi27(self, v):   self.write_positive_int(v, 27)
    def wi1(self, v):     self.write_int(v, 1)
    def wi3(self, v):     self.write_int(v, 3)
    def wi4(self, v):     self.write_int(v, 4)
    def wi7(self, v):     self.write_int(v, 7)
    def wi15(self, v):    self.write_int(v, 15)
    def wi16(self, v):    self.write_int(v, 16)
    def wpvint3(self, v): self.write_positive_vint(v, 3)
    def wpvint4(self, v): self.write_positive_vint(v, 4)
    def wpvint255(self, v):   self.write_positive_vint(v, 3)
    def wpvint65535(self, v): self.write_positive_vint(v, 4)
    def woften0_255(self, v):    self.wpvint_often_zero(v, 3)
    def woften0_65535(self, v):  self.wpvint_often_zero(v, 4)

    def to_bytes(self) -> bytes:
        return bytes(self._buf[:self._offset])

    def get_byte_array(self) -> bytes:
        return bytes(self._buf[:self._offset])

    def get_length(self) -> int:
        return self._offset
