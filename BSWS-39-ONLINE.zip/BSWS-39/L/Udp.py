import os
import socket
import threading

from L.BStream import Buf, Pkt

HOST        = "0.0.0.0"
PUBLIC_HOST = os.environ.get("UDPSRV_HOST", "")
PORT        = 9339
RAW_LOG     = 4

_socket    = None
_lock      = threading.Lock()
_counter   = 0
_sessions:  dict[int, object] = {}
_endpoints: dict[int, tuple]  = {}
_handlers:  dict[int, object] = {}
_unknown_seen: dict[int, tuple] = {}
_unknown_messages: dict[int, bool] = {}
_packet_log = 0
_raw_logged   = 0


def init():
    global _socket
    _socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    _socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    _socket.bind((HOST, PORT))
    threading.Thread(target=_listen, daemon=True).start()
    print(f"+ udp :{PORT}")
    hosts = [host for host in local_hosts() if not host.startswith("127.")]
    print(f"+ host :{', '.join(hosts) if hosts else '127.0.0.1'} (override: python Core.py <host> or UDPSRV_HOST)")
    if PUBLIC_HOST:
        print(f"+ udp host locked to {PUBLIC_HOST}")


def set_public_host(host: str):
    global PUBLIC_HOST
    if host:
        PUBLIC_HOST = host


def usable(host: str) -> bool:
    return bool(host) and not host.startswith("127.") and not host.startswith("169.254.")


def local_ip() -> str:
    probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        probe.connect(("8.8.8.8", 80))
        return probe.getsockname()[0]
    except OSError:
        return ""
    finally:
        probe.close()


def local_hosts() -> list:
    hosts = []
    for host in (local_ip(),):
        if host:
            hosts.append(host)
    try:
        for host in socket.gethostbyname_ex(socket.gethostname())[2]:
            if host not in hosts:
                hosts.append(host)
    except OSError:
        pass
    return hosts


def host_for(remote_ip: str) -> str:
    probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        probe.connect((remote_ip, 1))
        return probe.getsockname()[0]
    except OSError:
        return ""
    finally:
        probe.close()


def public_host(connection) -> str:
    if PUBLIC_HOST:
        return PUBLIC_HOST

    address = getattr(connection, 'address', None)
    if address and not address[0].startswith("127."):
        host = host_for(address[0])
        if host:
            return host

    host = local_ip()
    if usable(host):
        return host

    return "127.0.0.1" 


def create_session() -> int:
    global _counter
    with _lock:
        _counter += 1
        return _counter


def register(session_id: int, connection):
    with _lock:
        _sessions[session_id] = connection
        _endpoints.pop(session_id, None)


def unregister(session_id: int):
    with _lock:
        _sessions.pop(session_id, None)
        _endpoints.pop(session_id, None)


def is_connected(session_id: int) -> bool:
    return session_id in _endpoints


def register_handler(message_id: int, handler):
    _handlers[message_id] = handler


def bind_unknown(address):
    remote_ip = address[0]
    candidate = None
    for session_id, connection in _sessions.items():
        if session_id in _endpoints:
            continue
        if getattr(connection, 'address', None) is None:
            continue
        if connection.address[0] != remote_ip:
            continue
        if candidate is not None:
            return None
        candidate = session_id
    if candidate is None:
        return None
    connection = _sessions[candidate]
    _endpoints[candidate] = address
    return connection


def is_registered(session_id: int) -> bool:
    return session_id in _endpoints


def send(message, session_id: int, endpoint=None):
    target = endpoint if endpoint is not None else _endpoints.get(session_id)
    if target is None or _socket is None:
        return False

    message.encode()
    frame = Pkt(None)
    frame.wlong(0, session_id)
    frame.wi16(0)
    frame.wvint(message.id)
    frame.wvint(len(message.buffer))
    frame.buffer += message.buffer

    try:
        _socket.sendto(frame.buffer, target)
    except OSError:
        return False
    return True


def _listen():
    global _raw_logged
    while True:
        try:
            data, address = _socket.recvfrom(2048)
        except OSError:
            continue
        if _raw_logged < RAW_LOG:
            _raw_logged += 1
            print(f"? udp raw len={len(data)} {address[0]}:{address[1]} {data[:32].hex()}")
        if len(data) < 12:
            continue
        try:
            _handle(data, address)
        except Exception as exc:
            print(f"[UDP] {exc}")


def _handle(data: bytes, address):
    global _packet_log
    session_id = int.from_bytes(data[0:8], 'big')

    with _lock:
        connection = _sessions.get(session_id)
        if connection is None:
            connection = bind_unknown(address)
            if connection is None:
                if session_id not in _unknown_seen:
                    _unknown_seen[session_id] = address
                    print(f"? udp session={session_id} {address[0]}:{address[1]}")
                return
            _sessions[session_id] = connection
            _endpoints[session_id] = address
            print(f"~ udp bound session={session_id} {address[0]}:{address[1]}")
        else:
            new_endpoint = session_id not in _endpoints
            _endpoints[session_id] = address
            if new_endpoint:
                print(f"+ udp session={session_id} {address[0]}:{address[1]}")

    buf = Buf(data[10:])
    try:
        message_id = buf.rvint()
        length     = buf.rvint()
    except Exception:
        return

    payload = buf.read(length)

    if _packet_log < 20:
        _packet_log += 1
        print(f"+ udp in session={session_id} id={message_id} len={length} {address[0]}:{address[1]}")

    handler = _handlers.get(message_id)
    if handler is None:
        if message_id not in _unknown_messages:
            _unknown_messages[message_id] = True
            print(f"? udp msg id={message_id} len={length} payload={payload[:48].hex()}")
        return
    try:
        message = handler(connection, payload)
        message.decode()
        message.process()
    except Exception as exc:
        print(f"[UDP] {message_id}: {exc}")
