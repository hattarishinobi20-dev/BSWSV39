from L.BStream import Buf


class RequestLatencyTestStatusMessage(Buf):
    id = 19004

    def __init__(self, connection, header_bytes):
        super().__init__(header_bytes)
        self.connection = connection

    def decode(self):
        self.status = self.rvint()

    def process(self):
        pass
