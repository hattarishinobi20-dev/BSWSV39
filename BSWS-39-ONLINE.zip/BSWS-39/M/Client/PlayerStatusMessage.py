from L.BStream import Buf


class PlayerStatusMessage(Buf):
    id = 14366

    def __init__(self, connection, header_bytes):
        super().__init__(header_bytes)
        self.connection = connection

    def decode(self):
        self.status = self.rvint()

    def process(self):
        if self.status < 0:
            return
        self.connection.player_status = self.status
