from L.BStream import Buf
from M.Server.SeasonRewardsMessage import SeasonRewardsMessage


class GetSeasonRewardsMessage(Buf):
    id = 14277

    def __init__(self, connection, header_bytes):
        super().__init__(header_bytes)
        self.connection = connection

    def decode(self):
        pass

    def process(self):
        SeasonRewardsMessage(self.connection).send(0)
