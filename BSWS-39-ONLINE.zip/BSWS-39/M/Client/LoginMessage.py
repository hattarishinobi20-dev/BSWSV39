from M.Server.LoginOkMessage import LoginOkMessage
from M.Server.OwnHomeDataMessage import OwnHomeDataMessage

from L.BStream import Buf


class Device:
    major = 39
    minor = 0
    build = 0


class LoginMessage(Buf):
    def __init__(self, client, header_bytes):
        super().__init__(header_bytes)
        self.client = client
        self.encrypted = False

    def decode(self):
        try:
            self.rint()
            self.rint()
            self.rstr()

            self.device = Device()
            self.device.major = self.rint()
            self.device.minor = self.rint()
            self.device.build = self.rint()
            if self.device.major == 0:
                self.device.major = 39
        except:
            self.encrypted = True

    def process(self):
        if self.encrypted == False:
            if self.device.major == 39:
                LoginOkMessage(self.client).send(0, 2)
                OwnHomeDataMessage(self.client).send(0)
            else:
                print(f"? version {self.device.major}.{self.device.minor}.{self.device.build}")
