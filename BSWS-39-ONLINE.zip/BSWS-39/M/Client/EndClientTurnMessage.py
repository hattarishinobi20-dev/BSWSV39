from L.BStream import Buf

from M.Server.OwnHomeDataMessage import OFFERS, OwnHomeDataMessage


class EndClientTurnMessage(Buf):
    def __init__(self, connection, header_bytes):
        super().__init__(header_bytes)
        self.connection = connection

    def decode(self):
        self.rbool()
        self.tick     = self.rvint()
        self.checksum = self.rvint()
        count         = self.rvint()
        self.commands = []

        for _ in range(count):
            command_type = self._command_type()
            if command_type is None:
                break
            index = self._command_offer_index(command_type)
            self.commands.append((command_type, index))

    def _command_type(self):
        try:
            return self.rvint()
        except IndexError:
            return None

    def _command_offer_index(self, command_type: int) -> int:
        for _ in range(4):
            self.rvint()
        if command_type != 519:
            return -1
        try:
            index    = self.rvint()
            class_id = self.rvint()
            if class_id > 0:
                self.rvint()
            return index
        except IndexError:
            return -1

    def process(self):
        for command_type, index in self.commands:
            if command_type != 519 or index < 0 or index >= len(OFFERS):
                continue
            purchased = getattr(self.connection, 'purchased_offers', None)
            if purchased is None:
                purchased = set()
                self.connection.purchased_offers = purchased
            purchased.add(index)
            print(f"+ offer purchased index={index}")
            OwnHomeDataMessage(self.connection).send(0)
