from L.BStream import Buf
import L.Udp as Udp
from M.Battle.VisionUpdateMessage import UdpConnectionInfoMessage


class ClientInfoMessage(Buf):
    id = 10177

    def __init__(self, connection, header_bytes):
        super().__init__(header_bytes)
        self.connection = connection

    def decode(self):
        pass

    def process(self):
        UdpConnectionInfoMessage(
            client         = self.connection.client,
            server_port    = Udp.PORT,
            server_address = Udp.public_host(self.connection),
            session_id     = self.connection.udp_session_id,
        ).send(0)
        print(f"+ udp info session={self.connection.udp_session_id} host={Udp.public_host(self.connection)} port={Udp.PORT}")
