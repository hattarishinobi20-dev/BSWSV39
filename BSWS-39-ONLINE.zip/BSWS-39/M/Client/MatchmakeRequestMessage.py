from L.BStream import Buf
import G.Matchmaking as Matchmaking


class MatchmakeRequestMessage(Buf):
    def __init__(self, connection, header_bytes):
        super().__init__(header_bytes)
        self.connection = connection

    def decode(self):
        self.rvint()
        self.character_instance = self.rvint()
        self.rvint()
        self.event_slot = self.rvint()

    def process(self):
        self.connection.character_global_id = 16000000 + self.character_instance
        Matchmaking.request(self.connection, self.event_slot)
