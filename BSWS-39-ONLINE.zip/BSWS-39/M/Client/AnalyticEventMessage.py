from L.BStream import Buf


class AnalyticEventMessage(Buf):
    id = 10110

    def __init__(self, connection, header_bytes):
        super().__init__(header_bytes)
        self.connection = connection

    def decode(self):
        pass

    def process(self):
        pass
