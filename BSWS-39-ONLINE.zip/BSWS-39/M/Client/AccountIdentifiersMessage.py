from L.BStream import Buf


class AccountIdentifiersMessage(Buf):
    id = 10111

    def __init__(self, connection, header_bytes):
        super().__init__(header_bytes)
        self.connection = connection

    def decode(self):
        self.identifier = self.rstr()

    def process(self):
        pass
