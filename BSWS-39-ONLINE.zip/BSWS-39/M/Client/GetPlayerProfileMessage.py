from M.Server.PlayerProfileMessage import PlayerProfileMessage
from L.BStream import Buf


class GetPlayerProfileMessage(Buf):
    def __init__(self, client, header_bytes):
        super().__init__(header_bytes)
        self.client = client

    def decode(self):
        self.playerID = self.rlong()

    def process(self):
        PlayerProfileMessage(self.client, self).send(self.playerID[1])
