from L.BStream import Pkt


class MatchMakingStatusMessage(Pkt):
    id      = 20405
    version = 0

    def __init__(self, client, seconds: int, found: int, max_players: int):
        super().__init__(client)
        self.seconds     = seconds
        self.found       = found
        self.max_players = max_players

    def encode(self):
        self.wint(self.seconds)
        self.wint(self.found)
        self.wint(self.max_players)
        self.wint(0)
        self.wint(0)
        self.wbool(True)
