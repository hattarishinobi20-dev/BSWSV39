from L.BStream import Pkt


class MatchMakingCancelledMessage(Pkt):
    id      = 20406
    version = 0

    def encode(self):
        pass
