from L.BStream import Pkt
from L.BitStream import BitStream


class VisionUpdateMessage(Pkt):
    id      = 24109
    version = 4

    def __init__(self, client, tick: int, handled_inputs: int,
                 viewers: int, vision_bs: BitStream):
        super().__init__(client)
        self.tick           = tick
        self.handled_inputs = handled_inputs
        self.viewers        = viewers
        self.vision_bs      = vision_bs

    def encode(self):
        self.wvint(self.tick)
        self.wvint(self.handled_inputs)
        self.wvint(0)
        self.wvint(self.viewers)
        self.wbool(False)

        data   = self.vision_bs.get_byte_array()
        length = self.vision_bs.get_length()
        self.wint(length)
        self.buffer += data[:length]


class UdpConnectionInfoMessage(Pkt):
    id      = 24112
    version = 0

    def __init__(self, client, server_port: int = 9339,
                 server_address: str = "127.0.0.1",
                 session_id: int = 0):
        super().__init__(client)
        self.server_port    = server_port
        self.server_address = server_address
        self.session_id     = session_id

    def encode(self):
        self.wvint(self.server_port)
        self.wstr(self.server_address)
        self.wint(10)
        self.wlong(0, self.session_id)
        self.wi16(0)
        self.wint(0)
