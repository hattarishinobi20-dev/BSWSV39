from L.BStream import Pkt

LOBBY_DATA = "\nBSWS-39\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nhi"


class LobbyInfoMessage(Pkt):
    id      = 23457
    version = 0

    def __init__(self, client):
        super().__init__(client)

    def encode(self):
        from G import Sessions

        self.wvint(Sessions.count())
        self.wstr(LOBBY_DATA)
        self.wvint(0)
