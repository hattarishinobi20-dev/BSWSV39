from L.BStream import Pkt

class LoginOkMessage(Pkt):
    id     = 20104
    version = 1

    def encode(self):
        self.wlong(0, 1)
        self.wlong(0, 1)
        self.wstr("")
        self.wstr()
        self.wstr()
        self.wint(39)
        self.wint(110)
        self.wint(1)
        self.wstr('prod')
        self.wint(0)
        self.wint(0)
        self.wint(0)
        self.wstr()
        self.wstr()
        self.wstr()
        self.wint(0)
        self.wstr()
        self.wstr('CA')
        self.wstr()
        self.wint(2)
        self.wstr()

        self.wint(2)
        self.wstr('https://game-assets.brawlstarsgame.com')
        self.wstr('http://a678dbc1c015a893c9fd-4e8cc3b1ad3a3c940c504815caefa967.r87.cf2.rackcdn.com')

        self.wint(2)
        self.wstr('https://event-assets.brawlstars.com')
        self.wstr('https://24b999e6da07674e22b0-8209975788a0f2469e68e84405ae4fcf.ssl.cf2.rackcdn.com/event-assets')

        self.wvint(0)
        self.wstrz(b'')
        self.wbool(True)
        self.wstr()
        self.wstr()
        self.wstr()
        self.wstr('https://play.google.com/store/apps/details?id=com.supercell.brawlstars')
        self.wstr()
        self.wbool(False)