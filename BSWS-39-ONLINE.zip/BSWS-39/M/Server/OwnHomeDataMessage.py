from L.BStream import Pkt

OFFERS = (
    (0,  (14, 3,  0, 0),       0,  49, 120, 0, False, "БОЛЬШОЙ ЯЩИК x3",  "offer_bgr_vp"),
    (1,  (10, 5,  0, 0),       0, 299, 999, 1, False, "МЕГА НАБОР",       "offer_punk"),
    (2,  (1, 50000, 0, 0),     0,  50, 140, 1, False, "МОНЕТЫ x50000",    "offer_bgr_vp"),
    (3,  (16, 10000, 0, 0),    0,   0,   0, 2, True,  "ГЕМЫ БЕСПЛАТНО",  "offer_bgr_xmas23"),
)


class OwnHomeDataMessage(Pkt):
    id = 24101

    def __init__(self, connection):
        super().__init__(connection)
        self.connection = connection

    def encode(self):
        self.wvint(0)
        self.wvint(0)

        # LogicClientHome
        # LogicDailyData
        self.wvint(0) 
        self.wvint(0)
        self.wvint(13)
        self.wvint(1337)
        self.wvint(1338)
        self.wvint(465)
        self.wvint(0)
        self.wref(28, 0)   # Player icon
        self.wref(43, 4)

        # Array
        self.wvint(0)

        # Selected Skins (brawler 0 → skin 0 BanditGirlDefault, brawler 1 → skin 1 GunSlingerDefault)
        selectedSkins = [0, 1]
        self.wvint(len(selectedSkins))
        for v in selectedSkins:
            self.wref(29, v)  # SkinID

        # Skin Selected For Random Skin
        allSkins = [0, 1]
        self.wvint(len(allSkins))
        for i in allSkins:
            self.wref(29, i)

        # Current Random Skin
        self.wvint(0)
        for i in range(0):
            self.wref(29, 0)  # SkinID

        # Selected Group Skin
        self.wvint(0)  # Skin Count

        # Unlocked Skin
        self.wvint(len(allSkins))
        for i in allSkins:
            self.wref(29, i)

        # Unlocked Skin Purchase Option
        self.wvint(0)
        for i in range(0):
            self.wref(29, 0)  # SkinID

        # New Item
        self.wvint(0)
        for i in range(0):
            self.wref(23, 0)  # ItemID

        self.wvint(0)   # Leaderboard Region | 0 = Global, 1 = Asia
        self.wvint(0)   # Trophy Road Highest Trophies
        self.wvint(0)
        self.wvint(1)
        self.wbool(False)
        self.wvint(0)   # Tokens Doubler
        self.wvint(0)
        self.wvint(0)
        self.wvint(0)

        # ForcedDrops
        self.wvint(0)  # Starpower Drop
        self.wvint(0)  # Gadget Drop
        self.wvint(5)  # Rarity Count
        self.wvint(0)  # Rare Drop
        self.wvint(0)  # Super Rare Drop
        self.wvint(0)  # Epic Drop
        self.wvint(0)  # Mythic Drop
        self.wvint(0)  # Legendary Drop

        self.wbyte(4)   # Shop Token Doubler
        self.wvint(2)   # Token Doubler New Tag State
        self.wvint(2)   # Event Tickets New Tag State
        self.wvint(2)   # Coin Packs New Tag State
        self.wvint(0)   # Change Name Cost
        self.wvint(0)   # Timer For the Next Name Change

        self.wvint(len(OFFERS))   # Shop Offers

        purchased_offers = getattr(self.connection, 'purchased_offers', ())

        for index, items, currency, cost, old_cost, state, is_daily, title, background in OFFERS:
            self.wvint(1)  # RewardCount
            self.wvint(items[0])  # ItemType
            self.wvint(items[1])  # Amount
            self.wref(items[2], items[3])  # CsvID
            self.wvint(0)  # SkinID

            self.wvint(currency)  # Currency (0-Gems, 1-Gold, 3-StarPoints)
            self.wvint(cost)  # Cost
            self.wvint(86400)  # Time
            self.wvint(state)  # State (0-New with Animations, 1-New, 2-Nothing)
            self.wvint(0)
            self.wbool(index in purchased_offers)  # Who Buyed
            self.wvint(0)  # Offer Index
            self.wvint(0)
            self.wbool(is_daily)  # isDaily?
            self.wvint(old_cost)  # OldPrice
            self.wint(0)
            self.wstr(title)  # Offer Text
            self.wbool(False)
            self.wstr(background)  # Offer Background
            self.wvint(0)
            self.wbool(False)  # isProcess
            self.wvint(0)  # ExtraType
            self.wvint(0)  # Extra
            self.wstr()
            self.wbool(False)  # isOneTimePurchase

        self.wvint(0)   # Array

        self.wvint(200) # Available tokens from battles
        self.wvint(-64) # Timer for new tokens

        self.wvint(0)

        self.wvint(0)
        self.wvint(0)
        self.wref(16, 50)
        self.wstr('CA')
        self.wstr("это что") # Creator Code

        self.wvint(17)
        self.wlong(3, 0)   # TokensGained
        self.wlong(4, 0)   # TrophiesGained
        self.wlong(6, 0)   # DemoAccount
        self.wlong(7, 0)   # InvitesBlocked
        self.wlong(8, 0)   # StarPointsGained
        self.wlong(9, 1)   # ShowStarPoints
        self.wlong(10, 0)  # PowerPlayTrophiesGained
        self.wlong(12, 1)  # Unknown
        self.wlong(14, 0)  # CoinsGained
        self.wlong(15, 0)  # AgeScreen
        self.wlong(16, 1)  # AgeScreen
        self.wlong(17, 0)  # TeamChatMuted
        self.wlong(18, 1)  # EsportButton
        self.wlong(19, 1)  # ChampionShipLivesBuyPopup
        self.wlong(20, 0)  # GemsGained
        self.wlong(21, 0)  # LookingForTeamState
        self.wlong(22, 1)

        self.wvint(0)

        self.wvint(9)   # Brawlpass
        for i in range(9):
            self.wvint(i)
            self.wvint(34500)
            self.wbool(True)
            self.wvint(0)

            self.wbyte(2)
            self.wint(4294967292)
            self.wint(4294967295)
            self.wint(511)
            self.wint(0)

            self.wbyte(1)
            self.wint(4294967292)
            self.wint(4294967295)
            self.wint(511)
            self.wint(0)

        self.wvint(0)

        self.wbool(True)
        self.wvint(0)

        self.wbool(True)
        # Pins: Shelly (151-155) + Colt (44-48)
        allPins = [151, 152, 153, 154, 155, 44, 45, 46, 47, 48]
        self.wvint(len(allPins))  # Vanity Count
        for i in allPins:
            self.wref(52, i)
            self.wvint(0)

        self.wbool(False)

        self.wint(0)
        # LogicDailyData End

        # LogicConfData
        self.wvint(0)

        # Event Slots IDs Array
        self.wvint(22)  # Count
        self.wvint(1)   # Gem Grab
        self.wvint(2)   # Showdown
        self.wvint(3)   # Daily Events
        self.wvint(4)   # Team Events
        self.wvint(5)   # Duo Showdown
        self.wvint(6)   # Team Events 2
        self.wvint(7)   # Special Events
        self.wvint(8)   # Solo Events
        self.wvint(9)   # Power Play
        self.wvint(10)  # Seasonal Events
        self.wvint(11)  # Seasonal Events 2
        self.wvint(12)  # Candidates of The Day
        self.wvint(13)  # Winner of The Day
        self.wvint(14)  # Solo Mode Power League
        self.wvint(15)  # Team Mode Power League
        self.wvint(16)  # Club league
        self.wvint(17)  # Club league
        self.wvint(20)  # Championship Challenge (Stage 1)
        self.wvint(21)  # Championship Challenge (Stage 2)
        self.wvint(22)  # Championship Challenge (Stage 3)
        self.wvint(23)  # Championship Challenge (Stage 4)
        self.wvint(24)  # Championship Challenge (Stage 5)
        # Event Slots IDs Array End

        # EventType: 1=Gem Grab, 2=Showdown, 4=Bounty, 5=Duo Showdown, 6=Heist, 7=Brawl Ball
        events = [
            (1,   7), (2,  13), (3,  18), (4,   5), (5,  28), (6, 361),
            (7,  24), (8,  97), (10, 245), (11, 202), (12, 370), (13, 377),
            (17, 384), (20, 174), (21, 167), (22, 27), (23,  57), (24, 354),
        ]

        self.wvint(len(events))  # Events Count

        for eventIndex, (eventType, mapID) in enumerate(events, start=1):
            self.wvint(0)
            self.wvint(eventType)           # EventType
            self.wvint(0)                   # EventsBeginCountdown
            self.wvint(99999)               # Timer
            self.wvint(0)                   # tokens reward for new event
            self.wref(15, mapID)  # MapID
            self.wvint(-64)                 # GameModeVariation
            self.wvint(2)                   # State
            self.wstr()
            self.wvint(0)
            self.wvint(0)
            self.wvint(0)
            self.wvint(0)                   # Modifiers
            self.wvint(0)
            self.wvint(0)
            self.wbool(False)            # Map Maker Map Structure Array
            self.wvint(0)
            self.wbool(False)            # Power League Data Array
            self.wvint(0)
            self.wvint(0)
            self.wvint(0)                   # ChronosTextEntry
            self.wvint(-64)
            self.wbool(False)

        self.wvint(0)  # Coming Up Events Count

        self.wvint(8)  # Brawler Upgrade Cost
        self.wvint(1)
        self.wvint(2)
        self.wvint(3)
        self.wvint(4)
        self.wvint(5)
        self.wvint(6)
        self.wvint(7)
        self.wvint(8)

        self.wvint(4)  # Shop Coins Price
        self.wvint(0)
        self.wvint(0)
        self.wvint(0)
        self.wvint(0)

        self.wvint(4)  # Shop Coins Amount
        self.wvint(-1337)
        self.wvint(0)
        self.wvint(-1337)
        self.wvint(0)

        self.wbool(True)  # Show Offers Packs

        self.wvint(0)  # Release Entry

        self.wvint(13)  # IntValueEntry

        self.wlong(10008, 501)
        self.wlong(65, 2)
        self.wlong(1, 41000033)
        self.wlong(60, 36270)
        self.wlong(66, 1)
        self.wlong(61, 36270)  # SupportDisabled State
        self.wlong(47, 41381)
        self.wlong(29, 7)      # Skin Group Active For Campaign
        self.wlong(48, 49079)
        self.wlong(50, 1)      # Coming up quests placeholder
        self.wlong(1100, 1337)
        self.wlong(1003, 1)
        self.wlong(36, 0)

        self.wvint(2)  # Timed Int Value Entry

        self.wvint(14)
        self.wvint(1)
        self.wvint(480560)
        self.wvint(739760)

        self.wvint(29)
        self.wvint(7)
        self.wvint(0)
        self.wvint(746960)

        self.wvint(0)  # Custom Event
        self.wvint(0)
        self.wvint(0)
        self.wvint(0)
        # LogicConfData End

        self.wlong(0, 1)  # PlayerID
        self.wvint(0)     # Notification Factory
        self.wvint(-64)   # VideoAdStarted
        self.wbool(False)
        self.wvint(0)     # GatchaDrop
        self.wvint(0)     # FriendlyStarPower
        # LogicClientHome End

        self.wvlong(0, 1)  # PlayerID
        self.wvlong(0, 1)
        self.wvlong(0, 1)

        self.wstr("BSWS")  # PlayerName
        self.wbool(True)   # isRegistred

        self.wstr()

        self.wvint(15)  # Commodity Count

        brawlersUnlock = [0, 4]
        brawlers = [0, 1]
        brawlersCount = len(brawlers)

        # Unlocked Brawlers and Resources Array
        self.wvint(4 + len(brawlersUnlock))  # Count
        for i in brawlersUnlock:
            self.wref(23, i)
            self.wvint(1)

        self.wref(5, 1)
        self.wvint(1)

        self.wref(5, 8)
        self.wvint(0)   # Coins

        self.wref(5, 9)
        self.wvint(3)

        self.wref(5, 10)
        self.wvint(0)  # StarPoints

        # Brawlers Trophies Array
        self.wvint(brawlersCount)
        for x in brawlers:
            self.wref(16, x)
            self.wvint(-1)

        # Brawlers Trophies for Rank Array
        self.wvint(brawlersCount)
        for x in brawlers:
            self.wref(16, x)
            self.wvint(1337)

        # Unknown Brawlers Array
        self.wvint(0)

        # Brawlers Power Points Array
        self.wvint(brawlersCount)
        for x in brawlers:
            self.wref(16, x)
            self.wvint(0)

        # Brawlers Power Level Array
        self.wvint(brawlersCount)
        for x in brawlers:
            self.wref(16, x)
            self.wvint(-2)

        # Brawlers Star Powers Array
        self.wvint(0)

        # HeroSeenState
        self.wvint(0)

        self.wvint(0)
        self.wvint(0)
        self.wvint(0)
        self.wvint(0)
        self.wvint(0)
        self.wvint(0)
        self.wvint(0)

        self.wvint(0)    # Diamonds
        self.wvint(0)    # Free Diamonds
        self.wvint(52)   # Player Level
        self.wvint(100)
        self.wvint(0)    # CumulativePurchasedDiamonds
        self.wvint(0)    # Battle Count
        self.wvint(0)    # WinCount
        self.wvint(0)    # LoseCount
        self.wvint(0)    # WinLooseStreak
        self.wvint(0)    # NpcWinCount
        self.wvint(0)    # NpcLoseCount
        self.wvint(2)    # TutorialState
        self.wvint(0)
        # LogicClientAvatar End
