import math

from G.GameObject import GameObject, OBJECT_TYPE_CHARACTER
from G.Assets import character_data, card_data, area_effect_data, get_character_hp, get_character_speed
from G.Component.Buff import (
    Buff, SPEED_SLOWER, SPEED_FASTER, DAMAGE, DAMAGE_AND_SIZE, HEALTH_REGEN, BELLE_WEAPON,
)
from G.Component.Gear import Gear
from G.Component.Immunity import Immunity
from G.Component.Poison import Poison
from G.AreaEffect import AreaEffect
from G.Projectile import Projectile
from G.Skill import Skill
from G.GameModeUtil import mode_has_carryables
from G.LogicMath import (
    clamp, get_angle, get_angle_to, path_length, trunc_div, get_rotated_x, get_rotated_y,
    closest_level_border_collision, sin_table_value,
)
from L.BitStream import BitStream

MAX_HOLD_TICKS      = 15
INTRO_TICKS         = 100
DEPLOY_TICKS        = 19
DEPLOY_TICKS_FIRST  = 4
MAX_ATTACK_TICKS    = 63
DAMAGE_NUMBER_LIMIT = 32767
ULTI_CHARGE_MAX     = 4000
MELEE_RANGE         = 420
KNOCKBACK_TICKS     = 8

_DAMAGE_NUMBER_DELAY_TICKS = 2


class Character(GameObject):
    __slots__ = (
        'data', 'name', 'is_hero', 'is_boss', 'is_base', 'is_decoy',
        'is_training_dummy', 'is_train', 'is_carryable',
        'has_auto_attack', 'has_very_much_hit_points',
        'manual_rotations', 'should_encode_pet_status', 'secondary_pet',
        'has_power_levels', 'unique_property', 'area_effect_name',
        'hp', 'max_hp', 'hp_pct', 'is_alive_state',
        'state', 'move_angle', 'attack_angle', 'attacking_ticks',
        'knockbacked', 'knockback_ticks', 'stun_ticks', 'shaking', 'star_power_ic',
        'slippery', 'frozen_pct', 'poisons', 'buffs',
        'hit_effect_projectile', 'hit_effect_skin',
        'consumable_shield', 'consumable_shield_max',
        'item_count', 'battle_royale_buffs', 'big_state',
        'is_invincible', 'ultiing', 'using_ulti', 'ulti_charge',
        'charge_up', 'charge_up_type', 'charged_shot_count',
        'is_charging', 'active_charge_type', 'charge_animation',
        'shield_ticks', 'visibility_state', 'is_invisible',
        'vision_override_ticks', 'vision_override_x', 'vision_override_y',
        'yellow_eye', 'speed', 'buffed_speed', 'power_level', 'hero_level',
        'forced_angle_ticks', 'ticks_gone', 'is_control_removed',
        'steer_active', 'weapon_skill', 'ultimate_skill', 'skills',
        'damage_numbers', 'total_kick_distance', 'carrying_character',
        'spawn_tick', 'is_bot', 'hero_index', 'death_tick',
        'move_start', 'move_end', 'path_length',
        'way_point', 'way_point_start',
        'immunities', 'gear1', 'gear2', 'last_self_heal_tick',
        'tagged', 'last_tag_tick', 'silence', 'silence_tick', 'realm_timer',
        'rapid_fire_tick', 'cripple_end_tick', 'is_crippled', 'cripple_percent',
        'cc_immunity_ticks', 'reload_buff_ticks', 'skill_hold_ticks',
        'carryable_pick_ticks', 'carryable_person_immun_ticks',
        'health_regened_tick', 'health_regened_tick_sp', 'health_regen_blocked_tick',
        'auto_ulti_charge_timer', 'star_power_data', 'boost_set',
        'aoe_regenerate', 'static_speed_buff', 'immun_to_pushback_out_of_walls',
        'longer_dash_gauge_timer', 'longer_dash_gauge_ready',
        'extra_regen_ticks', 'extra_regen_amount', 'extra_regen_index',
        'charge_up_max', 'can_heal', 'is_weakly_stunned',
        'dragging_object', 'dragging_offset_x', 'dragging_offset_y',
        'shield_percent', 'consumable_shield_tick', 'consumable_shield_duration',
        'last_frozen_tick', 'frozen_decay_tick', 'slippery_ticks',
        'landing_tick', 'ball_state', 'afk_ticks',
        'is_teleporting', 'transform_animation', 'unload_time_ticks', 'attacking',
        'attached_character', 'last_rage_tick',
        'casting_time', 'rapid_fire_ms_between_attacks',
        'rapid_fire_x', 'rapid_fire_y', 'rapid_fire_attack_pattern', 'rapid_fire_bullets',
        'rapid_fire_projectile', 'rapid_fire_damage', 'rapid_fire_normal_dmg',
        'rapid_fire_range', 'rapid_fire_spread', 'rapid_fire_shoot_times', 'rapid_fire_tick',
        'attack_vector_x', 'attack_vector_y', 'attack_target_x', 'attack_target_y', 'left_hand',
        'shoot_index', 'last_attack_tick', 'melee_attack_pushbacks',
        'summoned_character', 'jester_skill_count', 'projectile_shield_angle',
        'projectile_shield_scale', 'charge_damage', 'charge_normal_dmg', 'charge_speed',
        'charge_pushback', 'charge_type', 'charge_start_ticks', 'charge_hit_ids', 'charge_hits',
        'invisible_ticks', 'eye_tick', 'attack_accelerating_factor',
        'controlled_character', 'is_controlled', 'destruct_after_ticks',
        'spawned_item_data', 'num_spawns_item', 'max_spawns_item',
        'spawned_item_damage', 'spawned_item_normal_dmg', 'damage_multiplier',
        'damage_modifier',
    )

    def __init__(self, data_class: int = 16, data_instance: int = 0):
        super().__init__(data_class, data_instance)

        self.data = character_data(data_instance) or {}
        self.name = self.data.get('_name', '')

        self.is_hero            = self.data.get('_type') == 'Hero'
        self.is_boss            = self.data.get('_type') in ('Npc_Boss', 'Npc_Boss_TownCrush')
        self.is_base            = self.data.get('_type') == 'Pvp_Base'
        self.is_decoy           = self.data.get('_type') == 'Minion_Mirage'
        self.is_training_dummy  = self.data.get('_type') == 'Minion_Building_charges_ulti'
        self.is_train           = self.data.get('_type') == 'Train'
        self.is_carryable       = self.data.get('_type') == 'Carryable'
        self.has_auto_attack    = int(self.data.get('AutoAttackDamage') or 0) > 0
        self.manual_rotations   = self.data.get('ManualRotations', '').lower() == 'true'
        self.should_encode_pet_status = self.data.get('ShouldEncodePetStatus', '').lower() == 'true'
        self.secondary_pet      = self.data.get('SecondaryPet', '').lower() == 'true'
        self.has_power_levels   = self.data.get('HasPowerLevels', '').lower() == 'true'
        self.unique_property    = int(self.data.get('UniqueProperty') or 0)
        self.area_effect_name   = self.data.get('AreaEffect', '')

        self.speed = get_character_speed(data_instance)
        self.max_hp = get_character_hp(data_instance)
        self.has_very_much_hit_points = (
            (int(self.data.get('Hitpoints') or 0) > 5799 and self.is_hero) or self.max_hp > 65535
        )

        self.hp             = self.max_hp
        self.hp_pct         = 100
        self.is_alive_state = True

        self.state              = 4
        self.move_angle         = 0
        self.attack_angle       = 0
        self.attacking_ticks    = 0
        self.knockbacked        = False
        self.knockback_ticks    = 0
        self.stun_ticks         = 0
        self.shaking            = 0
        self.star_power_ic      = False
        self.slippery           = False
        self.frozen_pct         = 0
        self.poisons: list      = []
        self.buffs: list        = []

        self.hit_effect_projectile = 0
        self.hit_effect_skin       = 0

        self.consumable_shield      = 0
        self.consumable_shield_max  = 0
        self.item_count             = 0
        self.battle_royale_buffs    = 0
        self.big_state              = False

        self.is_invincible  = False
        self.ultiing        = False
        self.using_ulti     = False
        self.ulti_charge    = 0

        self.charge_up          = 0
        self.charge_up_type     = 0
        self.charged_shot_count = 0
        self.is_charging        = False
        self.active_charge_type = 0
        self.charge_animation   = 0

        self.shield_ticks       = 0
        self.visibility_state   = 0
        self.is_invisible       = False

        self.vision_override_ticks = 0
        self.vision_override_x     = 0
        self.vision_override_y     = 0

        self.yellow_eye        = False
        self.buffed_speed      = 0
        self.immunities: list  = []
        self.gear1             = None
        self.gear2             = None
        self.last_self_heal_tick = 0
        self.power_level       = 0
        self.hero_level        = 0

        self.forced_angle_ticks = 0
        self.ticks_gone         = 0
        self.is_control_removed = False
        self.steer_active       = False

        self.weapon_skill   = None
        self.ultimate_skill = None
        self.skills: list   = []

        self.damage_numbers: list = []
        self.total_kick_distance  = 0
        self.carrying_character   = None
        self.move_start           = 0
        self.move_end             = 0
        self.path_length          = 0
        self.way_point            = (0, 0)
        self.way_point_start      = (0, 0)
        self.spawn_tick           = 0
        self.is_bot               = 0
        self.hero_index           = 0
        self.death_tick           = 1

        self.tagged                  = False
        self.last_tag_tick           = 0
        self.silence                 = False
        self.silence_tick            = 0
        self.realm_timer             = 0
        self.rapid_fire_tick         = 0
        self.cripple_end_tick        = 0
        self.is_crippled             = False
        self.cripple_percent         = 0
        self.cc_immunity_ticks       = 0
        self.reload_buff_ticks       = 0
        self.skill_hold_ticks        = 0
        self.carryable_pick_ticks    = 0
        self.carryable_person_immun_ticks = 0
        self.health_regened_tick     = 0
        self.health_regened_tick_sp  = 0
        self.health_regen_blocked_tick = 0
        self.auto_ulti_charge_timer  = 0
        self.star_power_data         = {}
        self.boost_set               = False
        self.aoe_regenerate          = 0
        self.static_speed_buff       = 0
        self.immun_to_pushback_out_of_walls = False
        self.longer_dash_gauge_timer = 0
        self.longer_dash_gauge_ready = False
        self.extra_regen_ticks       = 0
        self.extra_regen_amount      = 0
        self.extra_regen_index       = 0
        self.charge_up_max           = 0
        self.can_heal                = True
        self.is_weakly_stunned       = False
        self.dragging_object         = None
        self.dragging_offset_x       = 0
        self.dragging_offset_y       = 0
        self.shield_percent          = 0
        self.consumable_shield_tick  = 0
        self.consumable_shield_duration = 0
        self.last_frozen_tick        = 0
        self.frozen_decay_tick       = 0
        self.slippery_ticks          = 0
        self.landing_tick            = 0
        self.ball_state              = 0
        self.afk_ticks               = 0
        self.is_teleporting          = False
        self.transform_animation     = False
        self.unload_time_ticks       = 0
        self.attacking               = False
        self.attached_character      = None
        self.last_rage_tick          = 0
        self.casting_time            = 0
        self.rapid_fire_ms_between_attacks = 0
        self.rapid_fire_x            = 0
        self.rapid_fire_y            = 0
        self.rapid_fire_attack_pattern = 0
        self.rapid_fire_bullets      = 1
        self.rapid_fire_projectile   = None
        self.rapid_fire_damage       = 0
        self.rapid_fire_normal_dmg   = 0
        self.rapid_fire_range        = 0
        self.rapid_fire_spread       = 0
        self.rapid_fire_shoot_times  = 1
        self.rapid_fire_tick         = -1000
        self.attack_vector_x         = 0
        self.attack_vector_y         = 0
        self.attack_target_x         = 0
        self.attack_target_y         = 0
        self.left_hand               = 0
        self.shoot_index             = 0
        self.last_attack_tick        = -1000
        self.melee_attack_pushbacks  = False
        self.summoned_character      = None
        self.jester_skill_count      = 0
        self.projectile_shield_angle = 0
        self.projectile_shield_scale = 0
        self.charge_damage           = 0
        self.charge_normal_dmg       = 0
        self.charge_speed            = 0
        self.charge_pushback         = 0
        self.charge_type             = 0
        self.charge_start_ticks      = 0
        self.charge_hit_ids: list    = []
        self.charge_hits             = 0
        self.invisible_ticks         = 0
        self.eye_tick                = -1000
        self.attack_accelerating_factor = 0
        self.controlled_character    = None
        self.is_controlled           = False
        self.destruct_after_ticks    = 0
        self.spawned_item_data       = None
        self.num_spawns_item         = 0
        self.max_spawns_item         = 0
        self.spawned_item_damage     = 0
        self.spawned_item_normal_dmg = 0
        self.damage_multiplier       = 0
        self.damage_modifier         = 0

        if not self.data:
            self.data = character_data(0) or {}
        self._setup_skills()

    def _setup_skills(self):
        weapon_name   = self.data.get('WeaponSkill', '')
        ultimate_name = self.data.get('UltimateSkill', '')

        if weapon_name:
            self.weapon_skill = Skill(weapon_name, False, self)
            self.skills.append(self.weapon_skill)
        if ultimate_name:
            self.ultimate_skill = Skill(ultimate_name, True, self)
            self.skills.append(self.ultimate_skill)

    def get_object_type(self) -> int:
        return OBJECT_TYPE_CHARACTER

    def is_alive(self) -> bool:
        return self.is_alive_state

    def get_hitpoint_percentage(self) -> int:
        if self.max_hp == 0:
            return 0
        return clamp(self.hp * 100 // self.max_hp, 0, 100)

    def set_upgrades(self, power_level: int):
        self.power_level = power_level

    def set_hero_level(self, hero_level: int):
        self.hero_level = hero_level
        if self.is_hero:
            self.max_hp = int(math.floor(int(self.data.get('Hitpoints') or self.max_hp) * (1.0 + hero_level / 10.0)))
            self.hp     = self.max_hp

    def set_bot(self, is_bot):
        self.is_bot = 1 if is_bot else 0

    def has_buff(self, buff_id: int) -> bool:
        return self.get_buff(buff_id) is not None

    def get_buff(self, buff_id: int) -> Buff | None:
        for buff in self.buffs:
            if buff.type == buff_id:
                return buff
        return None

    def apply_buff(self, buff_id: int, duration: int, modifier: int,
                   size_increase: int = 0, source_index: int = 0) -> Buff:
        if self.has_buff(buff_id) and not Buff(buff_id, duration, modifier).can_stack():
            self.remove_buffs(buff_id)
        buff = Buff(buff_id, duration, modifier, size_increase)
        buff.source_index = source_index
        self.buffs.append(buff)
        self.update_buffed_speed()
        return buff

    def add_buff(self, buff_id: int, effect_type: int = 0, ticks: int = 0):
        buff = self.apply_buff(buff_id, ticks, 0)
        buff.effect_type = effect_type
        return buff

    def remove_buffs(self, buff_id: int):
        self.buffs = [buff for buff in self.buffs if buff.type != buff_id]
        self.update_buffed_speed()

    def update_buffed_speed(self):
        total = 0
        for buff in self.buffs:
            if buff.type in (SPEED_SLOWER, SPEED_FASTER):
                total += buff.modifier
        self.buffed_speed = total

    def give_speed_faster_buff(self, modifier: int, duration: int, buffed_speed: bool = True):
        self.apply_buff(SPEED_FASTER, duration, modifier)

    def give_speed_slower_buff(self, modifier: int, duration: int):
        self.apply_buff(SPEED_SLOWER, duration, modifier)

    def give_damage_buff(self, modifier: int, duration: int):
        self.apply_buff(DAMAGE, duration, modifier, 1)

    def give_damage_buff2(self, modifier: int, duration: int):
        self.apply_buff(DAMAGE_AND_SIZE, duration, modifier, 1)

    def add_poison(self, damage: int, normal_dmg: int, is_ulti: bool,
                   source, source_index: int, poison_type: int) -> Poison:
        for poison in self.poisons:
            if poison.type == poison_type and not poison.allows_stacking():
                poison.refresh(damage, normal_dmg, is_ulti, poison_type)
                return poison
        poison = Poison(damage, normal_dmg, is_ulti, source, source_index, poison_type)
        self.poisons.append(poison)
        return poison

    def add_immunity(self, target_index: int, target_data, ticks: int) -> Immunity:
        immunity = Immunity(target_index, target_data, ticks)
        self.immunities.append(immunity)
        return immunity

    def get_gear_boost(self, logic_type: int) -> int:
        for gear in (self.gear1, self.gear2):
            if gear is None:
                continue
            if gear.logic_type() == logic_type:
                gear.on_boost()
                return gear.modifier_value()
        return 0

    def is_in_bush(self) -> bool:
        battle = self.get_battle()
        if battle is None:
            return False
        tile = battle.tilemap.get_tile(self.x // 300, self.y // 300)
        if tile is None:
            return False
        return tile.hides_hero and not tile.is_destructed()

    def position_distance_to(self, other) -> int:
        return path_length(self.x, self.y, other.x, other.y)

    def is_immune_and_bullets_go_through(self, is_in_realm: bool = False) -> bool:
        return self.is_in_realm != is_in_realm

    def add_area_effect(self, bonus_damage: int, dot_damage: int, data,
                        skill_type: int = 0, is_ulti: bool = False):
        if not data:
            return None
        battle = self.get_battle()
        if battle is None:
            return None
        effect = AreaEffect(17, data.get('_instance', 0), data.get('Name', ''))
        effect.set_position(self.x, self.y, 0)
        effect.set_index(self.get_index())
        effect.set_source(self, skill_type)
        effect.aoe_dot    = dot_damage
        base_damage       = int(data.get('Damage') or 0)
        if base_damage < 1:
            effect.damage     = base_damage - bonus_damage
            effect.normal_dmg = 0
        else:
            effect.damage     = base_damage + bonus_damage
            effect.normal_dmg = base_damage
        effect.trigger(int(data.get('TimeMs') or 0) // 50)
        battle.manager.add(effect)
        return effect

    def shoot_homing_projectile(self, projectile_name: str, target, damage: int,
                                normal_dmg: int, source_index: int, bounces: int):
        from G.Assets import projectile_data
        battle = self.get_battle()
        if battle is None:
            return None
        data = projectile_data(projectile_name)
        if not data:
            return None
        projectile = Projectile.shoot_projectile(
            self, target, data, target.x, target.y, damage, 0, battle, 0, 1)
        if projectile is None:
            return None
        projectile.set_index(source_index)
        projectile.homing_target        = target
        projectile.belle_weapon_bounces = bounces
        projectile.hit_objects.add(self.get_global_id())
        return projectile

    def tick_effects(self):
        for poison in list(self.poisons):
            if poison.tick(self):
                self.poisons.remove(poison)
        for buff in list(self.buffs):
            if buff.tick(self):
                self.buffs.remove(buff)
                self.update_buffed_speed()
        for immunity in list(self.immunities):
            if immunity.tick(50):
                self.immunities.remove(immunity)

    def tick_gears(self):
        if self.gear1 is not None:
            self.gear1.tick(self)
        if self.gear2 is not None:
            self.gear2.tick(self)

    def is_charge_active(self) -> bool:
        return self.is_charging and self.charge_up_type != 0

    def encodes_charge_behavior(self) -> bool:
        if self.weapon_skill is not None and self.weapon_skill.behavior_type() == 'Charge':
            return True
        if self.ultimate_skill is not None and self.ultimate_skill.behavior_type() == 'Charge':
            return True
        return False

    def ultimate_seems_active(self) -> bool:
        return False


    def move_to(self, x: int, y: int):
        if self.is_control_removed:
            return
        start_x, start_y   = self.x, self.y
        target_x           = clamp(x, 0, 65535)
        target_y           = clamp(y, 0, 65535)
        self.way_point_start = (start_x, start_y)
        self.way_point       = (target_x, target_y)
        self.path_length     = path_length(start_x, start_y, target_x, target_y)
        speed                = self.speed + self.buffed_speed
        if speed <= 0:
            speed = 1
        self.move_start = self.get_ticks_gone()
        self.move_end   = self.move_start + max(1, 20 * self.path_length // speed)
        if self.path_length >= 1:
            self.move_angle = get_angle(target_x - start_x, target_y - start_y)

    def stop_movement(self):
        self.way_point_start = (self.x, self.y)
        self.way_point       = (self.x, self.y)
        self.path_length     = 0
        self.move_start      = self.get_ticks_gone() - 1
        self.move_end        = self.get_ticks_gone() - 1

    def update_position(self):
        ticks = self.get_ticks_gone()
        if self.path_length < 1 or self.move_end <= self.move_start:
            return
        if ticks >= self.move_end:
            self.x, self.y = self.way_point
            return
        percent   = 1000 * (ticks - self.move_start) // (self.move_end - self.move_start)
        travelled = self.path_length * percent // 1000
        start_x, start_y   = self.way_point_start
        target_x, target_y = self.way_point
        length             = path_length(start_x, start_y, target_x, target_y)
        if length < 1:
            return
        remaining = self.path_length - travelled
        self.x = target_x - trunc_div((target_x - start_x) * remaining, length)
        self.y = target_y - trunc_div((target_y - start_y) * remaining, length)

    def attack(self, x: int, y: int, use_ulti: bool = False):
        self.activate_skill(1 if use_ulti else 0, x, y)

    def activate_skill(self, skill_type: int, x: int, y: int):
        if self.z > 1:
            return
        if self.get_ticks_gone() < INTRO_TICKS:
            return

        if self.silence:
            return
        if self.is_player_control_removed():
            return
        if skill_type == 1:
            value = self.get_card_value_for_passive('speed_after_ulti', 1)
            if value >= 1:
                self.apply_buff(SPEED_FASTER, value, self.get_card_value_for_passive('speed_after_ulti', 0), 10)
        skill = self.ultimate_skill if skill_type == 1 else self.weapon_skill
        if skill is None:
            return
        if skill.is_active() or skill.cool_down > 0:
            return

        self.attack_angle    = get_angle(x - self.x, y - self.y)
        self.attacking_ticks = MAX_ATTACK_TICKS
        self.state           = 2

        if skill_type == 1:
            self.using_ulti = True
        cast_x, cast_y = skill.cast_position(self, x, y)
        skill.activate(self, cast_x, cast_y)

    def ulti_enabled(self):
        self.using_ulti = True

    def ulti_disabled(self):
        self.using_ulti = False

    def get_closest_visible_enemy(self):
        battle = self.get_battle()
        if battle is None:
            return None
        closest = None
        distance = 99999999
        for enemy in battle.manager.get_characters():
            if enemy is self or not enemy.is_alive_state:
                continue
            if enemy.get_fade_counter() < 1:
                continue
            if enemy.data.get('IsCarryable', '').lower() == 'true':
                continue
            if enemy.get_index() // 16 == self.get_index() // 16 or enemy.is_invisible:
                continue
            distance_to_enemy = path_length(self.x, self.y, enemy.x, enemy.y)
            if distance_to_enemy < distance:
                closest  = enemy
                distance = distance_to_enemy
        return closest

    def trigger_pushback(self, trigger_x: int, trigger_y: int, length: int):
        if not self.is_alive_state or length < 1:
            return
        distance = 6 * abs(length)
        dx = self.x - trigger_x
        dy = self.y - trigger_y
        current = path_length(0, 0, dx, dy)
        if current < 1:
            dx, dy, current = 1, 0, 1
        if distance > current:
            distance = current
        self.x = self.x + dx * distance // current
        self.y = self.y + dy * distance // current
        self.knockbacked     = True
        self.knockback_ticks = KNOCKBACK_TICKS

    def fire_attack(self, x: int, y: int, skill=None, damage: int = None, normal_dmg: int = None):
        if not self.is_alive_state:
            return
        if damage is None:
            skill = skill or self.weapon_skill
            if skill is None:
                return
            data        = skill.projectile_data()
            bullets     = skill.chosen_bullets(self)
            spread      = skill.spread()
            damage      = skill.skill_damage_math(skill.damage())
            normal      = skill.damage() if normal_dmg is None else normal_dmg
            ultimate    = skill.is_ultimate
            pattern     = skill.attack_pattern()
            shoot_times = 1
            shoot_index = 0
        else:
            data        = self.rapid_fire_projectile
            bullets     = self.rapid_fire_bullets
            spread      = self.rapid_fire_spread
            normal      = self.rapid_fire_normal_dmg if normal_dmg is None else normal_dmg
            ultimate    = self.using_ulti
            pattern     = self.rapid_fire_attack_pattern
            shoot_times = self.rapid_fire_shoot_times
            shoot_index = self.shoot_index
        if not data or not data.get('Name'):
            return
        battle = self.get_battle()
        if battle is None:
            return
        damage -= self.cripple_percent * damage // 100
        if damage <= 1:
            damage = 1
        offset_x, offset_y, target_offset_x, target_offset_y = self.get_shoot_position_modifiers(x, y, 50)
        target_x = x + target_offset_x
        target_y = y + target_offset_y
        if pattern in (1, 2, 3, 6, 22):
            pattern_spread = self.attack_pattern_spread(pattern, spread, shoot_index, shoot_times)
            self.spawn_projectile(battle, data, target_x, target_y, damage, normal, pattern_spread,
                                  shoot_index, ultimate, 0, offset_x, offset_y)
            return
        if bullets >= 2:
            step         = 2 * spread // (bullets - 1)
            travel_type  = int(data.get('TravelType') or 0)
            seventh      = int(data.get('Speed') or 0) // 7
            shot_slots   = 2 if bullets == 5 else 3
            volley_spread = -spread
            if travel_type == 3:
                volley_spread = 0
                step          = 0
                seventh       = 0
            for index in range(bullets):
                speed_adjustment = 0
                if bullets >= 4:
                    slot = (index + shoot_index) % shot_slots
                    if slot == 2:
                        speed_adjustment = seventh
                    elif slot == 1:
                        speed_adjustment = seventh // 2
                bullet_x = target_x
                bullet_y = target_y
                bullet_offset_x = offset_x
                bullet_offset_y = offset_y
                if pattern == 5 and index % 2 != 0:
                    dx = x - self.x
                    dy = y - self.y
                    length = path_length(self.x, self.y, x, y)
                    if length >= 1:
                        speed = int(data.get('Speed') or 0)
                        distance_delta = (length // speed) * (speed - speed // 4) - length
                        bullet_x += distance_delta * dx // length // 2
                        bullet_y += distance_delta * dy // length // 2
                        speed_adjustment = speed // 4
                if pattern == 4:
                    speed_adjustment = seventh * index
                if pattern in (10, 13):
                    speed_adjustment = 0
                self.spawn_projectile(battle, data, bullet_x, bullet_y, damage, normal,
                                      volley_spread + step * index, index, ultimate,
                                      speed_adjustment, bullet_offset_x, bullet_offset_y)
            return
        self.spawn_projectile(battle, data, target_x, target_y, damage, normal, 0,
                              shoot_index, ultimate, 0, offset_x, offset_y)

    def spawn_projectile(self, battle, data, target_x: int, target_y: int, damage: int, normal: int,
                         spread: int, bullet_index: int, ultimate: bool, speed_adjustment: int,
                         offset_x: int, offset_y: int):
        projectile = Projectile.shoot_projectile(
            self, self, data, target_x, target_y, damage, spread, battle,
            bullet_index, 2 if ultimate else 1, offset_x + self.x, offset_y + self.y,
            None, None, speed_adjustment, normal)
        if projectile is None:
            return None
        projectile.set_index(self.get_index())
        projectile.run_early_ticks()
        return projectile

    def attack_pattern_spread(self, pattern: int, spread: int, shoot_index: int, shoot_times: int) -> int:
        value = 0
        if shoot_index % 3 == 2:
            value = -spread
        elif shoot_index % 3 == 1:
            value = spread
        if shoot_times >= 5 and shoot_times > 1:
            value = sin_table_value(1080 * shoot_index // (shoot_times - 1)) * spread >> 10
        if pattern == 6:
            if shoot_index != 0:
                step  = (shoot_index - (0 if shoot_index & 1 else 1)) // 2 + 1
                side  = 1 if shoot_index % 2 == 0 else -1
                value = step * side * spread // shoot_times * 2
            else:
                value = 0
        elif pattern == 3:
            if shoot_times > 1:
                value = sin_table_value(720 * shoot_index // (shoot_times - 1)) * spread >> 10
        elif pattern == 2:
            if shoot_times > 1:
                value = shoot_index * (2 * spread) // (shoot_times - 1) - spread
        elif pattern == 22:
            if shoot_times > 1:
                base_angle = shoot_index * 360 // (shoot_times - 1)
                if shoot_index % 2 == 0:
                    value = sin_table_value(base_angle) * spread >> 10
                else:
                    value = -(sin_table_value(base_angle) * spread) >> 10
        return value

    def get_shoot_position_modifiers(self, x: int, y: int, forward: int):
        dx = x - self.x
        dy = y - self.y
        length = path_length(0, 0, dx, dy)
        forward_x = dx
        forward_y = dy
        if length != 0:
            forward_x = dx * forward // length
            forward_y = dy * forward // length
        side = self.two_weapon_attack_effect_offset()
        side_x = get_rotated_x(dx, dy, 90)
        side_y = get_rotated_y(dx, dy, 90)
        side_length = path_length(0, 0, side_x, side_y)
        if side_length != 0:
            side_x = side_x * side // side_length
            side_y = side_y * side // side_length
        else:
            side_x = 0
            side_y = 0
        if self.left_hand != 0:
            offset_x = forward_x - side_x
            offset_y = forward_y - side_y
            side_x = -side_x
            side_y = -side_y
        else:
            offset_x = forward_x + side_x
            offset_y = forward_y + side_y
        if self.left_hand == 0:
            self.left_hand = 1
        else:
            self.left_hand = 0
        return offset_x, offset_y, side_x, side_y

    def two_weapon_attack_effect_offset(self) -> int:
        return int(self.data.get('TwoWeaponAttackEffectOffset') or 0)

    def melee_attack(self, x: int, y: int, damage: int):
        battle = self.get_battle()
        if battle is None:
            return
        angle = get_angle(x - self.x, y - self.y)
        for other in battle.manager.get_characters():
            if other is self or not other.is_alive_state:
                continue
            if other.get_index() // 16 == self.get_index() // 16:
                continue
            if path_length(self.x, self.y, other.x, other.y) <= MELEE_RANGE:
                other.cause_damage(damage, self)

    def summon_minions(self, skill):
        battle = self.get_battle()
        if battle is None:
            return
        from G.GameObjectFactory import create_character_by_name
        name  = skill.data.get('SummonedCharacter') or ''
        count = int(skill.data.get('NumSpawns') or 1)
        if not name:
            return
        for _ in range(max(1, count)):
            minion = create_character_by_name(name)
            if minion is None:
                continue
            minion.set_index(self.get_index())
            minion.set_position(self.x, self.y, 0)
            minion.hp     = skill.skill_damage_math(int(minion.max_hp or 1))
            battle.manager.add(minion)

    def tick_skills(self):
        for skill in self.skills:
            skill.tick(self)

    def gain_ulti_charge(self, damage: int):
        player = self.get_player()
        if player is None:
            return
        mul = int(self.data.get('UltiChargeMul') or 0)
        if mul <= 0:
            return
        player.add_ulti_charge(damage * mul // 100)

    def cause_damage(self, damage: int, source=None, is_ulti: bool = False):
        if not self.is_alive_state or self.is_invincible:
            return
        for gear in (self.gear1, self.gear2):
            if gear is None or gear.shield_amount < 1:
                continue
            absorbed        = min(damage, gear.shield_amount)
            damage         -= absorbed
            gear.shield_amount -= absorbed
            self.get_gear_boost(4)
        self.hp -= damage
        source_player = source.get_player() if source is not None else None
        if source_player is not None:
            source_player.damage += damage
        if self.hp <= 0:
            self.hp = 0
            self.die(source)

    def die(self, source=None):
        if not self.is_alive_state:
            return
        self.is_alive_state = False
        self.state          = 0
        player              = self.get_player()
        if player is not None:
            player.deaths += 1
            source_player = source.get_player() if source is not None else None
            if source_player is not None:
                battle = self.get_battle()
                bounty = self.item_count + 1 if battle is not None and battle.gmv == 3 else 0
                source_player.killed_player(self.get_index() % 16, bounty)
            battle = self.get_battle()
            if battle is not None:
                battle.on_player_died(player)
        if self._manager is not None:
            self._manager.remove(self)

    def set_star_power(self, card_name: str):
        self.star_power_data = card_data(card_name) if card_name else {}

    def get_card_value_for_passive(self, passive_type: str, index: int) -> int:
        if not self.star_power_data:
            return -1
        if self.star_power_data.get('Type', '') != passive_type:
            return -1
        if index == 2:
            return int(self.star_power_data.get('Value3') or 0)
        if index > 0:
            return int(self.star_power_data.get('Value') or 0)
        return int(self.star_power_data.get('Value2') or 0)

    def set_star_power_boosts(self):
        if not self.star_power_data or self.boost_set:
            return
        self.boost_set = True
        value = self.get_card_value_for_passive('aoe_regenerate', 1)
        if value != -1:
            self.aoe_regenerate = value * self.max_hp // 1000
        value = self.get_card_value_for_passive('speed', 1)
        if value != -1:
            self.static_speed_buff += value
        value = self.get_card_value_for_passive('gain_health', 1)
        if value != -1:
            self.max_hp += value * self.max_hp // 1000
            self.hp = self.max_hp
            self.boost_set = False
        value = self.get_card_value_for_passive('extra_bullet', 1)
        if value != -1 and self.weapon_skill is not None:
            self.weapon_skill.max_charge += 1000 * value
            self.weapon_skill.charge = self.weapon_skill.max_charge
        self.star_power_ic = True

    def get_max_hold_ticks(self) -> int:
        value = self.get_card_value_for_passive('faster_focus', 1)
        if value >= 1:
            return 13 - 13 * value // 100
        return 13

    def get_max_charged_shots(self) -> int:
        if self.weapon_skill is not None and self.weapon_skill.charged_shot_count() >= 1:
            return self.weapon_skill.charged_shot_count()
        if self.unique_property == 10:
            return int(self.data.get('UniquePropertyValue1') or 0)
        return -1

    def get_active_skill(self, behavior_type: str):
        for skill in self.skills:
            if skill is None:
                continue
            if skill.behavior_type() == behavior_type and skill.ticks_active > 0:
                return skill
        return None

    def get_active_skill_shield(self) -> int:
        for skill in self.skills:
            if skill is None:
                continue
            if skill.behavior_type() == 'Shield' and skill.ticks_active > 0:
                return skill.ms_between_attacks()
        return 0

    def calculate_charge_up(self):
        weapon = self.weapon_skill.data if self.weapon_skill is not None else {}
        ultimate = self.ultimate_skill.data if self.ultimate_skill is not None else {}
        if len(self.skills) >= 2:
            if int(weapon.get('ChargeSpeed') or 0) > 0 and int(weapon.get('ChargeType') or 0) == 0:
                self.charge_up_type = 1
                self.charge_up_max = int(weapon.get('ChargeSpeed') or 0)
                return
            if int(ultimate.get('ChargeType') or 0) == 15:
                self.charge_up_type = 7
                self.charge_up_max = int(ultimate.get('ActiveTime') or 0)
                self.charge_up = 0
        value = self.get_card_value_for_passive('medikit', 1)
        if value >= 0:
            self.charge_up_type = 2
            self.charge_up_max = self.get_card_value_for_passive('medikit', 2)
            return
        value = self.get_card_value_for_passive('grow_from_damage', 1)
        if value >= 0:
            self.charge_up_type = 3
            self.charge_up_max = self.get_card_value_for_passive('grow_from_damage', 0)
            return
        value = self.get_card_value_for_passive('armor', 1)
        if value >= 0:
            self.charge_up_type = 4
            self.charge_up_max = value
            self.charge_up = self.charge_up_max
            return
        value = self.get_card_value_for_passive('increased_explosion', 1)
        if value >= 0:
            self.charge_up_type = 6
            self.charge_up_max = value
            return
        value = self.get_card_value_for_passive('attack_pierce', 1)
        if value >= 0:
            self.charge_up_type = 6
            self.charge_up_max = value * 50
            return
        value = self.get_card_value_for_passive('explosion_damage_increase', 1)
        if value >= 0:
            self.charge_up_type = 6
            self.charge_up_max = value
            return
        value = self.get_card_value_for_passive('reduce_damage_periodically', 1)
        if value >= 0:
            self.charge_up_type = 2
            self.charge_up_max = value * 50
            return
        value = self.get_card_value_for_passive('spawn_pet_on_hit', 1)
        if value >= 0:
            self.charge_up_type = 6
            self.charge_up_max = value * 50
            return
        value = self.get_card_value_for_passive('longer_dash', 1)
        if value >= 0:
            self.charge_up_type = 1
            dash_ms = self.get_card_value_for_passive('longer_dash', 2)
            if dash_ms <= 0:
                dash_ms = 2500
            self.charge_up_max = dash_ms
            return
        if self.unique_property == 1:
            self.charge_up_max = 1000
            self.charge_up_type = 8
        elif self.unique_property == 3:
            self.charge_up_type = 1
            self.charge_up_max = int(self.data.get('UniquePropertyValue1') or 0) * 50
            value = self.get_card_value_for_passive('faster_long_dash', 1)
            if value >= 1:
                self.charge_up_max -= 50 * value
        elif self.unique_property == 10:
            self.charge_up_type = 9
            self.charge_up_max = int(self.data.get('UniquePropertyValue1') or 0)
        elif self.unique_property == 12:
            self.charge_up_type = 10
            self.charge_up_max = int(self.data.get('UniquePropertyValue1') or 0)
        elif self.unique_property == 17:
            self.charge_up_type = 6
            self.charge_up_max = int(self.data.get('UniquePropertyValue1') or 0)
        player = self.get_player()
        if player is not None and player.accessory is not None:
            if player.accessory.data.get('ShowCountdown', '').lower() == 'true':
                self.charge_up_type = 7
                self.charge_up_max = int(player.accessory.data.get('ActiveTicks') or 0) * 50

    def is_charge_up_ready(self) -> bool:
        return self.charge_up >= self.charge_up_max

    def charge_ulti(self, amount: int, from_damage: bool = False, is_auto: bool = False):
        player = self.get_player()
        if player is None:
            return
        if not is_auto:
            boost = self.get_gear_boost(6)
            if boost > 0:
                amount += (amount * boost + 50) // 100
        player.add_ulti_charge(self.ulti_charge_mul(amount))

    def ulti_charge_mul(self, amount: int) -> int:
        mul = int(self.data.get('UltiChargeMul') or 0)
        if mul <= 0:
            return amount
        return amount * mul // 100

    def tick_auto_ulti_charge(self):
        if self.state == 4:
            return
        value = int(self.data.get('ChargeUltiAutomatically') or 0) // 4
        if value < 1:
            return
        self.auto_ulti_charge_timer -= 1
        if self.auto_ulti_charge_timer > 0:
            return
        if self.get_player() is None:
            return
        player = self.get_player()
        if player.accessory is not None and player.accessory.is_active:
            if player.accessory.type() == 'auto_super_load_boost':
                value += value * int(player.accessory.data.get('CustomValue1') or 0) // 100
        self.charge_ulti(value, False, True)
        self.auto_ulti_charge_timer = 5

    def give_electrocution(self, damage: int, normal_dmg: int, effect_type: int, bounces: int):
        for buff in list(self.buffs):
            if buff.type == BELLE_WEAPON:
                self.buffs.remove(buff)
        buff = self.apply_buff(BELLE_WEAPON, 20, damage, 0)
        buff.effect_type      = effect_type
        buff.normal_dmg       = normal_dmg
        buff.belle_weapon_bounces = bounces

    def set_silence(self, ticks: int):
        self.silence      = True
        self.silence_tick = self.get_ticks_gone() + ticks

    def add_cc_immunity(self, ticks: int):
        for buff in list(self.buffs):
            if buff.type == SPEED_SLOWER:
                self.buffs.remove(buff)
        self.update_buffed_speed()
        self.cc_immunity_ticks = max(self.cc_immunity_ticks, ticks)

    def has_cc_immunity(self) -> bool:
        return self.cc_immunity_ticks > 0

    def add_shield(self, ticks: int, percentage: int):
        self.shield_percent = percentage
        self.shield_ticks   = ticks

    def add_extra_health_regen(self, ticks: int, amount: int, index: int):
        self.extra_regen_ticks  = ticks
        self.extra_regen_amount = amount
        self.extra_regen_index  = index

    def give_reload_buff(self, ticks: int):
        self.reload_buff_ticks = ticks

    def add_frozen(self, count: float, attacker=None):
        if self.frozen_pct >= 100:
            return
        if self.stun_ticks <= self.get_ticks_gone():
            self.frozen_pct += count
        self.last_frozen_tick  = self.get_ticks_gone()
        self.frozen_decay_tick = self.get_ticks_gone()
        if attacker is not None:
            value = attacker.get_card_value_for_passive('slippery_to_frost', 1)
            if value != -1:
                self.slippery_ticks = max(self.slippery_ticks, value)
            if self.frozen_pct >= 100:
                value = attacker.get_card_value_for_passive('freeze_reload', 1)
                if value != -1:
                    attacker.give_reload_buff(value)

    def tick_frozen(self):
        if self.frozen_pct >= 100:
            self.trigger_stun(20, True)
            if self.get_ticks_gone() == self.last_frozen_tick + 20:
                self.frozen_pct = 0
        if self.slippery_ticks > 0:
            self.slippery_ticks -= 1
        self.slippery = self.slippery_ticks > 0
        if self.last_frozen_tick + 29 < self.get_ticks_gone() and self.frozen_pct > 0:
            if self.get_ticks_gone() - self.frozen_decay_tick >= 6:
                self.frozen_pct -= 1
                self.frozen_decay_tick = self.get_ticks_gone()

    def trigger_shake(self):
        self.shaking = 6

    def trigger_stun(self, ticks: int, force: bool = False):
        if self.is_carryable:
            return
        if ticks >= 1:
            if (not self.is_invincible and not self.has_cc_immunity()) or force:
                self.stun_ticks = ticks
                self.interrupt_all_skills(False)
                if self.get_card_value_for_passive('ulti_defense', 1) >= 0:
                    self.shield_ticks = 0
                if (not self.is_charging and not self.knockbacked) or force:
                    self.stop_movement()
            self.is_weakly_stunned = False

    def interrupt_all_skills(self, keep_ulti: bool):
        for skill in self.skills:
            if skill is None:
                continue
            if keep_ulti and skill.is_ultimate:
                continue
            skill.ticks_active = 0
            skill.on_activate  = False
        self.is_charging   = False
        self.charge_animation = 0

    def get_regenerate_per_second(self) -> int:
        if self.is_hero:
            return 13 * self.max_hp // 100
        return 0

    def block_health_regen(self):
        self.can_heal = False

    def heal(self, dealer_index: int, healing: int, show: bool, projectile_data=None) -> bool:
        if self.hp < 1:
            return False
        for immunity in self.immunities:
            if immunity.target_index == dealer_index and immunity.target_data == projectile_data:
                return False
        previous  = self.hp
        self.hp   = min(self.max_hp, previous + healing)
        healed    = self.hp - previous
        if healed > 0:
            battle = self.get_battle()
            if battle is not None:
                for player in battle.players:
                    if player.team_index == dealer_index // 16 and player.player_index == dealer_index % 16:
                        player.heals += healed
                        break
        if show and self.hp > previous:
            self.damage_numbers.append({'value': -healing, 'dealer': dealer_index, 'delay': 0})
        return True

    def tick_heals(self):
        if not self.can_heal:
            return
        if not self.is_hero:
            return
        if self.is_invincible:
            self.health_regen_blocked_tick = self.get_ticks_gone()
        if self.extra_regen_ticks >= 1:
            self.extra_regen_ticks -= 1
            if (self.extra_regen_ticks + 1) % 20 == 0:
                self.heal(self.extra_regen_index, self.extra_regen_amount, True)
        for buff in self.buffs:
            if buff.type == HEALTH_REGEN and buff.duration % 20 == 0:
                self.heal(buff.source_index, buff.modifier, True)
        value = self.get_card_value_for_passive('repair_self', 1)
        delay = 60
        if value >= 0:
            delay = 60 - value
            if delay <= 21:
                delay = 21
        if self.get_ticks_gone() >= self.health_regened_tick + 20:
            regen = self.get_regenerate_per_second()
            if regen > 0 and self.get_ticks_gone() >= self.health_regen_blocked_tick + delay:
                if self.get_ticks_gone() >= DEPLOY_TICKS_FIRST:
                    if self.hp < self.max_hp:
                        regen += regen * self.get_gear_boost(1) // 100
                    if regen >= 1:
                        self.heal(self.get_index(), regen, False)
                        self.health_regened_tick = self.get_ticks_gone()
        if self.get_ticks_gone() < self.health_regened_tick_sp + 20:
            return
        healed = False
        value = self.get_card_value_for_passive('heal_forest', 1)
        if value >= 0 and self.is_in_bush():
            self.heal(self.get_index(), value * self.max_hp // 1000, True)
            healed = True
        if self.get_active_skill('Invisibility') is not None and self.is_invisible:
            amount = self.get_card_value_for_passive('heal_invisible', 1) * self.max_hp // 1000
            if amount >= 0:
                self.heal(self.get_index(), amount, True)
                healed = True
        if self.aoe_regenerate >= 1 and self.get_battle() is not None:
            for character in self.get_battle().manager.get_characters():
                if character is self or not character.is_alive_state:
                    continue
                if character.get_index() // 16 != self.get_index() // 16:
                    continue
                if not character.is_hero or character.hp >= character.max_hp:
                    continue
                distance = abs(character.x - self.x)
                if distance <= 300 and distance * distance <= 90000:
                    effect = self.add_area_effect(0, 0, area_effect_data('AutoHeal'), 3, False)
                    if effect is not None:
                        effect.damage     = -self.aoe_regenerate
                        effect.normal_dmg = 0
                    self.health_regened_tick = self.get_ticks_gone()
                    healed = True
                    break
        value = self.get_card_value_for_passive('heal_continuous', 1)
        if value >= 1:
            if self.get_ticks_gone() >= self.health_regened_tick_sp + self.get_card_value_for_passive('heal_continuous', 0):
                self.heal(self.get_index(), (self.max_hp - self.hp) * value // 100, False)
                healed = True
        if healed:
            self.health_regened_tick_sp = self.get_ticks_gone()

    def get_buffed_speed(self) -> int:
        total = 0
        for buff in self.buffs:
            if buff.type <= 6 and (1 << buff.type) & 88 != 0:
                total += buff.modifier
        return total

    def set_character_tagged(self, attacker_index: int, tick: int, attacker=None):
        self.tagged = True
        if attacker is not None:
            value = attacker.get_card_value_for_passive('tag_lasts_longer', 1)
            if value >= 1:
                self.last_tag_tick = tick + (4 + value) * 20
                return
        self.last_tag_tick = tick + 80

    def set_king(self):
        self.big_state = True
        self.give_speed_slower_buff(-100, 9999)
        self.can_heal = False
        self.hp       = 100000
        self.max_hp   = 100000

    def set_vision_override(self, x: int, y: int, ticks: int):
        self.vision_override_x     = x
        self.vision_override_y     = y
        self.vision_override_ticks = ticks
        self.stop_movement()

    def set_dragging_object(self, game_object, offset_x: int, offset_y: int):
        if self.has_cc_immunity() or self.is_invincible or self.is_charging:
            return
        self.dragging_object   = game_object
        self.dragging_offset_x = offset_x
        self.dragging_offset_y = offset_y
        self.move_start        = self.get_ticks_gone() - 1
        self.move_end          = self.get_ticks_gone() - 1
        self.interrupt_all_skills(False)

    def is_in_water(self) -> bool:
        battle = self.get_battle()
        if battle is None:
            return False
        tile = battle.tilemap.get_tile(self.x // 300, self.y // 300)
        if tile is None:
            return False
        return tile.code == 'W' and not tile.is_destructed()

    def is_object(self) -> bool:
        return not self.has_auto_attack and self.speed == 0

    def push_out_of_walls(self):
        if self.is_carryable:
            return
        if self.is_steer_movement_active() or self.dragging_object is not None:
            return
        if self.knockbacked or self.is_charging:
            return
        if self.immun_to_pushback_out_of_walls:
            return
        battle = self.get_battle()
        if battle is None:
            return
        tile_x = self.x // 300
        tile_y = self.y // 300
        if battle.tilemap.is_passable(tile_x, tile_y):
            return
        if self.x % 300 < 150:
            tile_x -= 1
        else:
            tile_x += 1
        if battle.tilemap.is_passable(tile_x, self.y // 300):
            self.x = tile_x * 300 + 150
            return
        if self.y % 300 < 150:
            tile_y -= 1
        else:
            tile_y += 1
        if battle.tilemap.is_passable(self.x // 300, tile_y):
            self.y = tile_y * 300 + 150

    def is_steer_movement_active(self) -> bool:
        return self.steer_active

    def get_closest_projectile_flying_against_you(self):
        battle = self.get_battle()
        if battle is None:
            return None
        closest  = None
        distance = 99999999
        for projectile in battle.manager.get_projectiles():
            if projectile.get_index() // 16 == self.get_index() // 16 or projectile.state == 4:
                continue
            distance_to_projectile = path_length(self.x, self.y, projectile.x, projectile.y)
            if distance_to_projectile < distance:
                closest  = projectile
                distance = distance_to_projectile
        return closest

    def get_weapon_skill(self):
        return self.skills[0] if len(self.skills) > 0 else None

    def get_ultimate_skill(self):
        return self.skills[1] if len(self.skills) > 1 else None

    def get_skill(self, behavior_type: str):
        for skill in self.skills:
            if skill is not None and skill.behavior_type() == behavior_type:
                return skill
        return None

    def has_active_skill(self) -> bool:
        for skill in self.skills:
            if skill is not None and skill.is_active():
                return True
        return False

    def get_current_casting_skill(self):
        for skill in self.skills:
            if skill is None:
                continue
            if skill.on_activate and int(skill.data.get('CastingTime') or 0) > 0:
                return skill
            if skill.ticks_active >= 1:
                return skill
        return None

    def get_hero_level(self) -> int:
        return self.hero_level

    def get_power_level(self) -> int:
        if self.unique_property == 1:
            if self.charge_up_max < 1:
                return 0
            return clamp(3 * self.charge_up // self.charge_up_max, 0, 2)
        player = self.get_player()
        if player is not None:
            return int(self.power_level)
        return 0

    def get_unbuffed_speed(self) -> int:
        total = self.static_speed_buff
        if self.has_power_levels and self.get_power_level() > 0:
            total += 170
        if self.unique_property == 1:
            total += 60 * self.get_power_level()
        player = self.get_player()
        if player is not None and player.over_charging:
            total += 20 * self.speed // 100
        return total

    def get_radius(self) -> int:
        return int(self.data.get('CollisionRadius') or 0)

    def get_skill_holded_ticks(self) -> int:
        if self.skill_hold_ticks < 0:
            return 0
        return min(self.skill_hold_ticks, self.get_max_hold_ticks())

    def has_ulti(self) -> bool:
        if not self.is_hero:
            return self.is_boss
        player = self.get_player()
        if player is not None:
            return player.has_ulti()
        return False

    def ulti_used(self):
        player = self.get_player()
        if player is not None:
            player.use_ulti()
            self.using_ulti = False
        self.ultiing = True

    def ulti_button_pressed_twice(self):
        if self.is_charging and self.active_charge_type == 1:
            self.stop_movement()
            self.interrupt_all_skills(True)

    def is_pet(self) -> bool:
        if self.get_team_index() != -1:
            return False
        if self.get_index() < 0:
            return False
        return not self.is_hero

    def is_player_control_removed(self) -> bool:
        if self.is_charging or self.knockbacked or self.stun_ticks > 0:
            return True
        return self.dragging_object is not None

    def get_path_length(self) -> int:
        return path_length(self.way_point_start[0], self.way_point_start[1],
                           self.way_point[0], self.way_point[1])

    def set_start_rotation(self, angle: int):
        self.move_angle   = angle
        self.attack_angle = angle

    def reset_afk_ticks(self):
        self.afk_ticks = 0

    def set_forced_angle(self, angle: int):
        self.move_angle         = angle
        self.attack_angle       = angle
        self.forced_angle_ticks = self.get_ticks_gone()

    def set_control(self, owner, ticks: int):
        self.is_controlled        = True
        owner.controlled_character = owner

    def set_invisible(self, ticks: int = 3):
        if self.invisible_ticks <= 0:
            self.is_invisible = True
        self.invisible_ticks = ticks

    def reset_items_collected(self):
        self.item_count = 0

    def add_items_collected(self, count: int):
        self.item_count += count
        battle = self.get_battle()
        if battle is not None and battle.gmv == 3:
            self.item_count = min(6, self.item_count)

    def cripple(self, percent: int, ticks: int = 80):
        self.is_crippled      = True
        self.cripple_percent  = percent
        self.cripple_end_tick = self.get_ticks_gone() + ticks

    def eye_active(self):
        if self.yellow_eye:
            return
        self.yellow_eye = True
        self.eye_tick   = self.get_ticks_gone() + 160

    def watch(self, target):
        self.set_start_rotation(get_angle(target.x - self.x, target.y - self.y))

    def should_destruct(self) -> bool:
        return self.hp <= 0 and self.destruct_after_ticks < 1

    def is_tile_blocking(self, x: int, y: int) -> bool:
        battle = self.get_battle()
        if battle is None:
            return False
        tile_x = x // 300
        tile_y = y // 300
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                tx = tile_x + dx
                ty = tile_y + dy
                if tx < 0 or tx >= battle.tilemap.width or ty < 0 or ty >= battle.tilemap.height:
                    continue
                tile = battle.tilemap.get_tile(tx, ty)
                if tile is None or tile.is_destructed():
                    continue
                if tile.blocks_movement or tile.blocks_projectiles:
                    return True
        return False

    def trigger_immun_to_push_out_of_walls(self, ticks: int):
        self.immun_to_pushback_out_of_walls = True

    def get_enemy(self):
        battle = self.get_battle()
        if battle is None:
            return None
        closest  = None
        distance = 99999999
        for enemy in battle.manager.get_visible_game_objects(self.get_index(), self.get_global_id()):
            if enemy.get_object_type() != OBJECT_TYPE_CHARACTER:
                continue
            if enemy.hp <= 0 or enemy.is_carryable:
                continue
            if enemy.get_index() // 16 == self.get_index() // 16:
                continue
            distance_to_enemy = path_length(self.x, self.y, enemy.x, enemy.y)
            if distance_to_enemy < distance:
                closest  = enemy
                distance = distance_to_enemy
        return closest

    def get_closest_enemy(self, range_subtiles: int, target_teammates: bool = False,
                          ignore_visibility: bool = False, require_los: bool = False):
        battle = self.get_battle()
        if battle is None:
            return None
        closest  = None
        distance = range_subtiles * 100
        for enemy in battle.manager.get_characters():
            if enemy.hp <= 0 or enemy.is_carryable or not enemy.is_alive_state:
                continue
            same_team = enemy.get_index() // 16 == self.get_index() // 16
            if same_team and not target_teammates:
                continue
            if not same_team and target_teammates:
                continue
            if enemy.is_immune_and_bullets_go_through(self.is_in_realm) or enemy.is_invincible:
                continue
            if enemy.get_fade_counter() < 1 and not ignore_visibility:
                continue
            distance_to_enemy = path_length(self.x, self.y, enemy.x, enemy.y)
            if distance_to_enemy < distance:
                closest  = enemy
                distance = distance_to_enemy
        return closest

    def get_teammate_for_heal(self):
        battle = self.get_battle()
        if battle is None:
            return None
        closest  = None
        distance = 99999999
        for character in battle.manager.get_visible_game_objects(self.get_index(), self.get_global_id()):
            if character.get_object_type() != OBJECT_TYPE_CHARACTER:
                continue
            if character.hp <= 0 or character.hp >= character.max_hp:
                continue
            if not character.is_hero or character.is_carryable:
                continue
            if character.get_index() // 16 != self.get_index() // 16:
                continue
            distance_to_character = path_length(self.x, self.y, character.x, character.y)
            if distance_to_character < distance:
                closest  = character
                distance = distance_to_character
        return closest

    def get_active_pet(self, ignore_base: bool = False):
        battle = self.get_battle()
        if battle is None:
            return None
        for character in battle.manager.get_characters():
            if character is self or character.get_index() != self.get_index():
                continue
            if not character.is_alive_state:
                continue
            if not ignore_base or character.speed > 0:
                return character
        return None

    def get_controlled_projectile(self):
        battle = self.get_battle()
        if battle is None:
            return None
        for projectile in battle.manager.get_projectiles():
            if projectile.get_index() == self.get_index():
                if projectile.data.get('TravelType', '') == '5':
                    return projectile
        return None

    def get_normal_weapon_damage(self) -> int:
        if not self.skills:
            return 0
        damage = self.skills[0].damage()
        return damage + int(5 * damage / 100) * (self.hero_level + self.damage_multiplier)

    def get_absolute_damage(self, damage: int) -> int:
        return damage + int(5 * damage / 100) * (self.hero_level + self.damage_multiplier) + damage * self.damage_modifier // 100

    def get_damage_buff_temporary(self) -> int:
        total = 0
        for buff in self.buffs:
            if buff.type in (DAMAGE, DAMAGE_AND_SIZE, DAMAGE2):
                total += buff.modifier
        player = self.get_player()
        if player is not None and player.over_charging:
            total += 20
        return total

    def get_buffed_health_regen(self) -> int:
        total = 0
        for buff in self.buffs:
            if buff.type == HEALTH_REGEN:
                total += 1
        return total

    def handle_heal_from_damage(self, damage: int, is_ulti: bool, target=None):
        if self.hp < 1 or target is None:
            return
        if target.is_hero:
            value = target.get_card_value_for_passive('ulti_heals_self', 1)
            if value >= 1 and is_ulti:
                target.heal(target.get_index(), value * target.max_hp // 100, True)
        elif self.is_hero:
            value = self.get_card_value_for_passive('heal_from_damage', 1)
            if value >= 1:
                self.heal(self.get_index(), damage * value // 100, True)

    def show_damage_number(self, value: int, dealer_index: int, dealer=None):
        delayed = 0
        if dealer is not None and dealer.weapon_skill is not None:
            if dealer.weapon_skill.bullets_per_shot() > 1:
                delayed = _DAMAGE_NUMBER_DELAY_TICKS
        if not self.damage_numbers:
            self.damage_numbers.append({'value': value, 'dealer': dealer_index, 'delay': delayed})
            return
        for damage in self.damage_numbers:
            if damage.get('dealer', -1) == dealer_index:
                damage['value'] = damage.get('value', 0) + value
                return
        self.damage_numbers.append({'value': value, 'dealer': dealer_index, 'delay': delayed})

    def tick_invisibility(self):
        self.visibility_state = 0
        if self.invisible_ticks < 1:
            self.is_invisible = False
            self.yellow_eye   = False
        else:
            self.invisible_ticks -= 1
            if self.invisible_ticks < 1:
                self.visibility_state = 2
                self.invisible_ticks  = 0
                self.is_invisible     = False
                self.yellow_eye       = False
            else:
                self.is_invisible = True
        if self.get_active_skill('Invisibility') is not None:
            if self.invisible_ticks <= 0:
                self.visibility_state = 1
            self.invisible_ticks = 3
            self.is_invisible    = True
        if self.yellow_eye and self.eye_tick != 0 and self.get_ticks_gone() >= self.eye_tick:
            self.yellow_eye = False

    def tick_star_powers(self):
        if self.get_player() is None:
            return
        value = self.get_card_value_for_passive('shield_while_ulti', 1)
        if value >= 1:
            if self.get_controlled_projectile() is not None:
                self.add_shield(2, value)
            return
        value = self.get_card_value_for_passive('bush_shield', 1)
        if value >= 1:
            if self.is_in_bush():
                self.add_shield(self.get_card_value_for_passive('bush_shield', 0), value)
            return
        value = self.get_card_value_for_passive('speed_full_ammo', 1)
        if value >= 1:
            if self.is_charge_up_ready():
                self.give_speed_faster_buff(value, 10)
            return
        value = self.get_card_value_for_passive('speed_low_health', 0)
        if value >= 1:
            if self.get_hitpoint_percentage() <= value:
                self.give_speed_faster_buff(self.get_card_value_for_passive('speed_low_health', 1), 10)
            return
        value = self.get_card_value_for_passive('berserker', 1)
        if value >= 1:
            if self.get_hitpoint_percentage() <= value:
                self.give_reload_buff(10)
            return
        value = self.get_card_value_for_passive('low_health_shield', 1)
        if value >= 1:
            if self.get_hitpoint_percentage() <= value:
                self.add_shield(4, self.get_card_value_for_passive('low_health_shield', 0))
            return
        value = self.get_card_value_for_passive('shield_homerun', 1)
        if value >= 1:
            if self.is_charge_up_ready():
                self.add_shield(4, value)
            return
        value = self.get_card_value_for_passive('shield_while_charged_shots', 1)
        if value >= 1:
            if self.charged_shot_count >= 1:
                self.add_shield(4, value)
            return
        value = self.get_card_value_for_passive('shield_while_charged_up', 1)
        if value >= 1:
            if self.is_charge_up_ready():
                self.add_shield(4, value)
        value = self.get_card_value_for_passive('charged_bullet_speed', 1)
        if value >= 1:
            if self.is_charge_up_ready():
                self.attack_accelerating_factor = value * 2
            else:
                self.attack_accelerating_factor = 0
        value = self.get_card_value_for_passive('speed_ulti', 1)
        if value >= 1:
            if self.has_ulti():
                self.give_speed_faster_buff(value, 10)
            return
        value = self.get_card_value_for_passive('medikit', 1)
        if value >= 1:
            if self.get_hitpoint_percentage() <= value and self.is_charge_up_ready():
                self.heal(self.get_index(), self.get_card_value_for_passive('medikit', 0), True)
                self.charge_up = 0
            return

    def tick_area_effect_for_charge(self):
        if self.way_point[0] == self.way_point_start[0]:
            return
        if self.way_point[1] == self.way_point_start[1]:
            return
        self.add_area_effect(0, 0, area_effect_data('RollerFire'), 2, False)

    def set_item_summoning_variables(self, item_data, num_spawns: int, max_spawns: int, damage: int, normal_dmg: int):
        self.spawned_item_data       = item_data
        self.num_spawns_item         = num_spawns
        self.max_spawns_item         = max_spawns
        self.spawned_item_damage     = damage
        self.spawned_item_normal_dmg = normal_dmg

    def set_immunity(self, target_index: int, ticks: int, target_data=None):
        return self.add_immunity(target_index, target_data, ticks)

    def add_consumable_shield(self, amount: int, duration_ms: int):
        if self.consumable_shield < amount:
            self.consumable_shield          = amount
            self.consumable_shield_max      = amount
            self.consumable_shield_tick     = self.get_ticks_gone()
            self.consumable_shield_duration = duration_ms

    def get_current_active_or_casting_skill(self):
        casting = self.get_current_casting_skill()
        if casting is not None:
            return casting
        for skill in self.skills:
            if skill is not None and skill.is_active():
                return skill
        return None

    def hold_skill_started(self):
        self.skill_hold_ticks = 0

    def end_rapid_fire(self):
        self.attacking_ticks = 0

    def reset_events_on_tick(self):
        self.is_teleporting  = False
        self.hit_effect_projectile = 0
        self.hit_effect_skin       = 0
        for damage in list(self.damage_numbers):
            if damage.get('delay', 0) <= 0:
                self.damage_numbers.remove(damage)
            else:
                damage['delay'] -= 1

    def spawn_hit_effect(self, effect_name: str):
        battle = self.get_battle()
        if battle is None:
            return None
        effect = self.add_area_effect(0, 0, area_effect_data(effect_name), 1, False)
        return effect

    def trigger_rapid_fire(self, x: int, y: int, attack_pattern: int, bullets: int,
                           ms_between_attacks: int, projectile_data, damage: int, shoot_range: int,
                           spread: int, active_time: int, normal_dmg: int, first_immediately: bool):
        self.melee_attack_pushbacks = False
        if self.charge_up_type == 1:
            if self.is_charge_up_ready():
                if self.name == 'CannonGirlSmall':
                    damage += 240
                    self.add_shield(10, 40)
                    self.charge_up = 0
                else:
                    self.melee_attack_pushbacks = True
                    self.charge_pushback = int(self.data.get('ChargePushback') or 0)
            if self.name != 'CannonGirlSmall':
                self.charge_up = 0
        self.attacking            = True
        if projectile_data and (str(projectile_data.get('Indirect', '')).lower() == 'true'
                                or int(projectile_data.get('TravelType') or 0) == 6):
            self.attack_target_x = x
            self.attack_target_y = y
            vector_x = x - self.x
            vector_y = y - self.y
        else:
            vector_x = x - self.x
            vector_y = y - self.y
            vector_length = path_length(0, 0, vector_x, vector_y)
            if vector_length > 0:
                vector_x = vector_x * 100 * shoot_range // vector_length
                vector_y = vector_y * 100 * shoot_range // vector_length
        self.attack_vector_x      = vector_x
        self.attack_vector_y      = vector_y
        self.rapid_fire_x         = x
        self.rapid_fire_y         = y
        self.rapid_fire_attack_pattern  = attack_pattern
        self.rapid_fire_bullets         = bullets
        self.rapid_fire_ms_between_attacks = ms_between_attacks
        self.rapid_fire_projectile      = projectile_data
        self.rapid_fire_damage          = damage
        self.rapid_fire_normal_dmg      = normal_dmg
        self.rapid_fire_range           = shoot_range
        self.rapid_fire_spread          = spread
        self.rapid_fire_shoot_times     = active_time // ms_between_attacks if ms_between_attacks > 0 else 1
        self.shoot_index                = 0
        self.skill_hold_ticks           = -1
        if first_immediately:
            self.last_attack_tick = -100
        else:
            self.last_attack_tick = self.get_ticks_gone()

    def tick_rapid_fire(self):
        self.state = 2
        ticks = self.get_ticks_gone()
        self.rapid_fire_tick = ticks
        projectile_data = self.rapid_fire_projectile
        target_x = self.rapid_fire_x
        target_y = self.rapid_fire_y
        if projectile_data:
            indirect = str(projectile_data.get('Indirect', '')).lower() == 'true'
            if not indirect and int(projectile_data.get('TravelType') or 0) != 6:
                target_x = self.attack_vector_x + self.x
                target_y = self.attack_vector_y + self.y
        if self.rapid_fire_attack_pattern == 12:
            distance = self.charge_speed // 20 * self.rapid_fire_ms_between_attacks // 50
            target_x = self.x + get_rotated_x(distance, 0, self.move_angle)
            target_y = self.y + get_rotated_y(distance, 0, self.move_angle)
        if self.rapid_fire_shoot_times >= 0 and self.shoot_index >= self.rapid_fire_shoot_times:
            return
        if self.last_attack_tick + self.get_current_attack_speed_ticks() > ticks:
            return
        damage = self.rapid_fire_damage
        damage += self.get_damage_buff_temporary() * damage // 100
        self.fire_attack(target_x, target_y, None, damage)
        self.shoot_index      += 1
        self.last_attack_tick  = ticks
        self.attacking_ticks   = MAX_ATTACK_TICKS

    def set_character_summoning_variables(self, data, num_spawns: int, max_spawns: int, damage: int, health: int):
        self.summoned_character = data
        self.num_spawns_item    = num_spawns
        self.max_spawns_item    = max_spawns
        self.spawned_item_damage     = damage
        self.spawned_item_normal_dmg = health

    def trigger_transforming(self, data):
        battle = self.get_battle()
        if battle is None or not data:
            return self
        from G.GameObjectFactory import create_character_by_name
        index  = self.get_index()
        player = self.get_player()
        transformed = create_character_by_name(data.get('_name', ''))
        if transformed is None:
            return self
        if self.unique_property == 7:
            transformed.hp = self.hp
        transformed.item_count         = self.item_count
        transformed.battle_royale_buffs = self.battle_royale_buffs
        transformed.set_index(index)
        transformed.set_position(self.x, self.y, 0)
        transformed.set_bot(self.is_bot)
        transformed.set_hero_level(self.hero_level)
        if self.weapon_skill is not None and transformed.weapon_skill is not None:
            transformed.weapon_skill.charge = self.weapon_skill.charge
        transformed.block_health_regen()
        battle.manager.add(transformed)
        transformed.spawn_tick = self.spawn_tick
        if player is not None:
            player.own_object_id = transformed.object_global_id
        battle.manager.remove(self)
        self.transform_animation = True
        return transformed

    def trigger_charge(self, x: int, y: int, speed: int, charge_type: int, damage: int,
                       pushback: int, returning: bool, area_data=None):
        battle = self.get_battle()
        if battle is None:
            return False
        border = closest_level_border_collision(self.x, self.y, x, y,
                                                battle.tilemap.logic_width, battle.tilemap.logic_height)
        if border is not None:
            if border[0] > x:
                border = (border[0] + 50, border[1])
            elif border[0] < x:
                border = (border[0] - 50, border[1])
            if border[1] > y:
                border = (border[0], border[1] + 50)
            elif border[1] < y:
                border = (border[0], border[1] - 50)
            x, y = border
        if self.charge_up_type == 1:
            self.charge_up = 0
        value = self.get_card_value_for_passive('heal_on_charge', 1)
        if value >= 1:
            self.heal(self.get_index(), value, True)
        if charge_type != 10 or returning:
            value = self.get_card_value_for_passive('shield_charge', 1)
            if value >= 1:
                self.add_shield(self.get_card_value_for_passive('shield_charge', 2), value)
            self.stun_ticks = 0
            self.charge_hits = 0
        self.charge_hit_ids   = []
        self.charge_damage    = damage
        self.charge_pushback  = pushback
        self.charge_speed     = speed
        self.charge_type      = charge_type
        self.charge_start_ticks = self.get_ticks_gone()
        self.active_charge_type = charge_type
        self.is_charging      = True
        self.charge_animation = charge_type
        self.steer_active     = False
        self.move_to(x, y)
        if self.move_end - self.move_start > 0:
            self.move_end = self.move_start + max(1, 20 * self.path_length // max(1, speed))
        self.attack_angle = get_angle(x - self.x, y - self.y)
        return True

    def tick_charge(self):
        if not self.is_charging:
            return
        charge_type = self.active_charge_type
        if charge_type not in (1, 3, 4, 5, 7, 8, 9, 10, 12, 14, 16):
            return
        radius = 400
        if self.is_boss:
            radius = 800
        if charge_type in (3, 9):
            radius = 800
        damage = self.charge_damage
        damage += self.charge_damage * self.get_damage_buff_temporary() // 100
        damage -= self.charge_damage * self.cripple_percent // 100
        battle = self.get_battle()
        if battle is None:
            return
        for identifier in list(self.charge_hit_ids):
            entry = identifier
            entry['ticks'] -= 1
            if entry['ticks'] <= 0:
                self.charge_hit_ids.remove(entry)
        for character in battle.manager.get_characters():
            if character is self or not character.is_alive_state:
                continue
            if character.get_index() // 16 == self.get_index() // 16:
                continue
            if character.is_immune_and_bullets_go_through(self.is_in_realm):
                continue
            dx = character.x - self.x
            dy = character.y - self.y
            if abs(dx) > radius or abs(dy) > radius:
                continue
            if dx * dx + dy * dy > radius * radius:
                continue
            hit_ids = [entry['gid'] for entry in self.charge_hit_ids]
            if character.get_global_id() in hit_ids:
                continue
            if charge_type == 10:
                self.charge_hit_ids.append({'gid': character.get_global_id(), 'ticks': 100})
                hit_damage = character.get_hitpoint_percentage() * damage // 100
                if hit_damage < damage // 4:
                    hit_damage = damage // 4
                self.charge_normal_dmg = 1000
                damage = hit_damage
            elif not self.is_train:
                self.charge_hit_ids.append({'gid': character.get_global_id(), 'ticks': 10})
            if character.cause_damage(damage, self, self.using_ulti):
                self.charge_hits += 1
                value = self.get_card_value_for_passive('charge_end_damage', 1)
                if value > 0:
                    self.charge_damage += value
                if self.charge_pushback >= 1:
                    character.trigger_pushback(self.x, self.y, self.charge_pushback)

    def trigger_whirlwind(self, damage: int, normal_dmg: int, speed_increase: int):
        self.charge_damage     = damage
        self.charge_normal_dmg = normal_dmg
        self.using_ulti        = True
        self.charge_hit_ids    = []
        self.apply_buff(SPEED_FASTER, 2, speed_increase, 0)
        value = self.get_card_value_for_passive('ulti_defense', 1)
        if value > 0:
            self.add_shield(value, self.get_card_value_for_passive('ulti_defense', 0))

    def tick_whirlwind(self):
        skill = self.get_active_skill('Ww')
        if skill is None:
            return
        self.apply_buff(SPEED_FASTER, 2, skill.ms_between_attacks(), 0)
        damage = self.charge_damage
        damage += self.charge_damage * self.get_damage_buff_temporary() // 100
        damage -= self.charge_damage * self.cripple_percent // 100
        for entry in list(self.charge_hit_ids):
            entry['ticks'] -= 1
            if entry['ticks'] <= 0:
                self.charge_hit_ids.remove(entry)
        if self.knockbacked:
            return
        battle = self.get_battle()
        if battle is None:
            return
        radius = 100 * skill.casting_range()
        for character in battle.manager.get_characters():
            if character is self or not character.is_alive_state:
                continue
            if character.get_index() // 16 == self.get_index() // 16:
                continue
            if character.is_immune_and_bullets_go_through(self.is_in_realm):
                continue
            dx = character.x - self.x
            dy = character.y - self.y
            if abs(dx) > radius or abs(dy) > radius:
                continue
            if dx * dx + dy * dy > radius * radius:
                continue
            hit_ids = [entry['gid'] for entry in self.charge_hit_ids]
            if character.get_global_id() in hit_ids:
                continue
            self.charge_hit_ids.append({'gid': character.get_global_id(), 'ticks': 5})
            character.cause_damage(damage, self, self.using_ulti)

    def tick_projectile_shield(self):
        if not self.has_active_skill_behavior('ProjectileShield'):
            return

    def has_active_skill_behavior(self, behavior_type: str) -> bool:
        for skill in self.skills:
            if skill is None:
                continue
            if skill.behavior_type() == behavior_type and skill.ticks_active > 0:
                return True
        return False

    def tick_attacking_state(self):
        if self.has_active_skill_behavior('Attack'):
            self.state = 2
            if self.rapid_fire_tick != self.get_ticks_gone():
                self.tick_rapid_fire()
        elif self.has_active_skill_behavior('Ww'):
            self.state = 0
            self.block_health_regen()
            self.tick_whirlwind()
        if self.is_charging:
            self.tick_charge()

    def get_current_attack_speed_ticks(self) -> int:
        for skill in self.skills:
            if skill is None:
                continue
            if skill.behavior_type() == 'Attack' and skill.ticks_active > 0:
                if self.rapid_fire_ms_between_attacks >= 1:
                    return self.rapid_fire_ms_between_attacks // 50
        if self.casting_time >= 1:
            for skill in self.skills:
                casting = int(skill.data.get('CastingTime') or 0)
                if casting >= 1:
                    return casting // 50
        if not self.is_boss and self.weapon_skill is not None:
            return self.weapon_skill.ms_between_attacks() // 50
        return int(self.data.get('AutoAttackSpeedMs') or 0) // 50

    def tick_timers(self):
        ticks = self.get_ticks_gone()
        if self.attached_character is not None:
            self.set_position(self.attached_character.x, self.attached_character.y, 0)
        if self.silence and self.silence_tick < ticks:
            self.silence = False
        if self.unique_property == 1 and ticks - self.last_rage_tick >= 21:
            self.charge_up = max(0, self.charge_up - 3)
            self.last_rage_tick = ticks
        if self.realm_timer >= 1:
            self.realm_timer -= 1
        if self.realm_timer == 0:
            self.is_in_realm = False
        if self.rapid_fire_tick != ticks:
            attack_speed = self.get_current_attack_speed_ticks()
            self.attacking_ticks = clamp(self.last_attack_tick + attack_speed - ticks, 0, MAX_ATTACK_TICKS)
        if self.last_tag_tick <= ticks:
            self.tagged = False
        self.is_crippled = ticks < self.cripple_end_tick
        if not self.is_crippled:
            self.cripple_percent = 0
        if self.vision_override_ticks >= 1:
            self.vision_override_ticks -= 1
        if self.shield_ticks >= 1:
            self.shield_ticks -= 1
        if self.cc_immunity_ticks >= 1:
            self.cc_immunity_ticks -= 1
        if self.shaking >= 1:
            self.shaking -= 1
        if self.reload_buff_ticks >= 1:
            self.reload_buff_ticks -= 1
        if self.skill_hold_ticks >= 0:
            self.skill_hold_ticks += 1
        if ticks <= self.spawn_tick + 60:
            self.is_invincible = True
        else:
            self.is_invincible = False
        if self.carryable_pick_ticks > 0:
            self.carryable_pick_ticks -= 1
        if self.carryable_person_immun_ticks > 0:
            self.carryable_person_immun_ticks -= 1
        max_charge = self.charge_up_max
        if max_charge > 0 and self.name == 'Ghost':
            self.immun_to_pushback_out_of_walls = True
            self.charge_up -= 1
        if self.charge_up_type in (1, 2, 6) and self.state != 4:
            if self.charge_up_type != 1 or self.weapon_skill is None or self.weapon_skill.has_full_charge():
                self.charge_up = min(self.charge_up + 50, max_charge)
        elif self.charge_up_type == 10:
            if self.state in (1, 3):
                self.charge_up = 0
            elif self.state != 4:
                self.charge_up = min(self.charge_up + 50, max_charge)
        if self.get_card_value_for_passive('longer_dash', 1) >= 0 and not self.longer_dash_gauge_ready:
            dash_ms = self.get_card_value_for_passive('longer_dash', 2)
            if dash_ms <= 0:
                dash_ms = 2500
            dash_ticks = dash_ms // 50
            if self.weapon_skill is not None and self.weapon_skill.has_full_charge() and self.state != 4:
                if self.longer_dash_gauge_timer <= 0:
                    self.longer_dash_gauge_timer = dash_ticks
                self.longer_dash_gauge_timer -= 1
                if self.longer_dash_gauge_timer <= 0:
                    self.longer_dash_gauge_ready = True
            elif self.weapon_skill is not None and not self.weapon_skill.has_full_charge():
                self.longer_dash_gauge_timer = 0
        if self.consumable_shield >= 1 and ticks > self.consumable_shield_tick:
            if self.consumable_shield_duration >= 20 and (ticks - self.consumable_shield_tick) % (self.consumable_shield_duration // 20) == 0:
                self.consumable_shield = max(0, self.consumable_shield - self.consumable_shield_max // 20)
        for damage in list(self.damage_numbers):
            if damage.get('delay', 0) > 0:
                damage['delay'] -= 1

    def tick(self):
        if not self.is_alive_state:
            return
        self.ticks_gone = self.get_ticks_gone()
        self.update_position()
        if self.path_length >= 1 and self.move_end > self.get_ticks_gone():
            self.move_angle = get_angle(self.way_point[0] - self.x, self.way_point[1] - self.y)
        if self.attacking_ticks > 0:
            self.attacking_ticks -= 1
        if self.stun_ticks > 0:
            self.stun_ticks -= 1
        if self.knockback_ticks > 0:
            self.knockback_ticks -= 1
            if self.knockback_ticks == 0:
                self.knockbacked = False
        self.tick_gears()
        self.tick_effects()
        self.tick_skills()
        self.tick_attacking_state()
        self.tick_timers()
        self.tick_invisibility()
        self.tick_star_powers()
        self.tick_heals()
        self.tick_frozen()
        self.tick_auto_ulti_charge()

    def encode(self, bs: BitStream, is_own: bool, vision_team: int = 0):
        super().encode(bs, is_own, vision_team)

        is_own_hero = is_own and self.is_hero
        v4 = (self.has_very_much_hit_points and self.is_hero) or self.max_hp > 65535
        v5 = self.is_boss
        v6 = self.is_hero and self.weapon_skill is not None and self.weapon_skill.charged_shot_count() >= 1
        v9 = clamp(self.attacking_ticks, 0, MAX_ATTACK_TICKS)

        if self.has_auto_attack or self.speed != 0 or self.is_training_dummy:
            if is_own:
                bs.write_boolean(self.is_control_removed)
                forced = (self.forced_angle_ticks + 1 >= self.ticks_gone) or self.steer_active
                if bs.write_boolean(forced) or self.is_control_removed:
                    bs.wpi9(self.attack_angle & 0x1FF)
                    bs.wpi9(self.move_angle & 0x1FF)
            else:
                bs.wpi9(self.attack_angle & 0x1FF)
                bs.wpi9(self.move_angle & 0x1FF)

            bs.wpi3(self.state & 0x7)
            bs.write_boolean(False)
            bs.write_int(v9, 6)
            bs.write_boolean(self.knockbacked)
            if bs.write_boolean(self.stun_ticks >= 1):
                bs.write_boolean(False)
            bs.write_boolean(self.shaking > 0)
            bs.write_boolean(self.star_power_ic)
        else:
            bs.wpi3(self.state & 0x7)
            if self.is_train or self.manual_rotations:
                bs.wpi9(self.attack_angle & 0x1FF)
                bs.wpi9(self.move_angle & 0x1FF)
            elif self.area_effect_name:
                bs.wpi9(self.move_angle & 0x1FF)

        bs.woften0_65535(self.hit_effect_projectile)
        bs.woften0_65535(self.hit_effect_skin)

        bs.write_boolean(self.slippery)
        bs.write_boolean(self.has_buff(4))
        bs.write_boolean(self.has_buff(3))
        bs.write_boolean(False)
        bs.write_boolean(False)
        if bs.write_boolean(self.has_buff(14)):
            bs.wpi2(self.get_buff(14).effect_type)
        bs.write_boolean(self.has_buff(15))
        bs.write_boolean(False)

        bs.woften0_255(clamp(int(self.frozen_pct), 0, 100))
        bs.woften0_255(len(self.poisons))
        if len(self.poisons) >= 1:
            for poison in self.poisons:
                bs.wpi3(poison.type)
            bs.write_boolean(False)

        bs.woften0_255(clamp(-1, 0, 255))

        if v5:
            bs.wpi21(self.hp)
            bs.wpi21(self.max_hp)
        elif v4 and not self.is_hero:
            bs.wpi19(self.hp)
            bs.wpi19(self.max_hp)
        else:
            bs.wpvint65535(self.hp)
            bs.wpvint65535(self.max_hp)

        if self.is_decoy:
            bs.write_boolean(False)

        if self.is_hero or self.is_decoy:
            bs.woften0_255(self.item_count + self.battle_royale_buffs)

            if bs.write_boolean(self.consumable_shield > 0):
                bs.wpi11(self.consumable_shield)
                bs.wpi11(self.consumable_shield_max)
            bs.write_boolean(self.has_buff(13))
            if not self.is_alive_state:
                bs.write_boolean(False)

        if self.is_hero:
            battle = self.get_battle()
            carryable = getattr(battle, 'carryable', None) if battle else None

            if carryable is not None and carryable.carrying_character is self:
                bs.write_boolean(True)
                bs.woften0_65535(0)
                bs.woften0_65535(0)
                bs.wpvint65535(carryable.object_global_id % 1000000)
            elif battle is not None and mode_has_carryables(battle.gmv):
                bs.write_boolean(False)

            bs.woften0_255(0)
            bs.write_boolean(self.big_state)
            bs.write_boolean(False)

            if bs.write_boolean(True):
                bs.write_boolean(self.is_charge_active())
                bs.write_boolean(self.is_invincible)
                bs.write_boolean(False)
                bs.write_boolean(False)
                bs.write_boolean(self.ultiing)
                bs.write_boolean(self.using_ulti)

            if is_own:
                if bs.write_boolean(self.vision_override_ticks >= 1):
                    bs.wi16(self.vision_override_x)
                    bs.wi16(self.vision_override_y)

            if v6:
                bs.write_int(self.charged_shot_count, 2)

            if self.should_encode_pet_status or (self.unique_property == 13 and self.is_hero):
                bs.write_boolean(False)

            if self.has_power_levels or self.unique_property == 1:
                bs.wpi2(self.power_level)

            bs.write_boolean(False)

            if self.is_charge_active():
                bs.write_positive_int(self.charge_animation, 8)
                bs.write_positive_int(self.active_charge_type & 0xF, 4)

            if self.charge_up_type in (1, 7, 11, 12):
                bs.woften0_255(self.charge_up // 50)
            elif self.charge_up_type == 5:
                pass
            elif self.charge_up_type == 8:
                bs.wpi10(clamp(self.charge_up, 0, 1023))
            elif self.charge_up_type == 9:
                bs.wpi3(self.charged_shot_count)
            elif self.charge_up_type != 0:
                bs.wpi10(clamp(self.charge_up // 50, 0, 1023))
        elif self.secondary_pet:
            bs.write_positive_int(0, 2)
        elif self.is_carryable:
            trail = 0
            if self.z > 0:
                trail = 2 if self.total_kick_distance > 2400 else 1
            bs.wpi3(trail)
            bs.write_positive_int(0, 2)
        else:
            if self.encodes_charge_behavior():
                if bs.write_boolean(self.is_charging):
                    bs.write_positive_int(self.active_charge_type & 0xF, 4)

        if self.name in ('SpawnerDudeTurret', 'SpawnerDudeTurret002', 'SpawnerDudeTurret003'):
            for _ in range(10):
                bs.write_boolean(False)

        if v5:
            bs.write_boolean(False)

        bs.write_boolean(self.shield_ticks > 0)
        bs.wpi2(self.visibility_state & 0x3)
        bs.write_boolean(self.is_invisible)
        bs.write_positive_int(0, 9)

        if is_own_hero:
            if self.ultimate_seems_active():
                bs.write_boolean(True)
                bs.write_int(1 - self.speed, 10)
            elif bs.write_boolean(self.buffed_speed != 0):
                bs.write_int(self.buffed_speed, 10)
            bs.write_boolean(self.yellow_eye)

        viewer = self.get_viewer_player()
        displayed = []
        if self.damage_numbers and viewer is not None:
            for damage in self.damage_numbers:
                if damage.get('delay', 0) != 0:
                    continue
                if damage.get('dealer', -1) == viewer.player_index or self._index == viewer.player_index:
                    displayed.append(damage)

        bs.wpi5(len(displayed))
        for damage in displayed:
            bs.write_int(clamp(damage.get('value', 0), -DAMAGE_NUMBER_LIMIT, DAMAGE_NUMBER_LIMIT), 15)

        for skill in self.skills:
            skill.encode(bs, is_own, self)
