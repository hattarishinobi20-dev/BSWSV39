import random

from G.GameObject import GameObject, OBJECT_TYPE_ITEM
from G.Assets import item_data
from G.LogicMath import get_rotated_x, get_rotated_y, path_length
from L.BitStream import BitStream

ORB_SPAWNER_NAME  = 'OrbSpawner'
GEM_NAME          = 'Point'
STAR_NAME         = 'Money'
ORB_SPAWN_TICKS   = 140
ORB_FIRST_SPAWN   = 40
ORB_SPREAD        = 600
PICKUP_RADIUS     = 300

MASK_TIMED_ITEMS = 0x2980
MASK_POSITION_ITEMS = 0x202005040
SPAWNED_ITEM_INSTANCE = 24
TELEPORT_ITEM_INSTANCE = 29
MINE_ITEM_INSTANCE = 27
MINE_TRIGGER_ITEM_INSTANCE = 34
HEALING_ITEM_INSTANCE = 32
TRAMPOLINE_STATE_ITEM_INSTANCE = 35


class Item(GameObject):
    __slots__ = (
        'data', 'name', 'instance_id', 'align_to_tiles',
        'spawning_tick', 'spawned_tick',
        'pick_up_start_x', 'pick_up_start_y',
        'trampoline_state', 'trampoline_state_tick',
        'is_triggered_mine', 'teleport_type', 'state_tick',
        'is_healing', 'is_triggered', 'value',
        'is_destroyed',
    )

    def __init__(self, instance_id: int = 0, name: str = ''):
        data = item_data(name) if name else {}
        super().__init__(18, instance_id)

        self.data        = data
        self.name        = name or data.get('Name', '')
        self.instance_id = instance_id
        self.align_to_tiles = data.get('AlignToTiles', '').lower() == 'true' if data else False

        self.spawning_tick         = 1
        self.spawned_tick          = 0
        self.pick_up_start_x       = 0
        self.pick_up_start_y       = 0
        self.trampoline_state      = 0
        self.trampoline_state_tick = 0
        self.is_triggered_mine     = 0
        self.teleport_type         = 0
        self.state_tick            = 0
        self.is_healing            = False
        self.is_triggered          = 0
        self.value                 = int(data.get('Value') or 0)
        self.is_destroyed          = False

    def get_object_type(self) -> int:
        return OBJECT_TYPE_ITEM

    def aligns_to_tiles(self) -> bool:
        return self.align_to_tiles

    def should_destruct(self) -> bool:
        return self.is_destroyed

    def on_destruct(self):
        self.is_destroyed = True

    def tick(self):
        if self.name == ORB_SPAWNER_NAME:
            self.tick_orb_spawner()
        elif self.name in (GEM_NAME, STAR_NAME):
            self.tick_pickup()

    def tick_orb_spawner(self):
        if self.spawning_tick == 1:
            self.spawning_tick = ORB_FIRST_SPAWN
        if self.get_ticks_gone() < self.spawning_tick:
            return

        battle = self.get_battle()
        if battle is None:
            return

        angle = random.randint(0, 359)
        spawn = Item(item_data(GEM_NAME).get('_instance', 0), GEM_NAME)
        spawn.set_position(self.x + get_rotated_x(ORB_SPREAD, 0, angle),
                           self.y + get_rotated_y(0, ORB_SPREAD, angle), self.z)
        spawn.set_index(self.get_index())
        spawn.spawning_tick = self.get_ticks_gone()
        battle.manager.add(spawn)

        self.spawning_tick = self.get_ticks_gone() + ORB_SPAWN_TICKS
        self.spawned_tick  = self.get_ticks_gone()

    def tick_pickup(self):
        battle = self.get_battle()
        if battle is None:
            return
        for character in battle.manager.get_characters():
            if not character.is_alive_state or not character.is_hero:
                continue
            if path_length(self.x, self.y, character.x, character.y) > PICKUP_RADIUS:
                continue
            player = character.get_player()
            if player is None:
                continue
            player.score += self.value or 1
            character.item_count += 1
            battle.on_item_picked_up(self, character)
            self.is_destroyed = True
            return

    def encode(self, bs: BitStream, is_own: bool, vision_team: int = 0):
        super().encode(bs, is_own, vision_team)

        instance_id = self.instance_id
        masked = instance_id <= 13 and ((1 << instance_id) & MASK_TIMED_ITEMS) != 0

        if instance_id == 5 or masked or instance_id == SPAWNED_ITEM_INSTANCE:
            bs.wpi14(self.spawning_tick)
            bs.wpi14(self.spawned_tick)
            if instance_id == SPAWNED_ITEM_INSTANCE:
                bs.wpi14(0)
            return

        if instance_id <= 0x21 and ((1 << instance_id) & MASK_POSITION_ITEMS) != 0:
            bs.wpi6(self.pick_up_start_x // 50)
            bs.wpi6(self.pick_up_start_y // 50)
            return

        if (instance_id & 0xFFFFFFF8) == 0x10 or instance_id == 30:
            if bs.write_boolean(self.trampoline_state > 0):
                bs.wpi2(self.trampoline_state)
                bs.wpi6(self.trampoline_state_tick)
            return

        if instance_id == TRAMPOLINE_STATE_ITEM_INSTANCE:
            bs.write_boolean(self.trampoline_state == 3)
            return

        if instance_id == MINE_ITEM_INSTANCE:
            bs.wpi3(self.is_triggered_mine)
            return

        if instance_id == TELEPORT_ITEM_INSTANCE:
            bs.wpi2(self.teleport_type)
            bs.write_boolean(self.state_tick > 0)
            return

        if instance_id == HEALING_ITEM_INSTANCE:
            bs.write_boolean(self.is_healing)
            bs.wpi6(self.pick_up_start_y // 50)
            return

        if instance_id == MINE_TRIGGER_ITEM_INSTANCE:
            bs.wi7(self.is_triggered_mine)
            return
