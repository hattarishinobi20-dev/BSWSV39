import threading
import time
import random

from G.BattlePlayer import BattlePlayer, BOT_BRAWLERS
from G.BattleMode import BattleMode
from M.Battle.StartLoadingMessage import StartLoadingMessage
from M.Battle.MatchMakingStatusMessage import MatchMakingStatusMessage
from M.Battle.MatchMakingCancelledMessage import MatchMakingCancelledMessage

SEARCH_TIMEOUT   = 7
UPDATE_INTERVAL  = 0.25
TURNS_PER_SECOND = 4

SLOTS: dict[int, tuple] = {
    1:  (15000007,  0,  6,  True),   # Gem Grab
    2:  (15000013,  6, 10,  False),  # Showdown
    3:  (15000018,  2,  6,  True),   # Heist
    4:  (15000005,  3,  6,  True),   # Bounty
    5:  (15000028,  9, 10,  False),  # Duo Showdown
    6:  (15000361, 20,  6,  True),   # Knockout
    7:  (15000024,  5,  6,  True),   # Brawl Ball
    8:  (15000097, 11,  6,  True),   # Siege
    10: (15000245, 17,  6,  True),   # Hot Zone
    11: (15000202, 16,  6,  True),   # Capture The Flag
    12: (15000370, 21,  6,  True),   # Hold The Ball
    13: (15000377, 23,  6,  True),   # Volley Brawl
    17: (15000384, 22,  6,  True),   # Basket Brawl
    20: (15000174, 15, 10,  False),  # Lone Star
    21: (15000167, 14, 10,  False),  # Takedown
    22: (15000027,  8,  6,  True),   # Robo Rumble
    23: (15000057, 10,  6,  True),   # Boss Fight
    24: (15000354, 19,  6,  True),   # Protect The King
}

_slots: dict[int, 'MatchmakingSlot'] = {}
_lock  = threading.Lock()


def init():
    for slot_id, cfg in SLOTS.items():
        _slots[slot_id] = MatchmakingSlot(slot_id, cfg)
    t = threading.Thread(target=_update_loop, daemon=True)
    t.start()
    print("+ matchmaking")


def request(connection, slot: int):
    with _lock:
        if slot not in _slots:
            slot = 1
        connection.matchmake_slot = slot
        entry = MatchmakingEntry(connection)
        connection.matchmaking_entry = entry
        _slots[slot].add(entry)


def cancel(connection):
    with _lock:
        slot = getattr(connection, 'matchmake_slot', -1)
        if slot in _slots:
            connection.matchmake_slot = -1
            entry = getattr(connection, 'matchmaking_entry', None)
            if entry:
                _slots[slot].remove(entry)
    try:
        MatchMakingCancelledMessage(connection.client).send(0)
    except Exception:
        pass


def _update_loop():
    while True:
        with _lock:
            for slot in _slots.values():
                slot.update()
        time.sleep(UPDATE_INTERVAL)


class MatchmakingSlot:
    def __init__(self, slot_id: int, cfg: tuple):
        self.slot_id        = slot_id
        self.location_gid   = cfg[0]
        self.gmv            = cfg[1]
        self.players_needed = cfg[2]
        self.has_two_teams  = cfg[3]

        self._queue: list[MatchmakingEntry] = []
        self._add_q: list[MatchmakingEntry] = []
        self._rem_q: list[MatchmakingEntry] = []
        self._seconds_left  = SEARCH_TIMEOUT
        self._turns         = 0

    def add(self, entry: 'MatchmakingEntry'):
        self._add_q.append(entry)

    def remove(self, entry: 'MatchmakingEntry'):
        self._rem_q.append(entry)

    def update(self):
        try:
            for e in self._rem_q:
                if e in self._queue:
                    self._queue.remove(e)
            self._rem_q.clear()

            for e in self._add_q:
                if e not in self._queue:
                    self._queue.append(e)
            self._add_q.clear()

            self._queue = [e for e in self._queue if getattr(e.connection, 'is_open', True)]

            while len(self._queue) >= self.players_needed:
                batch = self._queue[:self.players_needed]
                self._queue = self._queue[self.players_needed:]
                self._launch(batch)

            if self._queue and self._seconds_left <= 0:
                batch = self._queue[:]
                self._queue.clear()
                self._seconds_left = SEARCH_TIMEOUT
                self._launch(batch)
                return

            if self._queue:
                self._turns += 1
                if self._turns >= TURNS_PER_SECOND:
                    self._turns = 0
                    self._seconds_left -= 1
                self._broadcast_status()
            else:
                self._turns = 0
                self._seconds_left = SEARCH_TIMEOUT

        except Exception as exc:
            print(f"[Matchmaking] slot={self.slot_id}: {exc}")

    def _broadcast_status(self):
        sec = max(0, self._seconds_left)
        for e in self._queue:
            try:
                MatchMakingStatusMessage(
                    e.connection.client,
                    seconds     = sec,
                    found       = len(self._queue),
                    max_players = self.players_needed,
                ).send(0)
            except Exception:
                pass

    def _launch(self, entries: list):
        used_chars: list[int]       = []
        battle_players: list[BattlePlayer] = []

        for i, entry in enumerate(entries):
            team_index = (i % 2) if self.has_two_teams else i
            char_gid   = getattr(entry.connection, 'character_global_id', 16000000)
            p = BattlePlayer.create(
                client_socket       = entry.connection.client,
                player_index        = i,
                team_index          = team_index,
                name                = getattr(entry.connection, 'player_name', 'BSWS'),
                character_global_id = char_gid,
                account_id          = getattr(entry.connection, 'account_id', 1),
                skin_global_id      = getattr(entry.connection, 'skin_global_id', 0),
                hero_power_level    = getattr(entry.connection, 'hero_power_level', 9),
            )
            entry.player = p
            battle_players.append(p)
            used_chars.append(char_gid)

        real_count = len(battle_players)

        for i in range(real_count, self.players_needed):
            team_index = (i % 2) if self.has_two_teams else i
            bot_gid    = None
            for _ in range(30):
                candidate = 16000000 + random.choice(BOT_BRAWLERS)
                if candidate not in used_chars or not self.has_two_teams:
                    bot_gid = candidate
                    break
            bot_gid = bot_gid or (16000000 + random.choice(BOT_BRAWLERS))
            used_chars.append(bot_gid)
            bot = BattlePlayer.create_bot(i, team_index, bot_gid)
            battle_players.append(bot)

        battle = BattleMode(self.location_gid, self.gmv, battle_players)
        battle.start()

        for i, entry in enumerate(entries):
            own_player = entry.player
            try:
                StartLoadingMessage(
                    client             = entry.connection.client,
                    players            = battle_players,
                    own_index          = own_player.player_index,
                    team_index         = own_player.team_index,
                    location_global_id = self.location_gid,
                    gmv                = self.gmv,
                ).send(0)
                battle.register_connection(entry.connection, own_player.player_index)
            except Exception as exc:
                print(f"[Matchmaking] StartLoading: {exc}")


class MatchmakingEntry:
    __slots__ = ('connection', 'player')

    def __init__(self, connection):
        self.connection = connection
        self.player: BattlePlayer | None = None
