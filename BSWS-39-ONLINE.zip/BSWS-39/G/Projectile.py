import math

from G.GameObject import GameObject, OBJECT_TYPE_PROJECTILE
from G.Assets import projectile_data, area_effect_data
from G.LogicMath import clamp, path_length, get_angle, get_angle_to, get_rotated_x, get_rotated_y
from L.BitStream import BitStream

STATE_FLYING     = 0
STATE_DEPLOYED   = 4
RAW_TRAVEL_TYPES = (8, 11)
BIG_MAP_WIDTH    = 22
PROJECTILE_CLASS = 6
TICKS_PER_SECOND = 20
DESTROY_TICKS    = 6
SUB_STEPS        = 3
DEFAULT_Z        = 300
SPEED_FIX        = 14


class Projectile(GameObject):
    __slots__ = (
        'data', 'name', 'skin_data',
        'travel_type', 'radius', 'indirect', 'is_bouncing',
        'trigger_with_delay_ms', 'pre_explosion_time_ms',
        'state', 'bounce_tile_index', 'on_deploy', 'trigger_delay',
        'ending_tick', 'target_x', 'target_y', 'display_scale',
        'total_delta', 'angle', 'special_effect', 'now_x', 'now_y',
        'owner_index',
        'owner', 'target', 'start_x', 'start_y', 'prev_x', 'prev_y',
        'original_end_x', 'original_end_y', 'deployed_tick', 'destroyed_ticks', 'early_ticks',
        'total_delta', 'length_delta', 'damage', 'normal_dmg', 'speed',
        'skill_type', 'hit_radius', 'is_destroyed', 'area_effect_name',
        'pierces_characters', 'pierces_environment', 'pushback_strength',
        'hit_objects', 'homing_target', 'belle_weapon_bounces',
    )

    def __init__(self, data_class: int = 6, data_instance: int = 0, name: str = ''):
        super().__init__(data_class, data_instance)
        self.area_effect_name = ''

        self.data   = projectile_data(name) if name else {}
        self.name   = name
        self.skin_data = self.data

        self.travel_type            = int(self.data.get('TravelType') or 0)
        self.radius                 = int(self.data.get('Radius') or 0)
        self.indirect               = self.data.get('Indirect', '').lower() == 'true'
        self.is_bouncing            = self.data.get('IsBouncing', '').lower() == 'true'
        self.trigger_with_delay_ms  = int(self.data.get('TriggerWithDelayMs') or 0)
        self.pre_explosion_time_ms  = int(self.data.get('PreExplosionTimeMs') or 0)
        self.pierces_characters     = self.data.get('PiercesCharacters', '').lower() == 'true'
        self.pierces_environment    = self.data.get('PiercesEnvironment', '').lower() == 'true'
        self.pushback_strength      = int(self.data.get('PushbackStrength') or 0)
        self.hit_objects            = set()
        self.homing_target          = None
        self.belle_weapon_bounces   = 0

        self.state             = 0
        self.bounce_tile_index = -1
        self.on_deploy         = False
        self.trigger_delay     = 0
        self.ending_tick       = 0
        self.target_x          = 0
        self.target_y          = 0
        self.display_scale     = 0
        self.total_delta       = 0
        self.angle             = 0
        self.special_effect    = False
        self.now_x             = 0
        self.now_y             = 0
        self.owner_index       = 0
        self.owner             = None
        self.target            = None
        self.start_x           = 0
        self.start_y           = 0
        self.prev_x            = 0
        self.prev_y            = 0
        self.original_end_x    = 0
        self.original_end_y    = 0
        self.deployed_tick     = 0
        self.early_ticks       = 0
        self.destroyed_ticks   = 0
        self.total_delta       = 0
        self.length_delta      = 0
        self.damage            = 0
        self.normal_dmg        = 0
        self.speed             = 0
        self.skill_type        = 0
        self.hit_radius        = 0
        self.is_destroyed      = False

    def get_object_type(self) -> int:
        return OBJECT_TYPE_PROJECTILE

    def should_destruct(self) -> bool:
        return self.is_destroyed

    def on_destruct(self):
        self.is_destroyed = True

    def travel_ticks(self, distance: int, speed: int) -> int:
        speed = max(1, speed)
        return max(1, int(20 * distance / speed + 0.5))

    @staticmethod
    def get_projectile_speed(owner, data, is_ultimate: bool) -> int:
        speed = int(data.get('Speed') or 0)
        if owner is None:
            return speed
        bonus = owner.get_card_value_for_passive('projectile_speed', 1)
        if bonus > 0:
            speed += bonus
        value = owner.get_card_value_for_passive('super_range' if is_ultimate else 'attack_range', 1)
        if value >= 0:
            rapid_range = owner.rapid_fire_range
            if rapid_range != value:
                return speed * rapid_range // (rapid_range - value)
            return speed
        if owner.attack_accelerating_factor > 0:
            speed += owner.attack_accelerating_factor
        return speed

    def shot_speed(self) -> int:
        speed = int(self.data.get('Speed') or 0)
        if speed <= 0:
            speed = 3000
        return speed

    def get_spread_max(self, spread: int, distance: int) -> int:
        return Projectile.spread_max(self.data, spread, distance)

    def shoot(self, offset_x, offset_y, owner, target, x: int, y: int,
              damage: int, normal_dmg: int, spread: int, bullet_index: int, skill_type: int,
              start_offset_x=None, start_offset_y=None, speed_adjustment: int = 0):
        battle = self.get_battle() or owner.get_battle()
        if battle is None:
            return None

        self.set_index(owner.get_index())
        self.owner       = owner
        self.target      = target
        self.skill_type  = skill_type

        dx = x - owner.x
        dy = y - owner.y
        distance = path_length(owner.x, owner.y, x, y)

        target_x = x
        target_y = y

        spread_max = self.get_spread_max(spread, distance)
        if spread_max >= 3:
            perpendicular_x = get_rotated_x(dx, dy, 90)
            perpendicular_y = get_rotated_y(dx, dy, 90)
            length = path_length(0, 0, perpendicular_x, perpendicular_y)
            if length > 0:
                perpendicular_x = perpendicular_x * spread_max // length
                perpendicular_y = perpendicular_y * spread_max // length
            if spread < 0:
                perpendicular_x = -perpendicular_x
                perpendicular_y = -perpendicular_y

            target_x = x + perpendicular_x
            target_y = y + perpendicular_y

            new_distance = path_length(owner.x, owner.y, target_x, target_y)
            if new_distance > 0 and distance > 0:
                target_x = (target_x - owner.x) * distance // new_distance + owner.x
                target_y = (target_y - owner.y) * distance // new_distance + owner.y

        self.init(offset_x, offset_y, owner, target, target_x, target_y,
                  damage, normal_dmg, bullet_index, battle, start_offset_x, start_offset_y,
                  speed_adjustment)
        return self

    def init(self, offset_x: int, offset_y: int, owner, target, target_x: int, target_y: int,
             damage: int, normal_dmg: int, bullet_index: int, battle,
             start_offset_x=None, start_offset_y=None, speed_adjustment: int = 0):
        width  = battle.tilemap.logic_width
        height = battle.tilemap.logic_height

        start_x = owner.x
        start_y = owner.y
        if offset_x == -1:
            dx = target_x - start_x
            dy = target_y - start_y
            length = path_length(0, 0, dx, dy)
            if length > 0:
                dx = dx * 200 // length
                dy = dy * 200 // length
            start_x += dx
            start_y += dy
        elif offset_x is not None:
            start_x = offset_x
            start_y = offset_y
        elif start_offset_x is not None:
            start_x += start_offset_x
            start_y += start_offset_y

        self.damage      = damage
        self.normal_dmg  = normal_dmg
        self.deployed_tick = battle.ticks
        self.speed       = Projectile.get_projectile_speed(owner, self.data, self.skill_type == 2)

        travel = self.travel_ticks(
            path_length(start_x, start_y, target_x, target_y), self.speed - speed_adjustment)
        self.ending_tick  = travel + battle.ticks
        self.length_delta = 1000 // max(1, self.ending_tick - self.deployed_tick)
        self.total_delta  = 0

        self.target_x          = target_x
        self.target_y          = target_y
        self.original_end_x    = target_x
        self.original_end_y    = target_y
        self.start_x           = clamp(start_x, 1, width - 2)
        self.start_y           = clamp(start_y, 1, height - 2)
        self.now_x             = self.start_x
        self.now_y             = self.start_y
        self.prev_x            = self.now_x
        self.prev_y            = self.now_y
        self.x                 = self.start_x
        self.y                 = self.start_y
        if owner is target and owner is not None:
            self.z = owner.z + int(owner.data.get('ProjectileStartZ') or 0)
        else:
            self.z = (target.z if target is not None else 0) + DEFAULT_Z
        self.display_scale     = 0
        self.angle             = get_angle(self.target_x - self.start_x, self.target_y - self.start_y)

        if self.trigger_with_delay_ms > 0:
            self.trigger_delay = self.trigger_with_delay_ms // 50 + battle.ticks

    def is_wall_between(self, x: int, y: int) -> bool:
        battle = self.get_battle()
        if battle is None:
            return False
        return not battle.tilemap.is_passable(x // 300, y // 300, True)

    def break_wall(self) -> bool:
        battle = self.get_battle()
        if battle is None:
            return False
        tile = battle.tilemap.get_tile(self.x // 300, self.y // 300, True)
        if tile is None:
            return False
        tile.destruct(self.pierces_environment)
        if tile.is_destructed():
            return True
        return False

    def update_position(self):
        if self.length_delta <= 0:
            return
        travel = self.ending_tick - self.deployed_tick
        if travel < 1:
            travel = 1
        elapsed = self.early_ticks + self.get_ticks_gone() - self.deployed_tick
        self.total_delta = min(1000, 1000 * elapsed // travel)
        percent = self.total_delta
        self.x = self.start_x + (self.target_x - self.start_x) * percent // 1000
        self.y = self.start_y + (self.target_y - self.start_y) * percent // 1000

    def collision_radius(self) -> int:
        radius = int(self.data.get('Radius') or 0)
        return radius * self.total_delta // 100

    def check_collisions(self):
        battle = self.get_battle()
        if battle is None:
            return False
        if self.data.get('Indirect', '').lower() == 'true':
            return False
        radius = self.collision_radius()
        for other in battle.manager.get_characters():
            if other is self.owner or not other.is_alive_state:
                continue
            if other.get_index() // 16 == self.owner_index // 16:
                continue
            if other.get_global_id() in self.hit_objects:
                continue
            hit_radius = radius + int(other.data.get('CollisionRadius') or 120)
            distance = path_length(self.x, self.y, other.x, other.y)
            if distance <= hit_radius:
                self.hit(other)
                if not self.pierces_characters:
                    return True
                self.hit_objects.add(other.get_global_id())
        return False

    def hit(self, character):
        character.cause_damage(self.damage, self.owner)
        if self.owner is not None:
            self.owner.gain_ulti_charge(self.damage)
        if self.pushback_strength > 0:
            character.trigger_pushback(self.x, self.y, self.pushback_strength)
        if not self.pierces_characters:
            self.deploy()
        return True

    def area_damage(self):
        battle = self.get_battle()
        if battle is None or self.owner is None:
            return
        radius = int(self.data.get('Radius') or 0)
        if radius < 1:
            return
        for other in battle.manager.get_characters():
            if other is self.owner or not other.is_alive_state:
                continue
            if other.get_index() // 16 == self.owner_index // 16:
                continue
            if path_length(self.x, self.y, other.x, other.y) <= radius:
                other.cause_damage(self.damage, self.owner)
                self.owner.gain_ulti_charge(self.damage)

    def deploy(self):
        if self.state >= STATE_DEPLOYED:
            return
        self.area_damage()
        self.area_effect_name = self.data.get('AreaEffect') or ''
        if self.area_effect_name:
            self.spawn_area_effect()
        self.state           = STATE_DEPLOYED
        self.on_deploy       = True
        self.display_scale   = 1000
        self.target_x        = self.x
        self.target_y        = self.y

    def spawn_area_effect(self):
        battle = self.get_battle()
        if battle is None:
            return
        from G.GameObjectFactory import create_area_effect
        effect = create_area_effect(self.area_effect_name)
        if effect is None:
            return
        effect.set_position(self.x, self.y, 0)
        effect.set_index(self.owner_index)
        effect.set_source(self.owner)
        battle.manager.add(effect)
        effect.trigger()

    def tick(self):
        if self.is_destroyed:
            return
        if self.state >= STATE_DEPLOYED:
            self.destroyed_ticks += 1
            if self.destroyed_ticks >= DESTROY_TICKS:
                self.is_destroyed = True
            return

        self.prev_x = self.now_x
        self.prev_y = self.now_y

        if self.homing_target is not None and self.homing_target.is_alive_state:
            self.target_x = self.homing_target.x
            self.target_y = self.homing_target.y

        self.update_position()
        self.angle = get_angle(self.target_x - self.start_x, self.target_y - self.start_y)

        if self.is_wall_between(self.x, self.y):
            if not self.break_wall():
                self.deploy()
                return
        if self.check_collisions():
            return

        self.now_x = self.x
        self.now_y = self.y

        if self.total_delta >= 1000 or self.early_ticks + self.get_ticks_gone() >= self.ending_tick:
            self.deploy()

    def run_early_ticks(self):
        data_early_ticks = int(self.data.get('EarlyTicks') or 0)
        if data_early_ticks >= 1:
            for _ in range(data_early_ticks):
                self.early_ticks += 1
                self.tick()
                self.on_deploy = True

    @staticmethod
    def spread_max(data, spread: int, distance: int) -> int:
        value = abs(spread)
        if data.get('ConstantFlyTime', '').lower() == 'true':
            return 3 * value
        if data.get('Indirect', '').lower() == 'true':
            min_distance = int(data.get('MinDistanceForSpread') or 0)
            if min_distance > distance:
                distance = min_distance
        return distance * value // 300

    @staticmethod
    def shoot_projectile(owner, target, data, x: int, y: int,
                         damage: int, spread: int, battle,
                         bullet_index: int = 0, skill_type: int = 1,
                         offset_x=None, offset_y=None,
                         start_offset_x=None, start_offset_y=None,
                         speed_adjustment: int = 0, normal_dmg=None):
        if not data:
            return None
        projectile = Projectile(PROJECTILE_CLASS, data.get('_instance', 0), data.get('Name', ''))
        projectile.data = data
        projectile.pierces_characters  = data.get('PiercesCharacters', '').lower() == 'true'
        projectile.pierces_environment = data.get('PiercesEnvironment', '').lower() == 'true'
        projectile.pushback_strength   = int(data.get('PushbackStrength') or 0)
        projectile.attach(battle.manager, 0)
        battle.manager.add(projectile)
        return projectile.shoot(offset_x, offset_y, owner, target, x, y, damage,
                                damage if normal_dmg is None else normal_dmg,
                                spread, bullet_index, skill_type, start_offset_x, start_offset_y,
                                speed_adjustment)

    def uses_raw_position(self) -> bool:
        if self.travel_type in RAW_TRAVEL_TYPES:
            return True
        return self.data.get('IgnoreLevelBoarder', '').lower() == 'true'

    def rendering(self) -> str:
        return self.skin_data.get('Rendering', '')

    def encode(self, bs: BitStream, is_own: bool, vision_team: int = 0):
        super().encode(bs, is_own, vision_team)

        battle = self.get_battle()
        tilemap = getattr(battle, 'tilemap', None) if battle else None
        big_map = tilemap is not None and tilemap.width >= BIG_MAP_WIDTH

        bs.wpi3(self.state)

        if self.state != STATE_DEPLOYED:
            if self.is_bouncing:
                if self.bounce_tile_index < 0:
                    bs.write_boolean(False)
                    self._encode_tail(bs, big_map)
                    return
                bs.write_boolean(True)
            else:
                self._encode_tail(bs, big_map)
                return

        if big_map:
            bs.wpi12(self.bounce_tile_index)
        else:
            bs.wpi10(clamp(self.bounce_tile_index, 0, 1023))

        self._encode_tail(bs, big_map)

    def _encode_tail(self, bs: BitStream, big_map: bool):
        bs.write_boolean(self.on_deploy)

        if self.trigger_with_delay_ms > 0:
            bs.wpvint65535(self.trigger_delay)
        elif self.pre_explosion_time_ms > 0:
            bs.wpvint65535(self.ending_tick)

        if self.pre_explosion_time_ms > 0:
            bs.wpvint65535(self.target_x)
            bs.wpvint65535(self.target_y)

        bs.wpi10(clamp(self.display_scale if self.display_scale != 0 else self.total_delta, 0, 1023))

        if self.rendering() != 'DoNotRotateClip':
            bs.wpi9(self.angle & 0x1FF)

        bs.write_boolean(self.special_effect)
        if self.special_effect:
            if self.travel_type in RAW_TRAVEL_TYPES:
                bs.wi16(self.now_x)
                bs.wi16(self.now_y)
            else:
                bs.wpvint65535(clamp(self.now_x, 0, 65535))
                bs.wpvint65535(clamp(self.now_y, 0, 65535))
