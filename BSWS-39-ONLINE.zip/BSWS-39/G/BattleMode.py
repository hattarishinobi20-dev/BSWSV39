import random
import threading
import time
from collections import deque

import L.Udp as Udp

from G.TileMapFactory import create as create_tilemap
from G.TileMap import TileMap
from G.GameObjectManager import GameObjectManager
from G.GameObjectFactory import create_character, create_character_by_name, create_item, create_area_effect
from G.ClientInput import (ClientInput, INPUT_ATTACK, INPUT_ULTI, INPUT_MOVE,
                           INPUT_RESPAWN, INPUT_CHARGE, INPUT_RELEASE, INPUT_GADGET,
                           INPUT_EMOTE, INPUT_STOPATK)
from G.GameModeUtil import (
    get_battle_ticks,
    get_respawn_seconds,
    has_two_teams,
    has_five_teams,
)
from G.LogicMath import get_angle, get_rotated_x, get_rotated_y
from L.BitStream import BitStream

TICKS_PER_SECOND  = 20
INTRO_TICKS       = 100
NO_TIME_TICKS     = 16000
NORMAL_TICKS      = 3180
GAME_OVER_TICKS   = 300
FIRST_SPAWN_TICK  = 1
SPAWN_EFFECT_DELAY = 40

GMV_GEM_GRAB     = 0
GMV_HEIST        = 2
GMV_BOUNTY       = 3
GMV_SHOWDOWN     = 6
GMV_BIG_GAME     = 7
GMV_DUO_SHOWDOWN = 9
GMV_LASER_BALL   = 5
GMV_VOLLEY_BRAWL = 23
GMV_KNOCKOUT     = 20

UDP_INFO_RESEND_TICKS = 100
GEM_GRAB_TARGET        = 10
GEM_GRAB_COUNTDOWN_TICKS = 20 * 17
PIN_TICKS     = 80
MAX_ATTACK_TICKS = 63


class BattleMode:
    def __init__(self, location_global_id: int, gmv: int, players: list):
        self.location_global_id = location_global_id
        self.gmv                = gmv
        self.players            = players
        self.ticks              = 0
        self.is_over            = False
        self.is_ending          = False
        self.end_tick           = -1
        self.winner_team        = -1
        self.players_alive      = len(players)
        self.max_ticks          = get_battle_ticks(gmv)

        self.tilemap: TileMap   = create_tilemap(location_global_id)
        self.manager            = GameObjectManager(self)

        self.gem_grab_countdown = 0
        self.zone1_score        = 0
        self.zone2_score        = 0
        self.is_round_ending    = False
        self.current_round      = 0
        self.round_winners      = [-1, -1, -1]
        self.goal_team          = -1
        self.goal_ticks         = 0
        self.set_stop_ticks     = False
        self.carryable          = None
        self.carryable_team0    = None
        self.carryable_team1    = None

        self._sessions: dict[int, object] = {}
        self._logged_inputs: dict[int, int] = {}
        self._last_input: dict[int, int]  = {}
        self._input_q: deque[ClientInput] = deque()
        self._lock   = threading.Lock()
        self._thread: threading.Thread | None = None

    @property
    def map_width(self) -> int:
        return self.tilemap.width

    @property
    def map_height(self) -> int:
        return self.tilemap.height

    def get_players_count(self) -> int:
        return len(self.players)

    def get_tile(self, col: int, row: int):
        return self.tilemap.get_tile(col, row)

    def get_gem_grab_countdown(self) -> int:
        return self.gem_grab_countdown

    def get_team_score(self, team_index: int) -> int:
        score = 0
        for player in self.players:
            if player.team_index == team_index:
                score += player.score
        return score

    def on_item_picked_up(self, item, character):
        print(f"[BattleMode] picked {item.name} by {character.name} score={self.get_team_score(character.get_index() // 16)}")

    def get_alive_teams(self) -> int:
        return len(self.get_alive_teams_list())

    def get_alive_teams_list(self) -> list:
        teams = []
        for team in range(5 if has_two_teams(self.gmv) else len(self.players)):
            if self.is_team_alive_or_respawning(team):
                teams.append(team)
        return teams

    def is_team_alive_or_respawning(self, team_index: int) -> bool:
        for player in self.players:
            if player.team_index != team_index:
                continue
            if player.is_alive or player.respawn_started:
                return True
        return False

    def knockout_round_winners(self, team_index: int) -> list:
        return self.round_winners

    def register_connection(self, connection, player_index: int):
        sid = id(connection)
        self._sessions[sid]   = connection
        self._last_input[sid] = 0
        connection.battle     = self
        self.players[player_index].session_id = sid
        self._send_udp_info(connection)

    def _send_udp_info(self, connection):
        try:
            from M.Battle.VisionUpdateMessage import UdpConnectionInfoMessage
            UdpConnectionInfoMessage(
                client         = connection.client,
                server_port    = Udp.PORT,
                server_address = Udp.public_host(connection),
                session_id     = getattr(connection, 'udp_session_id', 0),
            ).send(0)
            print(f"+ udp info session={getattr(connection, 'udp_session_id', 0)} host={Udp.public_host(connection)} port={Udp.PORT}")
        except Exception as exc:
            print(f"[UdpConnectionInfo] {exc}")

    def resend_udp_info(self, connection):
        delay = getattr(connection, 'udp_info_resend_tick', 0)
        if self.ticks < delay:
            return
        connection.udp_info_resend_tick = self.ticks + UDP_INFO_RESEND_TICKS
        connection.udp_info_resends = getattr(connection, 'udp_info_resends', 0) + 1
        self._send_udp_info(connection)

    def add_input(self, inp: ClientInput, session_id: int):
        inp.owner_session_id = session_id
        with self._lock:
            self._input_q.append(inp)

    def _player_by_session(self, sid: int):
        for player in self.players:
            if player.session_id == sid:
                return player
        return None

    def _handle_inputs(self):
        with self._lock:
            queue, self._input_q = self._input_q, deque()

        for inp in queue:
            player = self._player_by_session(inp.owner_session_id)
            if player is None:
                continue
            if self._last_input.get(inp.owner_session_id, 0) >= inp.index:
                continue
            self._last_input[inp.owner_session_id] = inp.index
            player.last_handled_input = inp.index

            character = self.manager.get_by_id(player.own_object_id)
            if character is None or not character.is_alive_state:
                if inp.type not in (INPUT_RESPAWN, INPUT_EMOTE):
                    continue
            if character is not None and character.charge_up_type > 0 and 2 <= inp.type <= 8:
                continue

            logged = self._logged_inputs.get(player.player_index, 0)
            if logged < 5:
                self._logged_inputs[player.player_index] = logged + 1
                print(f"[Input] p={player.player_index} idx={inp.index} type={inp.type} x={inp.x} y={inp.y}")

            if inp.type == INPUT_ATTACK:
                skill = character.weapon_skill
                if skill is None:
                    continue
                character.ulti_disabled()
                if inp.auto_attack:
                    target = self._auto_attack_target(character, inp)
                    if target is not None:
                        inp.x, inp.y = target.x, target.y
                    character.activate_skill(0, inp.x, inp.y)
                elif skill.is_positional_targeted():
                    character.activate_skill(0, inp.x, inp.y)
                else:
                    character.activate_skill(0, inp.x + character.x, inp.y + character.y)
            elif inp.type == INPUT_ULTI:
                skill = character.ultimate_skill
                if skill is None:
                    continue
                character.ulti_disabled()
                if not player.has_ulti():
                    continue
                if inp.auto_attack:
                    target = self._auto_attack_target(character, inp)
                    if target is not None:
                        inp.x, inp.y = target.x, target.y
                    character.activate_skill(1, inp.x, inp.y)
                elif skill.is_positional_targeted():
                    character.activate_skill(1, inp.x, inp.y)
                else:
                    character.activate_skill(1, inp.x + character.x, inp.y + character.y)
            elif inp.type == INPUT_MOVE:
                character.move_to(inp.x, inp.y)
            elif inp.type == INPUT_CHARGE:
                character.ulti_enabled()
            elif inp.type == INPUT_RELEASE:
                character.ulti_disabled()
            elif inp.type == INPUT_STOPATK:
                character.stop_movement()
            elif inp.type == INPUT_EMOTE:
                player.start_using_pin(self.ticks, inp.emote_index)

    def _auto_attack_target(self, character, inp):
        target = self.manager.get_by_id(inp.auto_attack_target)
        if target is None or target.get_object_type() != 0:
            target = character.get_closest_visible_enemy()
        return target

    def _send_vision(self):
        from M.Battle.VisionUpdateMessage import VisionUpdateMessage

        for player in self.players:
            if player.is_bot or player.session_id <= 0:
                continue
            connection = self._sessions.get(player.session_id)
            if connection is None or not getattr(connection, 'is_open', True):
                continue

            try:
                bs = BitStream(8192)
                self.manager.encode(bs, player.own_object_id, player.player_index, player.team_index)
                message = VisionUpdateMessage(
                    client         = connection.client,
                    tick           = self.ticks,
                    handled_inputs = player.last_handled_input,
                    viewers        = 0,
                    vision_bs      = bs,
                )
                udp_session = getattr(connection, 'udp_session_id', 0)
                if not Udp.is_registered(udp_session):
                    self.resend_udp_info(connection)

                if Udp.send(message, udp_session):
                    if not getattr(connection, 'vision_udp', False):
                        connection.vision_udp = True
                        print(f"[BattleMode] vision udp session={udp_session}")
                else:
                    if not getattr(connection, 'vision_tcp', False):
                        connection.vision_tcp = True
                        print(f"[BattleMode] vision tcp session={udp_session} (udp not connected)")
                    if not getattr(connection, 'udp_warned', False) and self.ticks > 20 * 5:
                        connection.udp_warned = True
                        print(f"[BattleMode] no udp in 5s: client must reach {Udp.PUBLIC_HOST or Udp.public_host(connection)}:{Udp.PORT}/udp "
                              f"(adb reverse tunnels tcp only, use LAN ip or UDPSRV_HOST)")
                    message.send(0)
            except Exception as exc:
                print(f"[Vision] p={player.player_index}: {exc}")

    def add_game_objects(self):
        self.players_alive = len(self.players)
        team1_indexer = 0
        team2_indexer = 0
        team_spawn_counters = {team: 0 for team in range(5)}

        for player in self.players:
            character = create_character(player.character_global_id % 1000000)
            character.set_index(player.team_index * 16 + player.player_index)
            character.set_bot(player.is_bot)

            if has_two_teams(self.gmv):
                if player.team_index == 0:
                    tile = self.tilemap.spawn_points_team1[team1_indexer % len(self.tilemap.spawn_points_team1)]
                    team1_indexer += 1
                else:
                    tile = self.tilemap.spawn_points_team2[team2_indexer % len(self.tilemap.spawn_points_team2)]
                    team2_indexer += 1
                character.set_position(tile.x + 150, tile.y + 150, 0)
                player.set_spawn_point(tile.x + 150, tile.y + 150)

            elif self.gmv == GMV_DUO_SHOWDOWN:
                spawn_point_index = player.team_index % 5
                safe_index = spawn_point_index * 2
                if safe_index >= len(self.tilemap.spawn_points_team1):
                    safe_index = safe_index % len(self.tilemap.spawn_points_team1)
                base_tile = self.tilemap.spawn_points_team1[safe_index]
                position_in_team = player.player_index % 2
                offset_x = -300 if position_in_team == 0 else 300
                character.set_position(base_tile.x + 150 + offset_x, base_tile.y + 150, 0)
                player.set_spawn_point(base_tile.x + 150 + offset_x, base_tile.y + 150)

            elif has_five_teams(self.gmv):
                spawn_point_index = player.team_index % 5
                base_tile = self.tilemap.spawn_points_team1[spawn_point_index * 2]
                position_in_team = team_spawn_counters[player.team_index] % 2
                team_spawn_counters[player.team_index] += 1
                offset_x = position_in_team * 600 * 2
                character.set_position(base_tile.x + 150 + offset_x, base_tile.y + 150, 0)
                player.set_spawn_point(base_tile.x + 150 + offset_x, base_tile.y + 150)

            else:
                tile = self.tilemap.spawn_points_team1[team1_indexer % len(self.tilemap.spawn_points_team1)]
                team1_indexer += 1
                character.set_position(tile.x + 150, tile.y + 150, 0)
                player.set_spawn_point(tile.x + 150, tile.y + 150)

            character.set_hero_level(player.hero_power_level - 1)
            character.set_upgrades(player.hero_power_level)
            character.spawn_tick = self.ticks

            self.manager.add(character)
            player.own_object_id = character.object_global_id
            player.is_alive      = True

        if self.gmv == GMV_GEM_GRAB:
            item = create_item('OrbSpawner')
            item.set_position(3150, 4950, 0)
            item.set_index(16)
            self.manager.add(item)

        if self.gmv == GMV_BOUNTY:
            item = create_item('Money')
            item.set_position(3150, 4950, 0)
            self.manager.add(item)

        if self.gmv in (GMV_SHOWDOWN, GMV_DUO_SHOWDOWN):
            for tile in self.tilemap.loot_box_spawn:
                if random.randint(0, 120) < 80:
                    box = create_character_by_name('LootBox')
                    if box is None:
                        continue
                    box.set_position(tile.x + 150, tile.y + 150, 0)
                    box.set_index(170)
                    box.hp     = 4300
                    box.max_hp = 4300
                    self.manager.add(box)

    def start(self):
        self.add_game_objects()
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()
        print(f"[BattleMode] loc={self.location_global_id} gmv={self.gmv} n={len(self.players)}")

    def _run(self):
        interval = 1.0 / TICKS_PER_SECOND
        while not self.is_over:
            start = time.monotonic()
            try:
                self._tick()
            except Exception as exc:
                print(f"[BattleMode] tick {self.ticks}: {exc}")
            sleep = interval - (time.monotonic() - start)
            if sleep > 0:
                time.sleep(sleep)

    def _tick(self):
        self._handle_inputs()
        self._send_vision()

        if self.is_ending:
            if self.ticks >= self.end_tick + GAME_OVER_TICKS:
                self.is_over = True
                return
            self.manager.pre_tick()
            self._simulate()
            self.ticks += 1
            return

        for player in self.players:
            player.kill_list.clear()

        self.manager.pre_tick()
        self._simulate()
        self.ticks += 1

        if self.ticks >= INTRO_TICKS:
            if self.calculate_is_game_over():
                return
            if self.max_ticks > 0 and self.ticks >= self.max_ticks:
                self._end_by_timer()

    def _simulate(self):
        self.manager.tick()
        self.tilemap.tick(self.manager)
        self.tick_spawn_heroes()

    def tick_spawn_heroes(self):
        if self.gmv == GMV_KNOCKOUT:
            return

        for player in self.players:
            if player.is_alive:
                continue
            if self.gmv == GMV_SHOWDOWN:
                continue

            respawn_seconds = get_respawn_seconds(self.gmv)
            base_tick = player.death_tick + TICKS_PER_SECOND * respawn_seconds

            if self.ticks == base_tick and player.death_tick != 1:
                effect = create_area_effect('HeroSpawn')
                effect.set_position(player.spawn_x, player.spawn_y, 0)
                effect.set_index(player.team_index * 16 + player.player_index)
                self.manager.add(effect)
                effect.trigger()

            if self.ticks == base_tick + SPAWN_EFFECT_DELAY:
                character = create_character(player.character_global_id % 1000000)
                character.set_index(player.team_index * 16 + player.player_index)
                character.set_position(player.spawn_x, player.spawn_y, 0)
                character.set_bot(player.is_bot)
                character.spawn_tick = self.ticks
                character.set_hero_level(player.hero_power_level - 1)
                character.set_upgrades(player.hero_power_level)
                self.manager.add(character)
                player.own_object_id = character.object_global_id
                player.is_alive      = True


    def on_player_died(self, player):
        self.drop_items_on_death(player)
        player.is_alive      = False
        player.respawn_started = False
        player.death_tick    = self.ticks

        if self.gmv in (GMV_SHOWDOWN, GMV_DUO_SHOWDOWN):
            if player.is_bot == 2:
                return
            self.players_alive = max(0, self.players_alive - 1)
            player.battle_royale_rank = self.players_alive + 1
            return

        if self.gmv == GMV_KNOCKOUT:
            return

    def drop_items_on_death(self, player):
        if self.gmv != GMV_GEM_GRAB or player.score <= 0:
            return

        amount = player.score
        player.score = 0
        character = self.manager.get_by_id(player.own_object_id)
        drop_x = character.x if character is not None else player.spawn_x
        drop_y = character.y if character is not None else player.spawn_y
        if character is not None:
            character.item_count = 0

        for index in range(amount):
            angle = random.randint(0, 359)
            distance = random.randint(150, 500)
            item = create_item('Point')
            item.set_position(drop_x + get_rotated_x(distance, 0, angle),
                              drop_y + get_rotated_y(0, distance, angle), 0)
            self.manager.add(item)

    def get_alive_characters_by_team(self, team_index: int) -> list:
        characters = []
        for character in self.manager.get_characters():
            if character.team_index != team_index:
                continue
            if character.is_alive():
                characters.append(character)
        return characters

    def get_player_with_object(self, global_id: int):
        for player in self.players:
            if player.own_object_id == global_id:
                return player
        return None

    def alive_teams_count(self) -> int:
        teams = set()
        for player in self.players:
            if player.is_alive:
                teams.add(player.team_index)
        return len(teams)

    def calculate_is_game_over(self) -> bool:
        if self.gmv == GMV_GEM_GRAB:
            return self.calculate_gem_grab_over()
        if self.gmv in (GMV_SHOWDOWN, GMV_DUO_SHOWDOWN):
            return self.alive_teams_count() <= 1
        if self.gmv == GMV_KNOCKOUT:
            return False
        alive_team0 = 0
        alive_team1 = 0
        for player in self.players:
            if player.team_index == 0 and player.is_alive:
                alive_team0 += 1
            elif player.team_index == 1 and player.is_alive:
                alive_team1 += 1
        return alive_team0 == 0 or alive_team1 == 0

    def calculate_gem_grab_over(self) -> bool:
        score0 = self.get_team_score(0)
        score1 = self.get_team_score(1)

        if score0 > score1 and score0 >= GEM_GRAB_TARGET:
            team = 0
        elif score1 > score0 and score1 >= GEM_GRAB_TARGET:
            team = 1
        else:
            self.gem_grab_countdown = 0
            return False

        if self.gem_grab_countdown == 0:
            self.gem_grab_countdown = self.ticks + GEM_GRAB_COUNTDOWN_TICKS
            return False
        if self.ticks <= self.gem_grab_countdown:
            return False

        self.winner_team = team
        self._end_by_timer()
        return True

    def _end_by_timer(self):
        self.is_ending = True
        self.end_tick  = self.ticks
        for player in self.players:
            player.reset_using_pin()
        print(f"[BattleMode] timer end tick={self.ticks} gmv={self.gmv}")
