import random
from L.BStream import Pkt


BOT_NAMES = [
    "<cff00ff>Elox</c>",         "<c00bfff>VITAL_SHARK</c>",   "<cff8800>prostislavv</c>",
    "<c66ff66>alekzz03</c>",     "<cff4444>cu6ickk</c>",       "<cffff00>Igor10d</c>",
    "<c66ccff>neguesti</c>",     "<cff66cc>Dep100r</c>",       "<c99ff66>crysoul29</c>",
    "<cffaa00>ElNinoTV</c>",     "<c66ffff>tq_nob</c>",        "<cff9999>Mebius_mbb</c>",
    "<c99ccff>kiita21x</c>",     "<cff5555>clash__99</c>",     "<c55ff55>rouch888</c>",
    "<c55aaff>RealPlayTV</c>",   "<cffdd00>pr0100vlad</c>",    "<cbbbbbb>Morkovava</c>",
    "<cff4d4d>LINE</c>",         "<c66ccff>IceArrow</c>",      "<cffe066>AuRuM TV</c>",
    "<cff6699>MMA</c>",          "<c66ff99>DanKar</c>",        "<c9966ff>ZebrailTV</c>",
    "<cff9933>Nikitos Show</c>", "<c33ffcc>Holdik</c>",        "<cffcc33>Pozzi</c>",
]

BOT_BRAWLERS = list(range(0, 13))


class BattlePlayer:
    __slots__ = (
        'account_id', 'player_index', 'team_index', 'session_id',
        'character_global_id', 'skin_global_id', 'hero_power_level',
        'name', 'thumbnail_global_id', 'name_color_global_id', 'high_name_color_global_id',
        'trophies', 'highest_trophies',
        'emotes', 'is_bot',
        'kills', 'deaths', 'damage', 'heals', 'score',
        'is_alive', 'battle_end_sent', 'ulti_charge', 'has_star',
        'spawn_x', 'spawn_y', 'own_object_id',
        'kill_list', 'start_pin_ticks', 'pin_index',
        'spray_index', 'respawn_started',
        'respawn_x', 'respawn_y',
        'last_handled_input', 'control_ticks_left',
        'hero_index', 'death_tick',
        'event_collect_tokens', 'temporary_team_override',
        'over_charge', 'over_charging',
        'battle_royale_rank', 'accessory',
    )

    def __init__(self):
        self.account_id                 = 0
        self.player_index               = 0
        self.team_index                 = 0
        self.session_id                 = -1
        self.character_global_id        = 16000000
        self.skin_global_id             = 0
        self.hero_power_level           = 9
        self.name                       = "BSWS"
        self.thumbnail_global_id        = 28000000
        self.name_color_global_id       = 43000000
        self.high_name_color_global_id  = 0
        self.trophies                   = 0
        self.highest_trophies           = 0
        self.emotes                     = {1: 134, 2: 134, 3: 134, 4: 134, 5: 134}
        self.is_bot                     = False
        self.kills                      = 0
        self.deaths                     = 0
        self.damage                     = 0
        self.heals                      = 0
        self.score                      = 0
        self.is_alive                   = True
        self.battle_end_sent            = False
        self.ulti_charge                = 0
        self.has_star                   = False
        self.spawn_x                    = 0
        self.spawn_y                    = 0
        self.own_object_id              = 0
        self.kill_list: list            = []
        self.start_pin_ticks            = -9999
        self.pin_index                  = 0
        self.spray_index                = 0
        self.respawn_started            = False
        self.respawn_x                  = 0
        self.respawn_y                  = 0
        self.last_handled_input         = 0
        self.control_ticks_left         = 0
        self.hero_index                 = 0
        self.death_tick                 = 1
        self.event_collect_tokens       = 0
        self.temporary_team_override    = 0
        self.over_charge                = 0
        self.over_charging              = False
        self.battle_royale_rank         = -1
        self.accessory                  = None

    def has_ulti(self) -> bool:
        return self.ulti_charge >= 4000

    def get_ulti_charge(self) -> int:
        return self.ulti_charge

    def is_using_pin(self, ticks: int) -> bool:
        return ticks - self.start_pin_ticks < 80

    def start_using_pin(self, ticks: int, index: int):
        self.start_pin_ticks = ticks
        self.pin_index       = index

    def reset_using_pin(self):
        self.start_pin_ticks = -1

    def set_spawn_point(self, x: int, y: int):
        self.spawn_x = x
        self.spawn_y = y

    def get_spawn_point(self):
        return self.spawn_x, self.spawn_y

    def add_ulti_charge(self, amount: int):
        self.ulti_charge = max(0, min(self.ulti_charge + amount, 4000))

    def use_ulti(self):
        self.ulti_charge = 0

    def killed_player(self, index: int, bounty_stars: int = 0):
        self.kill_list.append({'player_index': index, 'stars': bounty_stars})
        self.kills += 1

    def encode(self, pkt: Pkt):
        pkt.wlong(0, self.account_id)
        pkt.wvint(self.player_index)
        pkt.wvint(self.team_index)
        pkt.wvint(0)
        pkt.wint(0)

        pkt.wvint(self.character_global_id // 1000000)
        pkt.wvint(self.character_global_id % 1000000)

        if self.skin_global_id:
            pkt.wvint(self.skin_global_id // 1000000)
            pkt.wvint(self.skin_global_id % 1000000)
        else:
            pkt.wvint(0)

        pkt.wbool(True)
        pkt.wvint(self.hero_power_level)

        pkt.wvint(0)
        pkt.wvint(0)
        pkt.wvint(0)
        pkt.wvint(0)
        pkt.wvint(0)
        pkt.wvint(0)

        pkt.wbool(True)
        pkt.wvint(5)
        for slot in range(1, 6):
            emote_val = self.emotes.get(slot, 134)
            pkt.wvint(52)
            pkt.wvint(emote_val)

        name_bytes = self.name.encode('utf-8')
        pkt.wint(len(name_bytes))
        pkt.buffer += name_bytes
        pkt.wvint(100)
        pkt.wvint(self.thumbnail_global_id)
        pkt.wvint(self.name_color_global_id)
        pkt.wvint(self.high_name_color_global_id)

        pkt.wbool(False)

    @staticmethod
    def create(client_socket, player_index: int, team_index: int,
               name: str = "BSWS",
               character_global_id: int = 16000000,
               account_id: int = 1,
               skin_global_id: int = 0,
               hero_power_level: int = 9) -> 'BattlePlayer':
        p = BattlePlayer()
        p.account_id            = account_id
        p.player_index          = player_index
        p.team_index            = team_index
        p.name                  = name
        p.character_global_id   = character_global_id
        p.skin_global_id        = skin_global_id
        p.hero_power_level      = hero_power_level
        p.session_id            = id(client_socket)
        return p

    @staticmethod
    def create_bot(player_index: int, team_index: int,
                   character_global_id: int = None) -> 'BattlePlayer':
        p = BattlePlayer()
        p.is_bot                        = True
        p.player_index                  = player_index
        p.team_index                    = team_index
        p.account_id                    = 100000 + player_index
        p.session_id                    = -1
        p.character_global_id           = character_global_id or (16000000 + random.choice(BOT_BRAWLERS))
        p.skin_global_id                = 0
        p.hero_power_level              = random.randint(5, 9)
        p.name                          = random.choice(BOT_NAMES)
        p.thumbnail_global_id           = 28000000
        p.name_color_global_id          = 43000000
        p.high_name_color_global_id     = 46000000
        return p
