from G.GameObject import GameObject, OBJECT_TYPE_AREA
from G.Assets import area_effect_data
from L.BitStream import BitStream

PLAYBACK_ACTIVE  = 8
PLAYBACK_PAYBACK = 4


class AreaEffect(GameObject):
    __slots__ = (
        'data', 'name', 'playback_type', 'radius',
        'is_active', 'life_time_consumed_percent', 'payback',
        'aoe_dot', 'normal_dmg',
        'display_scale', 'source', 'damage', 'duration_ticks',
        'tick_counter', 'should_be_destructed',
    )

    def __init__(self, data_class: int = 17, data_instance: int = 0, name: str = ''):
        super().__init__(data_class, data_instance)

        self.data = area_effect_data(name) if name else {}
        self.name = name

        self.playback_type = int(self.data.get('PlaybackType') or 0)
        self.radius        = int(self.data.get('Radius') or 0)

        self.is_active                 = False
        self.aoe_dot                   = 0
        self.normal_dmg                = 0
        self.life_time_consumed_percent = 0
        self.payback                   = 0
        self.display_scale             = 0
        self.source                    = None
        self.damage                    = 0
        self.duration_ticks            = 0
        self.tick_counter              = 0
        self.should_be_destructed      = False

    def get_object_type(self) -> int:
        return OBJECT_TYPE_AREA

    def get_radius(self) -> int:
        return self.radius

    def should_destruct(self) -> bool:
        return self.should_be_destructed

    def set_source(self, source, skill_type: int = 0):
        self.source = source

    def set_damage(self, damage: int):
        self.damage = damage

    def trigger(self, duration_ticks: int = 0):
        self.is_active      = True
        self.duration_ticks = duration_ticks

    def tick(self):
        if self.duration_ticks > 0:
            self.tick_counter += 1
            self.life_time_consumed_percent = min(100, self.tick_counter * 100 // self.duration_ticks)
            if self.tick_counter >= self.duration_ticks:
                self.should_be_destructed = True

    def encode(self, bs: BitStream, is_own: bool, vision_team: int = 0):
        super().encode(bs, is_own, vision_team)

        if self.playback_type == PLAYBACK_ACTIVE:
            bs.write_boolean(self.is_active)

        bs.wpi7(self.life_time_consumed_percent)

        if self.playback_type == PLAYBACK_PAYBACK:
            bs.wpi7(self.payback)

        has_source = self.source is not None
        bs.write_boolean(has_source)
        if has_source:
            bs.wpi27(self.source.get_global_id())

        bs.woften0_65535(self.display_scale)
