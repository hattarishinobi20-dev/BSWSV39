from G.TileMap import TileMap
from G.Assets import get_map_rows, get_map_rows_by_name

_FALLBACK = ['.' * 21] * 21


def _create(rows: list[str]) -> TileMap:
    width  = max(len(row) for row in rows)
    height = len(rows)
    padded = [row.ljust(width, '.') for row in rows]
    return TileMap(width, height, ''.join(padded))


def create(location_global_id: int) -> TileMap:
    return _create(get_map_rows(location_global_id) or _FALLBACK)


def create_by_name(map_name: str) -> TileMap:
    return _create(get_map_rows_by_name(map_name) or _FALLBACK)
