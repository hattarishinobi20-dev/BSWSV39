import math

from G.Assets import skill_data, area_effect_data
from G.LogicMath import (
    clamp, path_length, trunc_div, get_rotated_x, get_rotated_y, closest_level_border_collision,
)

CHARGE_PER_SHOT    = 1000
TICK_MS            = 50
TICKS_PER_SECOND   = 20
BATTLE_INTRO_TICKS = 100
VALID_TILE_PADDING = 100
BORDER_PADDING     = 95
VALID_MAP_PADDING  = 1

BEHAVIOR_ATTACK       = 'Attack'
BEHAVIOR_CHARGE       = 'Charge'
BEHAVIOR_WHIRLWIND    = 'Ww'
BEHAVIOR_AREA_BUFF    = 'AreaBuff'
BEHAVIOR_CHANGE       = 'ChangeCharacter'
BEHAVIOR_SHIELD       = 'ProjectileShield'
BEHAVIOR_INVISIBILITY = 'Invisibility'
BEHAVIOR_BLINK        = 'Blink'


class Skill:
    __slots__ = (
        'name', 'data', 'is_ultimate', 'owner',
        'ticks_active', 'on_activate', 'cool_down', 'charge',
        'max_charge', 'infinity', 'x', 'y', 'max_ticks_active',
        'last_attack_tick', 'hero_level', 'damage_buff',
        'is_from_auto_attack', 'seem_to_be_active', 'fire_dude_cool_down',
        'recharge_modifier',
    )

    def __init__(self, name: str, is_ultimate: bool, owner=None):
        self.name         = name
        self.data         = skill_data(name) or {}
        self.is_ultimate  = is_ultimate
        self.owner        = owner

        max_charge_count  = int(self.data.get('MaxCharge') or 0)
        self.max_charge   = max(1000, 1000 * max_charge_count)
        self.charge       = self.max_charge
        self.ticks_active = 0
        self.max_ticks_active = 0
        self.on_activate  = False
        self.cool_down    = 0
        self.infinity     = False
        self.x            = 0
        self.y            = 0
        self.last_attack_tick = -1000
        self.hero_level   = 0
        self.damage_buff  = 0
        self.is_from_auto_attack  = False
        self.seem_to_be_active    = False
        self.fire_dude_cool_down  = 0
        self.recharge_modifier    = 0
        if owner is not None:
            self.hero_level = owner.get_hero_level() + 1

    def level_to(self, owner):
        self.hero_level  = owner.get_hero_level()
        self.damage_buff = owner.battle_royale_buffs + owner.damage_multiplier

    def get_max_charge(self) -> int:
        return self.max_charge

    def skill_damage_math(self, damage: int) -> int:
        if damage <= 0:
            return 0
        return int(math.floor(damage * (1.0 + (self.hero_level + self.damage_buff) / 10.0)))

    def is_active(self) -> bool:
        return self.ticks_active > 0

    def should_end_this_tick(self) -> bool:
        return self.ticks_active == TICK_MS

    def add_charge(self, amount: int):
        owner = self.owner
        extra = 0
        if owner is not None:
            value = owner.get_card_value_for_passive('extra_bullet', 1)
            if value != -1:
                extra = value
        self.charge = clamp(self.charge + amount * 10, 0, 1000 * (int(self.data.get('MaxCharge') or 0) + extra))

    def has_enough_charge(self) -> bool:
        return self.charge >= CHARGE_PER_SHOT

    def has_full_charge(self) -> bool:
        return self.charge == self.max_charge

    def max_cooldown(self) -> int:
        return self.cooldown_ms()

    def has_button(self) -> bool:
        return True

    def is_ok_to_reduce_cooldown(self) -> bool:
        return True

    def behavior_type(self) -> str:
        return self.data.get('BehaviorType', '')

    def hold_to_shoot(self) -> bool:
        return self.data.get('HoldToShoot', '').lower() == 'true'

    def skill_can_change(self) -> bool:
        return self.data.get('SkillCanChange', '').lower() == 'true'

    def instance_id(self) -> int:
        return int(self.data.get('_instance') or 0)

    def charged_shot_count(self) -> int:
        return int(self.data.get('ChargedShotCount') or 0)

    def active_time(self) -> int:
        return int(self.data.get('ActiveTime') or 0)

    def cooldown_ms(self) -> int:
        return int(self.data.get('Cooldown') or 0)

    def recharge_ms(self) -> int:
        return int(self.data.get('RechargeTime') or 1500)

    def ms_between_attacks(self) -> int:
        return int(self.data.get('MsBetweenAttacks') or 0)

    def casting_range(self) -> int:
        return int(self.data.get('CastingRange') or 0)

    def charge_type(self) -> int:
        return int(self.data.get('ChargeType') or 0)

    def charge_speed(self) -> int:
        return int(self.data.get('ChargeSpeed') or 0)

    def charge_pushback(self) -> int:
        return int(self.data.get('ChargePushback') or 0)

    def attack_pattern(self) -> int:
        return int(self.data.get('AttackPattern') or 0)

    def damage(self) -> int:
        return int(self.data.get('Damage') or 0)

    def spread(self) -> int:
        return int(self.data.get('Spread') or 0)

    def bullets_per_shot(self) -> int:
        return int(self.data.get('NumBulletsInOneAttack') or 1)

    def projectile_name(self) -> str:
        return self.data.get('Projectile') or ''

    def projectile_data(self):
        from G.Assets import projectile_data
        name = self.projectile_name()
        return projectile_data(name) if name else None

    def is_positional_targeted(self) -> bool:
        return self.data.get('IsPositionalTargeted', '').lower() == 'true'

    def get_range_add_subtiles(self, owner):
        return -1

    def interrupt(self, character):
        behavior = self.behavior_type()
        if (behavior == BEHAVIOR_ATTACK or behavior == BEHAVIOR_WHIRLWIND) and self.ticks_active >= 1:
            self.ticks_active = 0
            weapon = character.get_weapon_skill()
            if weapon is not None:
                weapon.cool_down = weapon.cooldown_ms()
            ultimate = character.get_ultimate_skill()
            if ultimate is not None:
                ultimate.cool_down = ultimate.cooldown_ms()
            if behavior == BEHAVIOR_ATTACK:
                character.end_rapid_fire()

    def activate_laser_ball(self, owner, skill_type: int):
        if skill_type == 0 and self.charge > CHARGE_PER_SHOT:
            self.charge -= CHARGE_PER_SHOT
        if skill_type == 1 and owner.get_player() is not None:
            owner.get_player().use_ulti()

    def get_spread_from_hold(self, owner) -> int:
        pattern = self.attack_pattern()
        if pattern == 14:
            return self.spread() * owner.jester_skill_count
        if pattern != 13:
            return self.spread()
        max_hold = owner.get_max_hold_ticks()
        if max_hold < 1:
            return self.spread()
        return self.spread() - owner.get_skill_holded_ticks() * 130 // max_hold

    def activate(self, character, x: int, y: int) -> bool:
        if self.charge < CHARGE_PER_SHOT and int(self.data.get('MaxCharge') or 0) != 0:
            return False
        if self.ticks_active > 0 or self.cool_down > 0:
            return False

        self.charge -= CHARGE_PER_SHOT

        character.interrupt_all_skills(True)
        self.ticks_active = self.active_time()
        player = character.get_player()
        if player is not None and player.accessory is not None:
            accessory = player.accessory
            if not self.is_ultimate and accessory.is_active and accessory.type() == 'next_attack_change':
                custom = int(accessory.data.get('CustomValue2') or 0)
                if custom >= 1:
                    self.ticks_active = custom
        if self.is_ultimate:
            value = character.get_card_value_for_passive('more_bullets_ulti', 1)
            if value >= 1:
                self.ticks_active = value
        if not self.is_ultimate:
            value = character.get_card_value_for_passive('decrease_unload_time', 1)
            if value >= 1:
                self.ticks_active -= self.ticks_active * value // 100
        if self.is_ultimate:
            boost = character.get_gear_boost(11)
            if boost >= 1:
                self.ticks_active += boost * 20
        self.x, self.y = self.get_skill_cast_pos(
            character, x, y, self.get_range_add_subtiles(character))
        self.on_activate = True
        self.max_ticks_active = self.ticks_active
        character.block_health_regen()
        character.casting_time = self.casting_time() - character.skill_hold_ticks * TICK_MS
        return True

    def casting_time(self) -> int:
        return int(self.data.get('CastingTime') or 0)

    def execute_first_attack_immediately(self) -> bool:
        return self.data.get('ExecuteFirstAttackImmediately', '').lower() == 'true'

    def get_skill_cast_pos(self, character, x: int, y: int, range_add: int):
        battle = character.get_battle()
        if battle is None:
            return x, y
        cast_x = x
        cast_y = y
        behavior = self.behavior_type()
        if behavior in (BEHAVIOR_WHIRLWIND, BEHAVIOR_CHARGE):
            cast_x = clamp(cast_x, 1, battle.tilemap.logic_width - 2)
            cast_y = clamp(cast_y, 1, battle.tilemap.logic_height - 2)
        casting_range = self.casting_range()
        if casting_range >= 1:
            dx = cast_x - character.x
            dy = cast_y - character.y
            limit = 100 * (casting_range + range_add)
            distance = path_length(character.x, character.y, cast_x, cast_y)
            if distance > limit > 0:
                dx = limit * dx // distance
                dy = limit * dy // distance
            cast_x = dx + character.x
            cast_y = dy + character.y
        if self.data.get('AlwaysCastAtMaxRange', '').lower() == 'true':
            dx = cast_x - character.x
            dy = cast_y - character.y
            distance = path_length(0, 0, dx, dy)
            if distance > 0:
                length = 100 * (casting_range + range_add)
                cast_x = dx * length // distance + character.x
                cast_y = dy * length // distance + character.y
        if behavior in (BEHAVIOR_WHIRLWIND, BEHAVIOR_CHARGE):
            padding = VALID_TILE_PADDING
            cast_x = clamp(cast_x, padding + 1, battle.tilemap.logic_width - padding - 2)
            cast_y = clamp(cast_y, padding + 1, battle.tilemap.logic_height - padding - 2)
        else:
            cast_x = clamp(cast_x, VALID_MAP_PADDING, battle.tilemap.logic_width - 2)
            cast_y = clamp(cast_y, VALID_MAP_PADDING, battle.tilemap.logic_height - 2)
        return cast_x, cast_y

    def cast_position(self, character, x: int, y: int):
        return self.get_skill_cast_pos(character, x, y, self.get_range_add_subtiles(character))

    def run_attack_behavior(self, owner, x: int, y: int):
        from G.Assets import item_data, character_data_by_name
        owner.spawned_item_data  = None
        owner.summoned_character = None
        spawn_item = self.data.get('SpawnedItem') or ''
        if spawn_item:
            if owner.unique_property != 10 or owner.charged_shot_count >= owner.get_max_charged_shots():
                item = item_data(spawn_item)
                owner.set_item_summoning_variables(
                    item, int(self.data.get('NumSpawns') or 0), int(self.data.get('MaxSpawns') or 0),
                    self.skill_damage_math(self.damage()), self.damage())
        else:
            summon_name = self.data.get('SummonedCharacter') or ''
            if summon_name:
                data = character_data_by_name(summon_name)
                if data:
                    damage = int(data.get('AutoAttackDamage') or 0)
                    if damage == 0:
                        effect = area_effect_data(data.get('AreaEffect') or '')
                        if effect:
                            damage = abs(int(effect.get('Damage') or 0))
                    damage = damage * ((self.hero_level - 1) * 10) // 100
                    owner.set_character_summoning_variables(
                        data, int(self.data.get('NumSpawns') or 0), int(self.data.get('MaxSpawns') or 0),
                        damage,
                        int(data.get('Hitpoints') or 0) * ((self.hero_level - 1) * 10) // 100 + owner.get_gear_boost(7))
        active_time = self.active_time()
        if not self.is_ultimate:
            value = owner.get_card_value_for_passive('decrease_unload_time', 1)
            if value >= 1:
                active_time -= active_time * value // 100
        bullets = self.chosen_bullets(owner)
        owner.trigger_rapid_fire(
            self.x, self.y, self.attack_pattern(), bullets, self.ms_between_attacks(),
            self.projectile_data(), self.skill_damage_math(self.damage()),
            self.casting_range() + self.get_range_add_subtiles(owner),
            self.get_spread_from_hold(owner), active_time, self.damage(),
            self.execute_first_attack_immediately())
        area_name = self.data.get('AreaEffectObject') or ''
        if area_name:
            area_data = area_effect_data(area_name)
            damage = self.damage()
            if damage <= 0 and area_data:
                damage = int(area_data.get('Damage') or 0)
            level_bonus = 2 if self.is_ultimate else 1
            owner.add_area_effect(damage * ((self.hero_level - 1) * 10) // 100, 0, area_data, level_bonus, False)
        self.on_activate = False

    def chosen_bullets(self, owner) -> int:
        bullets = self.bullets_per_shot()
        if self.attack_pattern() == 14:
            bullets = owner.jester_skill_count + 1
        return bullets

    def trigger_charge(self, owner, x: int, y: int, speed: int, damage: int) -> bool:
        return owner.trigger_charge(x, y, speed, self.charge_type(), damage,
                                    self.charge_pushback(), self.charge_type() == 10,
                                    area_effect_data(self.data.get('AreaEffectObject') or ''))

    def tick(self, character=None):
        owner = character or self.owner
        if owner is None:
            return
        if self.infinity:
            self.cool_down = 0
            self.charge    = self.max_charge
        if owner.get_card_value_for_passive('berserker', 1) >= 1:
            if owner.get_hitpoint_percentage() <= owner.get_card_value_for_passive('berserker', 0):
                self.cool_down *= owner.get_card_value_for_passive('berserker', 1)
        self.level_to(owner)
        if self.charge_type() == 15:
            self.x = owner.x
            self.y = owner.y
        was_active = self.ticks_active
        if self.on_activate:
            if owner.casting_time > 0:
                return
            ultimate_slot = 2
            if owner.get_ultimate_skill() is self:
                owner.ultiing = True
                owner.ulti_used()
            else:
                owner.ultiing = False
                ultimate_slot = 1
            if self.is_ultimate:
                cooldown = self.ticks_active + self.cooldown_ms()
                weapon = owner.get_weapon_skill()
                if weapon is not None:
                    weapon.cool_down = self.ticks_active + weapon.cooldown_ms()
            else:
                cooldown = self.ticks_active + self.cooldown_ms()
            if cooldown >= TICK_MS:
                cooldown -= TICK_MS
            self.cool_down = cooldown
            self.run_behavior(owner, ultimate_slot)
        self.ticks_active = max(0, self.ticks_active - TICK_MS)
        if self.cool_down >= 1:
            self.cool_down -= TICK_MS
            if self.name == 'FireDudeWeapon':
                self.fire_dude_cool_down = self.cool_down + 100
            if self.cool_down <= 0:
                self.cool_down = 0
        if self.fire_dude_cool_down >= 1:
            self.fire_dude_cool_down -= 25
            if self.fire_dude_cool_down <= 0:
                self.fire_dude_cool_down = 0
        if self.charge < self.max_charge and self.cool_down <= 0 and self.fire_dude_cool_down <= 0:
            if int(self.data.get('MaxCharge') or 0) >= 1 and self.recharge_ms() > 0:
                gain = 1000 // (self.recharge_ms() // TICK_MS)
                gain += gain * owner.get_gear_boost(5) // 100
                if owner.reload_buff_ticks > 0:
                    gain *= 2
                self.charge = min(self.max_charge, self.charge + gain)
        if was_active >= 1 and self.ticks_active <= 0:
            owner.end_rapid_fire()
        if self.ticks_active <= 0:
            self.max_ticks_active = 0

    def run_behavior(self, owner, slot: int):
        behavior = self.behavior_type()
        if behavior == BEHAVIOR_ATTACK:
            self.run_attack_behavior(owner, self.x, self.y)
            return
        if behavior == BEHAVIOR_CHARGE:
            self.trigger_charge(owner, self.x, self.y, self.charge_speed(), self.skill_damage_math(self.damage()))
            owner.charge_normal_dmg = self.damage()
            self.on_activate = False
            return
        if behavior == BEHAVIOR_WHIRLWIND:
            owner.trigger_whirlwind(self.skill_damage_math(self.damage()), self.damage(), self.ms_between_attacks())
            self.on_activate = False
            return
        if behavior == BEHAVIOR_AREA_BUFF:
            area_data = area_effect_data(self.data.get('AreaEffectObject') or '')
            owner.add_area_effect(self.damage() * ((self.hero_level - 1) * 10) // 100, 0, area_data, slot, False)
            self.on_activate = False
            return
        if behavior == BEHAVIOR_CHANGE:
            from G.Assets import character_data_by_name
            data = character_data_by_name(self.data.get('SummonedCharacter') or '')
            player = owner.get_player()
            if data and player is not None:
                player.own_object_id = owner.trigger_transforming(data).get_global_id()
            self.on_activate = False
            return
        if behavior == BEHAVIOR_SHIELD:
            import math as _math
            from G.LogicMath import get_angle
            owner.projectile_shield_angle = int(self.spread() * 0.008 * 57.296)
            owner.projectile_shield_scale = self.casting_range() * 100
            self.on_activate = False
            owner.set_forced_angle(get_angle(self.x - owner.x, self.y - owner.y))
            return
        if behavior == BEHAVIOR_INVISIBILITY:
            owner.set_invisible(self.active_time())
            self.on_activate = False
            return
        if behavior == BEHAVIOR_BLINK:
            area_name = self.data.get('AreaEffectObject') or ''
            owner.add_area_effect(0, 0, area_effect_data(area_name), slot, False)
            owner.set_position(self.x, self.y, 0)
            self.on_activate = False
            return
        if behavior == 'Summon':
            owner.summon_minions(self)
            self.on_activate = False
            return
        if behavior == 'Melee':
            owner.melee_attack(self.x, self.y, self.skill_damage_math(self.damage()))
            self.on_activate = False
            return
        self.on_activate = False

    def encode(self, bs, is_own: bool, owner=None):
        bs.woften0_255(self.ticks_active // TICK_MS)
        bs.write_boolean(self.on_activate)
        bs.woften0_255(self.cool_down // TICK_MS)

        if int(self.data.get('MaxCharge') or 0) >= 1:
            divisor = 20 if self.hold_to_shoot() else 1
            bs.wpi12(self.charge // divisor)

        if self.skill_can_change():
            bs.write_positive_int(self.instance_id(), 8)
