from collections import deque

from L.BitStream import BitStream
from G.GameObject import (
    GameObject,
    OBJECT_TYPE_CHARACTER,
    OBJECT_TYPE_PROJECTILE,
    OBJECT_TYPE_AREA,
    OBJECT_TYPE_ITEM,
)
from G.GameModeUtil import mode_has_carryables, has_two_bases
from G.LogicMath import clamp, distance

GMV_GEM_GRAB       = 0
GMV_BOUNTY         = 3
GMV_BOUNTY_DUO     = 15
GMV_SHOWDOWN       = 6
GMV_DUO_SHOWDOWN   = 9
GMV_BIG_GAME       = 7
GMV_KING_OF_HILL   = 17
GMV_KNOCKOUT       = 20
GMV_CTF            = 16
GMV_SIEGE          = 11
GMV_TRAINING       = 13
GMV_LONE_STAR      = 14
GMV_BOSS_TOWN      = 18
GMV_BOSS_FIGHT     = 10
GMV_ROBO_RUMBLE    = 8

WIDE_MAP_TILES     = 21
PROJECTILE_RADIUS  = 600


class GameObjectManager:
    __slots__ = (
        'battle', '_objects', '_add_q', '_rem_q', '_counter', 'petrols',
    )

    def __init__(self, battle):
        self.battle                     = battle
        self._objects: list[GameObject] = []
        self._add_q: deque[GameObject]  = deque()
        self._rem_q: deque[GameObject]  = deque()
        self._counter: int              = 0
        self.petrols: list              = []

    def add(self, obj: GameObject):
        if obj is None:
            return
        obj_type = obj.get_object_type()
        global_id = (obj_type * 1000000 + self._counter) if obj_type > 0 else (1000000 + self._counter)
        self._counter += 1
        obj.attach(self, global_id)
        self._add_q.append(obj)

    def remove(self, obj: GameObject):
        self._rem_q.append(obj)

    def get_objects(self) -> list:
        return self._objects

    def get_by_id(self, global_id: int) -> GameObject | None:
        for obj in self._objects:
            if obj is not None and obj.get_global_id() == global_id:
                return obj
        for obj in self._add_q:
            if obj is not None and obj.get_global_id() == global_id:
                return obj
        return None

    def get_by_index(self, index: int):
        candidates = self._objects + list(self._add_q)
        for obj in candidates:
            if obj is not None and obj.get_object_type() == OBJECT_TYPE_CHARACTER and obj.get_index() == index:
                return obj
        return None

    def get_by_clone_of_id(self, global_id: int) -> list:
        return [obj for obj in self._objects if obj.get_clone_of_global_id() == global_id]

    def get_characters(self) -> list:
        found = [obj for obj in self._objects if obj is not None and obj.get_object_type() == OBJECT_TYPE_CHARACTER]
        found += [obj for obj in self._add_q if obj is not None and obj.get_object_type() == OBJECT_TYPE_CHARACTER]
        return found

    def get_projectiles(self) -> list:
        found = [obj for obj in self._objects if obj is not None and obj.get_object_type() == OBJECT_TYPE_PROJECTILE]
        found += [obj for obj in self._add_q if obj is not None and obj.get_object_type() == OBJECT_TYPE_PROJECTILE]
        return found

    def get_items(self) -> list:
        found = [obj for obj in self._objects if obj is not None and obj.get_object_type() == OBJECT_TYPE_ITEM]
        found += [obj for obj in self._add_q if obj is not None and obj.get_object_type() == OBJECT_TYPE_ITEM]
        return found

    def get_area_effects(self) -> list:
        found = [obj for obj in self._objects if obj is not None and obj.get_object_type() == OBJECT_TYPE_AREA]
        found += [obj for obj in self._add_q if obj is not None and obj.get_object_type() == OBJECT_TYPE_AREA]
        return found

    def get_specific_projectiles(self, game_object: GameObject) -> list:
        return [
            obj for obj in self._objects
            if obj is not None
            and obj.get_object_type() == OBJECT_TYPE_PROJECTILE
            and obj.get_index() // 16 != game_object.get_index() // 16
            and distance(obj.x, obj.y, game_object.x, game_object.y) <= PROJECTILE_RADIUS
        ]

    def get_visible_game_objects(self, team_index: int, own_object_id: int) -> list:
        own = self.get_by_id(own_object_id)
        in_realm = own.is_in_realm if own is not None else False

        visible = []
        for obj in self._objects:
            if obj is None:
                continue
            if obj.is_in_realm != in_realm:
                continue
            if obj.get_fade_counter() > 0 or obj.get_index() // 16 == team_index:
                visible.append(obj)

        for obj in self._add_q:
            if obj is None:
                continue
            if obj.is_in_realm != in_realm:
                continue
            if obj.get_fade_counter() > 0 or obj.get_index() // 16 == team_index:
                visible.append(obj)

        return visible

    def pre_tick(self):
        for obj in list(self._objects):
            if obj is None:
                self._objects.remove(obj)
                continue
            if obj.should_destruct():
                obj.on_destruct()
                self._rem_q.append(obj)
            else:
                obj.reset_events()

        while self._add_q:
            self._objects.append(self._add_q.popleft())

        while self._rem_q:
            obj = self._rem_q.popleft()
            if obj in self._objects:
                self._objects.remove(obj)

    def tick(self):
        for obj in list(self._objects):
            if obj is not None:
                obj.tick()

    def encode(self, bs: BitStream, own_object_id: int, player_index: int, team_index: int):
        battle  = self.battle
        gmv     = battle.gmv
        players = battle.players

        visible = self.get_visible_game_objects(team_index, own_object_id)

        bs.wpi21(own_object_id)
        bs.write_boolean(False)

        if gmv == GMV_GEM_GRAB:
            bs.wpvint65535(battle.get_gem_grab_countdown())
        elif gmv == GMV_KING_OF_HILL:
            bs.wpi3(1)
            bs.wpi7(battle.zone1_score)
            bs.wpi7(battle.zone2_score)
        elif gmv == GMV_KNOCKOUT:
            bs.wpi11(0)
            bs.write_boolean(battle.is_round_ending)
            bs.write_boolean(True)
            bs.wpi2(battle.current_round)
            bs.write_boolean(True)
            winners = battle.knockout_round_winners(team_index)
            bs.wi7(winners[0])
            bs.wi7(winners[1])
            bs.wi7(winners[2])

        bs.write_boolean(False)
        bs.wi4(-1)

        bs.write_boolean(False)
        bs.write_boolean(False)
        bs.write_boolean(False)
        bs.write_boolean(False)

        tilemap = battle.tilemap
        v1 = clamp(tilemap.width, 0, tilemap.width - 1)
        v2 = clamp(tilemap.height, 0, tilemap.height - 1)

        if v1 > WIDE_MAP_TILES:
            bs.wpi6(0)
            bs.wpi6(0)
            bs.wpi6(v1)
        else:
            bs.wpi5(0)
            bs.wpi6(0)
            bs.wpi5(v1)
        bs.wpi6(v2)

        for x in range(tilemap.width):
            for y in range(tilemap.height):
                tile = tilemap.get_tile(x, y, True, True)
                if tile is None:
                    continue
                if tile.respawn_seconds > 0 or tile.is_destructible or tile.data.get('TileCode') == 'I':
                    bs.write_boolean(
                        tile.is_destructed()
                        and tilemap.get_tile(x, y, True, True).is_destructed()
                    )

        bs.woften0_65535(len(tilemap.new_tiles))
        for tile in tilemap.new_tiles:
            bs.wpi12(tile.tile_x() + tilemap.width * tile.tile_y())
            bs.wpi4(tile.dynamic_code)

        bs.woften0_65535(len(self.petrols))
        for petrol in self.petrols:
            bs.wpi6(petrol.x)
            bs.wpi6(petrol.y)
            bs.wi4(petrol.player_index)

        for index, player in enumerate(players):
            bs.write_boolean(player.is_alive)
            bs.write_boolean(player.has_ulti())

            if gmv == GMV_SHOWDOWN:
                bs.wpi4(0)

            accessory = player.accessory
            if accessory is not None:
                accessory.encode(bs, player.own_object_id == own_object_id)

            if gmv == GMV_BOUNTY:
                bs.write_boolean(False)

            bs.woften0_255(0)
            bs.write_boolean(False)

            using_pin = player.is_using_pin(battle.ticks)
            bs.write_boolean(using_pin)
            if using_pin:
                bs.wi3(player.pin_index)
                bs.wpi14(player.start_pin_ticks)

            if index != player_index:
                continue

            bs.wpi12(clamp(player.get_ulti_charge(), 0, 4000))
            bs.write_boolean(player.has_ulti())
            bs.write_boolean(False)
            bs.woften0_255(0)

        bs.woften0_65535(0)
        bs.woften0_255(0)

        if mode_has_carryables(gmv):
            bs.write_boolean(battle.goal_team == -1 or battle.set_stop_ticks)
            bs.wi1(battle.goal_team if battle.goal_team != -1 else 0)

        if gmv == GMV_SHOWDOWN:
            bs.wpi4(battle.players_alive)
        elif gmv == GMV_ROBO_RUMBLE:
            bs.wpi7(0)
            bs.wpi7(0)
            bs.write_boolean(True)
        elif gmv == GMV_DUO_SHOWDOWN:
            bs.wpi3(battle.get_alive_teams())
        elif gmv == GMV_CTF:
            bs.wpi13(0)
            bs.wpi13(0)
        elif has_two_bases(gmv):
            hp1 = 0
            hp2 = 0
            for character in self.get_characters():
                if not character.is_base:
                    continue
                if not character.is_alive():
                    continue
                if character.get_index() // 16 == 0:
                    hp1 = character.get_hitpoint_percentage()
                else:
                    hp2 = character.get_hitpoint_percentage()
            bs.wpi7(hp1)
            bs.wpi7(hp2)
            if gmv == GMV_SIEGE:
                bs.wpi8(0)
                bs.wpi8(0)
                bs.wpi3(0)
                bs.wpi3(0)
                bs.wpi6(0)
                bs.wpi6(0)
                bs.write_boolean(False)
        elif gmv == GMV_BOSS_TOWN:
            bs.wpi7(0)
        elif gmv == GMV_LONE_STAR:
            bs.wpi7(0)
            bs.wpi14(0)
        elif gmv == GMV_TRAINING:
            bs.wpi17(0)
        elif gmv == GMV_BOSS_FIGHT:
            bs.wpi7(10)
        elif gmv == GMV_BIG_GAME:
            bs.wpi7(0)

        for player in players:
            if gmv not in (GMV_SHOWDOWN, GMV_DUO_SHOWDOWN):
                bs.write_boolean(True)
                bs.write_positive_vint(player.score, 3)
            else:
                bs.write_boolean(False)

            kill_list = player.kill_list
            if gmv not in (GMV_SHOWDOWN, GMV_DUO_SHOWDOWN):
                if bs.write_boolean(len(kill_list) > 0):
                    bs.wpi4(len(kill_list))
                    for entry in kill_list:
                        bs.wpi4(entry.get('player_index', 0))
                        bs.wi3(entry.get('stars', 0))
            else:
                bs.write_boolean(False)

        bs.wpvint4(len(visible))

        if visible:
            for obj in visible:
                data_id = obj.get_data_id()
                bs.wpi5(data_id // 1000000)
                bs.wpi9(data_id % 1000000)

            for obj in visible:
                bs.wpvint65535(obj.get_global_id() % 1000000)

            bs.write_boolean(False)

            for obj in visible:
                obj.encode(bs, obj.get_global_id() == own_object_id, team_index)

        if gmv == GMV_BIG_GAME:
            if bs.write_boolean(False):
                bs.wpi15(0)
                bs.wpi16(0)
