import threading

_lock    = threading.Lock()
_sessions = set()


def add(connection):
    with _lock:
        _sessions.add(connection)


def remove(connection):
    with _lock:
        _sessions.discard(connection)


def count() -> int:
    with _lock:
        return len(_sessions)
