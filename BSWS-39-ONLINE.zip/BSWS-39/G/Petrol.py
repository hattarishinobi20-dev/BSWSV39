PETROL_LIFETIME_TICKS = 20 * 15


class Petrol:
    __slots__ = (
        'destructed_ticks', 'ignited', 'player_index', 'team_index',
        'x', 'y', 'scale', 'damage', 'slowing',
    )

    def __init__(self, x: int, y: int, scale: int, damage: int,
                 player_index: int, team_index: int):
        self.x                = x
        self.y                = y
        self.scale            = scale * scale
        self.damage           = damage
        self.player_index     = player_index
        self.team_index       = team_index
        self.destructed_ticks = 0
        self.ignited          = False
        self.slowing          = 0

    def ignite(self, manager, damage: int):
        self.ignited = True
        if damage > 0:
            self.damage = damage

    def tick(self, manager) -> bool:
        self.destructed_ticks += 1
        return self.destructed_ticks >= PETROL_LIFETIME_TICKS
