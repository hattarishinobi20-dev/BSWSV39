from G.Assets import accessory_data
from L.BitStream import BitStream

DEFAULT_USES = 3
STATE_READY  = 1


class Accessory:
    __slots__ = (
        'name', 'data', 'uses', 'cool_down', 'state', 'is_active',
        'start_using_tick', 'angle', 'activation_delay', 'x', 'y',
        'ticks_active',
    )

    def __init__(self, name: str):
        self.name              = name
        self.data              = accessory_data(name)
        self.uses              = DEFAULT_USES
        self.cool_down         = 0
        self.state             = 0
        self.is_active         = False
        self.start_using_tick  = 0
        self.angle             = 0
        self.activation_delay  = int(self.data.get('ActivationDelay') or 0)
        self.x                 = 0
        self.y                 = 0
        self.ticks_active      = 0

    def type(self) -> str:
        return self.data.get('Type', '')

    def encode(self, bs: BitStream, is_own: bool):
        bs.wpi3(self.uses)

        if is_own:
            bs.woften0_255(self.cool_down)
            if bs.woften0_255(self.state) != STATE_READY:
                return
            bs.wpi14(self.start_using_tick)
            bs.wpi9(self.angle)
        else:
            if not bs.write_boolean(self.is_active):
                return
            bs.wpi14(self.start_using_tick)
            bs.wpi9(self.angle)
