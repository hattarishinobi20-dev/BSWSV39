class Immunity:
    __slots__ = ('target_index', 'target_data', 'ticks')

    def __init__(self, target_index: int, target_data, ticks: int):
        self.target_index = target_index
        self.target_data  = target_data
        self.ticks        = ticks

    def tick(self, ticks: int) -> bool:
        self.ticks -= ticks
        return self.ticks < 1
