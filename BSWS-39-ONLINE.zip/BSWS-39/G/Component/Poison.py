from G.LogicMath import trunc_div

TICK_TIMER = 20
SPLIT_TYPE = 4
SPLIT_FAST = 2
SPLIT_DEFAULT = 4


class Poison:
    __slots__ = (
        'damage', 'normal_dmg', 'is_ulti', 'source', 'source_index',
        'type', 'tick_timer', 'second_timer',
    )

    def __init__(self, damage: int, normal_dmg: int, is_ulti: bool,
                 source, source_index: int, type: int):
        divisor = SPLIT_FAST if type == SPLIT_TYPE else SPLIT_DEFAULT
        self.damage       = trunc_div(damage, divisor)
        self.normal_dmg   = trunc_div(normal_dmg, divisor)
        self.is_ulti      = is_ulti
        self.source       = source
        self.source_index = source_index
        self.type         = type
        self.tick_timer   = TICK_TIMER
        self.second_timer = divisor

    def refresh(self, damage: int, normal_dmg: int, is_ulti: bool, type: int):
        divisor = SPLIT_FAST if type == SPLIT_TYPE else SPLIT_DEFAULT
        self.damage       = trunc_div(damage, divisor)
        self.normal_dmg   = trunc_div(normal_dmg, divisor)
        self.is_ulti      = is_ulti
        self.type         = type
        self.tick_timer   = TICK_TIMER
        self.second_timer = divisor

    def allows_stacking(self) -> bool:
        return self.type == SPLIT_TYPE

    def tick(self, character) -> bool:
        self.tick_timer -= 1
        if self.tick_timer > 0:
            return False
        character.cause_damage(self.damage, self.source, self.is_ulti)
        self.second_timer -= 1
        self.tick_timer = TICK_TIMER
        return self.second_timer < 1
