from G.Tile import Tile, CODE_TO_SPAWN

LOGIC_TILE = 300


class TileMap:
    __slots__ = (
        'width', 'height', '_tiles', 'new_tiles',
        'spawn_points', 'spawn_points_team1', 'spawn_points_team2',
        'spawn_points_bases', 'zones_spawn_points', 'coop_base_spawn',
        'laser_ball_team1', 'laser_ball_team2', 'loot_box_spawn',
        'heal_tiles', 'damage_tiles', 'slow_tiles', 'fast_tiles',
        'teleport_tiles', 'springboard_tiles', 'training_dummies',
    )

    def __init__(self, width: int, height: int, data):
        self.width  = width
        self.height = height

        self._tiles   = []
        self.new_tiles = []

        self.spawn_points        = []
        self.spawn_points_team1  = []
        self.spawn_points_team2  = []
        self.spawn_points_bases  = []
        self.zones_spawn_points  = []
        self.coop_base_spawn     = []
        self.laser_ball_team1    = []
        self.laser_ball_team2    = []
        self.loot_box_spawn      = []
        self.heal_tiles          = []
        self.damage_tiles        = []
        self.slow_tiles          = []
        self.fast_tiles          = []
        self.teleport_tiles      = []
        self.springboard_tiles   = []
        self.training_dummies    = []

        chars = data if isinstance(data, str) else ''.join(data)

        index = 0
        for row in range(height):
            tile_row = []
            for col in range(width):
                tile = Tile(chars[index] if index < len(chars) else '.', col * LOGIC_TILE, row * LOGIC_TILE)
                tile_row.append(tile)
                self._register(tile)
                index += 1
            self._tiles.append(tile_row)

        if not self.spawn_points_team1:
            self.spawn_points_team1.append(Tile('.', 10 * LOGIC_TILE, 10 * LOGIC_TILE))
        if not self.spawn_points_team2:
            self.spawn_points_team2 = self.spawn_points_team1

    def _register(self, tile: Tile):
        code = tile.code
        if code == '1':
            self.spawn_points.append(tile)
            self.spawn_points_team1.append(tile)
        elif code == '2':
            self.spawn_points.append(tile)
            self.spawn_points_team2.append(tile)
            self.training_dummies.append(tile)
        elif code == '8':
            self.spawn_points_bases.append(tile)
            self.zones_spawn_points.append(tile)
        elif code == '0':
            self.training_dummies.append(tile)
        elif code == '3':
            self.training_dummies.append(tile)
        elif code == '4':
            self.loot_box_spawn.append(tile)
        elif code == '5':
            self.coop_base_spawn.append(tile)
        elif code == '6':
            self.laser_ball_team1.append(tile)
        elif code == '7':
            self.laser_ball_team2.append(tile)
        elif code == 'y':
            self.heal_tiles.append(tile)
        elif code == 'x':
            self.damage_tiles.append(tile)
        elif code == 'z':
            self.slow_tiles.append(tile)
        elif code == 'w':
            self.fast_tiles.append(tile)

        name = tile.name
        if name.startswith('Teleport'):
            self.teleport_tiles.append(tile)
        elif name == 'SpringBoard':
            self.springboard_tiles.append(tile)

    @property
    def logic_width(self) -> int:
        return self.width * LOGIC_TILE

    @property
    def logic_height(self) -> int:
        return self.height * LOGIC_TILE

    def get_tile(self, x: int, y: int, is_tile: bool = False, only_real_tiles: bool = False) -> Tile | None:
        if x < 0 or y < 0 or x >= self.width or y >= self.height:
            return None
        if not only_real_tiles:
            for tile in self.new_tiles:
                if tile.tile_x() == x and tile.tile_y() == y and not tile.is_destructed():
                    return tile
        return self._tiles[y][x]

    def get_tile_at_logic(self, x: int, y: int) -> Tile | None:
        return self.get_tile(x // LOGIC_TILE, y // LOGIC_TILE)

    def is_passable(self, x: int, y: int, is_tile: bool = True) -> bool:
        tile = self.get_tile(x, y, is_tile)
        if tile is None:
            return False
        return not tile.blocks_movement or tile.is_destructed()

    def add_tile(self, tile: Tile):
        tile.life_time = tile.life_time or 0
        self.new_tiles.append(tile)

    def tick(self, manager=None):
        index = 0
        while index < len(self.new_tiles):
            tile = self.new_tiles[index]
            if tile.life_time > 0:
                tile.life_time -= 1
                if tile.life_time == 0:
                    tile.destruct()
            if tile.is_destructed():
                self.new_tiles.pop(index)
                continue
            index += 1

    def all_tiles(self):
        for row in self._tiles:
            for tile in row:
                yield tile
